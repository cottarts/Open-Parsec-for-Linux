import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
import threading
import urllib.request
import urllib.error
spec=importlib.util.spec_from_file_location('control',Path(__file__).resolve().parents[2]/'apps/control/control.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
class ConfigTests(unittest.TestCase):
    def test_invalid_values_cannot_become_daemon_arguments(self):
        for value in [{'codec':'av1'},{'fps':True},{'output':'card1:DP-1; reboot'},{'name':'bad\nname'},{'token':'secret'},{'allow_guests':1}]:
            with self.subTest(value=value),self.assertRaises(ValueError):c.checked(value)
    def test_config_roundtrip_is_private_and_contains_no_account_secret(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp);cfg=c.save(directory,c.DEFAULT|{'name':'Open Parsec test','output':'card1:DP-1'})
            self.assertEqual(c.load(directory),cfg)
            self.assertEqual((directory/'settings.json').stat().st_mode&0o777,0o600)
            env=(directory/'settings.env').read_text()
            self.assertIn('--output card1:DP-1',env);self.assertNotIn('KESSEL_SESSION',env)
            self.assertIn(f'/run/user/{os.getuid()}/pulse/native',env)
    def test_renaming_keeps_vaapi_encoder(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            c.save(directory, c.DEFAULT | {'encoder': 'vaapi', 'name': 'Before'})
            cfg = c.load(directory)
            cfg['name'] = 'RenamedHost'
            c.save(directory, cfg)
            self.assertEqual(c.load(directory)['encoder'], 'vaapi')
            self.assertIn('--encoder vaapi', (directory / 'settings.env').read_text())
            self.assertIn('--name RenamedHost', (directory / 'settings.env').read_text())
    def test_auto_does_not_force_nvenc(self):
        self.assertEqual(c.DEFAULT['encoder'], 'auto')
        self.assertNotIn('--encoder', c.environment(c.DEFAULT))
class WebTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.s=c.server(Path(self.temp.name),0,'12345678')
        self.thread=threading.Thread(target=self.s.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.s.server_port}'
    def tearDown(self):self.s.shutdown();self.s.server_close();self.thread.join();self.temp.cleanup()
    def request(self,path,headers=None,data=None):
        return urllib.request.urlopen(urllib.request.Request(self.url+path,headers=headers or {},data=data),timeout=3)
    def test_api_requires_pin(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.request('/api/settings')
        self.assertEqual(ctx.exception.code,401)
        with self.request('/api/settings',{'X-OpenParsec-PIN':'12345678'}) as r:self.assertEqual(json.load(r)['codec'],'h264')
    def test_rebinding_host_is_refused_even_with_pin(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.request('/api/settings',{'Host':'evil.example','X-OpenParsec-PIN':'12345678'})
        self.assertEqual(ctx.exception.code,403)
    def test_cross_origin_save_is_refused(self):
        headers={'X-OpenParsec-PIN':'12345678','Origin':'http://evil.example'}
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.request('/api/settings',headers,json.dumps(c.DEFAULT).encode())
        self.assertEqual(ctx.exception.code,403)
    def test_same_origin_save_and_pin_lockout(self):
        headers={'X-OpenParsec-PIN':'12345678','Origin':self.url}
        with self.request('/api/settings',headers,json.dumps(c.DEFAULT).encode()) as r:self.assertEqual(r.status,200)
        for _ in range(5):
            with self.assertRaises(urllib.error.HTTPError):self.request('/api/settings')
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.request('/api/settings',headers)
        self.assertEqual(ctx.exception.code,429)
if __name__=='__main__':unittest.main()
