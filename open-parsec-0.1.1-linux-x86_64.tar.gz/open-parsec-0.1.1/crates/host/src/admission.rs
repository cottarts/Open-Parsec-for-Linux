//! The admission seam: four calls and an event queue.
//!
//! This is the whole of what a signaling implementation has to drive, and it is
//! deliberately poll based rather than callback based. A callback runs on our
//! thread, so an application that blocks in one stalls a media loop, and every
//! integration has to reason about which thread it is on. A queue the caller
//! drains moves that decision to the caller and keeps our threads ours.
//!
//! **Admission is the application's decision.** Nothing here applies policy
//! beyond capacity: no allow list, no interactive approval, no identity check.
//! Those live above the seam, where the information is.
//!
//! One socket per guest, bound by walking from the configured base. Concurrent
//! guests therefore occupy consecutive ports, because the socket punched for an
//! attempt becomes that guest's media socket for the whole session rather than
//! being handed back.

use core::sync::atomic::{AtomicU32, Ordering};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::{Arc, mpsc};

use lowlat_core::channel::{RecvRing, SlotMeta};
pub use lowlat_core::conn::Kind;
use lowlat_core::conn::{Conn, Credentials};

/// One thing signaling delivered for a running guest's engine.
#[derive(Debug, Clone, Copy)]
enum Arrival {
    /// An address to check, with the exchange's marking.
    Candidate(SocketAddr, Kind),
    /// The peer says it is bound and listening; translated-path checks may
    /// begin.
    PeerReady,
}
use lowlat_core::control::{self, CONTROL_CHANNEL, status};
use lowlat_core::endpoint::{Endpoint, Media};
use lowlat_core::envelope::{Cipher, Envelope};
use lowlat_core::send::{SendRing, SendSlot};
use lowlat_core::session::{DELIVERY_DEADLINE_MS, Session};
use lowlat_core::video::Rotation;
use lowlat_net::web::WebSession;
use lowlat_net::{Guest, Shell, Socket, Wake};

use crate::session::{Negotiation, State};
use crate::stream::{SeatHold, Seats, Stream};
use crate::video::Packetiser;
use lowlat_inject::event::{Extents, Injector, Place};
use lowlat_inject::uinput::Devices;

/// Video, stream 0. See docs/01-protocol.md section 6.
const VIDEO_CHANNEL: u8 = 1;
const AUDIO_CHANNEL: u8 = 2;

/// How long a session stays up after the peer has been told it is over.
///
/// **The reason rides a reliable channel**, so it is retransmitted if the
/// first attempt is lost. Tearing the session down on the pass that queued it
/// throws the message away with the ring it is sitting in, and the peer is
/// left to discover the disconnection from its own liveness deadline, which is
/// exactly what saying why was meant to avoid.
const KICK_GRACE_MS: f64 = 250.0;

/// What one fragment carries, and therefore what one ring slot holds.
///
/// **Derived from the datagram floor, not from the path.** The size a peer
/// accepts is not negotiated and cannot be, so the floor is the only size
/// entitled to be emitted before a probe has justified anything larger. A
/// slot wide enough for a bigger datagram is not free headroom: the slot
/// width *is* the fragment width, so widening it puts oversized datagrams on
/// a path nothing has measured, and a peer that cannot take one discards the
/// whole thing silently.
const BODY: usize = lowlat_core::DEFAULT_BODY;
const SLOT: usize = BODY;

/// Ring depths, per channel and direction.
///
/// **Sized from the largest frame the stream can produce**, not from control
/// traffic. The send window may never exceed the peer's ring depth
/// (docs/01-protocol.md section 7), which is also where the delivery gate's
/// top ceiling comes from, so the video ring is exactly that depth: anything
/// less would refuse a frame the gate had already admitted.
const VIDEO_SEND_SLOTS: usize = 4000;
/// Sound, which is fifty packets a second and never a burst.
///
/// **Four fragments a packet at the uncompressed rate**, times the queue a
/// guest may be behind by, times a margin. A window smaller than one packet
/// would refuse every one of them and the guest would simply be deaf.
const AUDIO_SEND_SLOTS: usize = 128;
/// Control we send is a handful of small messages per second.
const CONTROL_SEND_SLOTS: usize = 256;
/// Control we receive has to hold the peer's in-flight window plus whatever
/// single message is longest, and a long one is a real shape: a message of
/// several hundred fragments is recorded on this protocol.
const CONTROL_RECV_SLOTS: usize = 1024;

/// The longest inbound control message that will be taken: the user-data
/// ceiling plus its header, which is the largest message the protocol permits
/// a peer to send.
///
/// **A message longer than this ends the attempt**, because a take that does
/// not fit does not consume the message and the next pass reads the same one
/// forever. Sized below the ceiling, that turned a legal message into a dead
/// session; past the ceiling it is a peer this host cannot serve, and ending
/// beats stalling silently.
const MAX_INBOUND: usize =
    lowlat_core::control::USER_DATA_MAX + lowlat_core::control::CONTROL_HEADER_LEN;

/// How often the loop reports what it has gathered, in passes. Cheap, and only
/// reads state the loop already owns.
const REPORT_EVERY: u32 = 16;

/// The buttons the live-run probe watches for, as the whole-pad message packs
/// them: the two face buttons nearest the thumb.
const PROBE_CHORD: u16 = 0x1000 | 0x2000;

/// How long the probe asks for.
const PROBE_MS: f64 = 500.0;

/// How often a streaming guest says how it is doing, in milliseconds.
const PROGRESS_MS: f64 = 2000.0;

/// A 256-bit key and the four-byte nonce prefix that follows it.
const MATERIAL_LEN: usize = 36;

/// What the application must forward to the peer, or act on.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum Event {
    /// A local candidate, to be sent to the peer as it is found. Trickled, not
    /// batched: batching adds the slowest interface to every setup.
    Candidate {
        attempt: String,
        addr: SocketAddr,
        from_stun: bool,
        /// Whether the exchange should mark it lan: host candidates, and
        /// every IPv6 address -- there is no translation to negotiate on that
        /// family however the address was found, and marking it anything else
        /// sends the peer's one path-opening probe to an address that needs
        /// none. The application copies this and `from_stun` into its
        /// signaling verbatim and decides nothing.
        lan: bool,
    },
    /// Send the peer a candidate marked `sync`, once.
    ///
    /// It is a readiness marker rather than an address, and **a peer may
    /// withhold every real candidate until it arrives**, so a host that never
    /// emits one negotiates with a peer that never offers anything to check.
    /// Whatever address rides along is ignored by the receiver.
    Ready { attempt: String },
    /// Connectivity completed and media can flow.
    Established { attempt: String, addr: SocketAddr },
    /// The attempt is over, with the reason typed rather than a timeout.
    Ended { attempt: String, outcome: Outcome },
    /// A guest sent its application a message ([01 §11.1](01-protocol.md)).
    ///
    /// **Nothing here reads the body.** The sub-identifier and the text are an
    /// application's own protocol, and a host that interpreted either would be
    /// inventing one on its behalf (docs/05-host.md section 5).
    UserData { guest: u32, id: u32, text: Vec<u8> },
    /// What is being captured changed: a different output, or the same one at
    /// a different size.
    ///
    /// **Raised where the change happened**, by the loop that rebuilt around
    /// it. Nothing else knows which of the two it was, and an application left
    /// to notice by comparing what it last asked for is an application polling
    /// on a timer for something the host already knew.
    CaptureChanged {
        width: u32,
        height: u32,
        output: String,
    },
    /// The guest holding the pointer changed, or nobody holds it now.
    ///
    /// Only raised where one guest at a time may drive; with arbitration off
    /// there is no owner to change.
    InputOwnerChanged { guest: Option<u32> },
    /// The host cannot continue, and every guest has been told why.
    ///
    /// **The one event that is never dropped**, because a bounded queue that
    /// discards this discards the only explanation for everything that stopped
    /// working.
    Fatal { reason: i32 },
}

/// Why an attempt finished.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum Outcome {
    /// Negotiated, but no path was found. The only outcome that justifies
    /// escalating to a relay.
    ConnectivityFailed,
    /// The peer stopped answering. An established session learns this from the
    /// media path rather than from signaling, because a peer that closes a
    /// session it was using does not withdraw its offer.
    PeerGone,
    /// The browser pipe's security handshake did not complete, or the peer
    /// was not the one the credential exchange named, or its association
    /// ended with an error. A path existed; the pipe on it did not.
    HandshakeFailed,
    /// Nothing sent to the peer has been acknowledged for the delivery
    /// deadline, while there was something outstanding the whole time.
    ///
    /// **Distinct from [`Outcome::PeerGone`] because the peer is not
    /// necessarily gone.** It may still be acknowledging on the cadence and
    /// have stopped receiving, which satisfies every deadline that watches the
    /// inbound direction while the whole send window is retransmitted for as
    /// long as the session is allowed to last. The two are told apart only by
    /// whether a window moves, and a live run needs to know which it saw.
    Undeliverable,
    /// The peer said it was leaving, on the control channel.
    ///
    /// **Distinct from [`Outcome::PeerGone`], and it is the difference between
    /// a seat freed now and a seat freed two minutes from now.** Signaling
    /// carries nothing when a peer closes a session it was using, so without
    /// this the only thing that notices is the media path's liveness deadline,
    /// and the guest's port and its share of the bitrate budget stay spent
    /// until then. Repeated test connections exhaust capacity that way.
    ///
    /// Carries the status the peer left with, which in practice is zero.
    ///
    /// **Corrected 2026-08-30, and the correction is the useful part.** This
    /// said the number was the far end's account of its own failure -- that a
    /// peer which could not decode said so here. It does not. Measured against
    /// a real client made to fail: **a peer that leaves because something broke
    /// sends nothing at all** and the host learns it from the delivery deadline
    /// instead, while a peer that leaves cleanly sends this opcode with the
    /// argument **always zero**. The reference client emits literally
    /// `(10, 0, 0, 0)` and skips the message entirely unless its own status is
    /// still healthy.
    ///
    /// **The status travels the other way.** A host puts one here to tell a
    /// peer why it was ended, which is [`Outcome::Kicked`]'s number and is read
    /// by the far side. Reading the field inbound is still right -- it costs
    /// nothing, a peer is free to send one, and discarding a field because
    /// today's peers leave it zero is how a protocol gets read wrong later --
    /// but it is not a diagnosis of the far end and nothing should wait for
    /// one.
    PeerLeft(i32),
    /// Connected, then never said what it could decode.
    ///
    /// Distinct from [`Outcome::PeerGone`] on purpose: a peer that reached us
    /// and then sat silent is either not speaking this protocol or died in the
    /// handshake, and reporting that as a peer that went away sends the next
    /// diagnosis to the network rather than to the negotiation.
    NeverDeclared,
    /// The socket could not be driven any further.
    ///
    /// **Rare, and it is about this host rather than about the peer.** A
    /// datagram the path refuses is dropped like loss and never reaches here;
    /// what does is a socket that has stopped working, which no retry answers.
    TransportFailed,
    /// The control stream could not be read any further.
    ///
    /// A message that cannot be taken does not advance the channel, so this is
    /// terminal rather than a frame to skip.
    ControlStalled,
    /// The host ended it, and told the peer why.
    ///
    /// **The only outcome the peer is given a reason for.** Every other one
    /// here is something that happened to the session; this is a decision, and
    /// a decision the peer is not told about is indistinguishable from a host
    /// that stopped working.
    Kicked(i32),
}

/// Which pipe a peer speaks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum Transport {
    /// The native transport: authenticated records on the attempt socket.
    Bud,
    /// The browser's: a data channel, SCTP on DTLS, on the same socket.
    Web,
}

/// What the offer told us about the peer.
#[derive(Debug, Clone)]
pub struct Peer {
    pub ufrag: String,
    pub pwd: String,
    /// Media key material. Retained because the answer's key is ours, not
    /// theirs; this is kept for the legacy path and for logging its absence.
    pub aes256: Option<String>,
    /// Which pipe the offer asked for.
    pub transport: Transport,
    /// The peer's certificate digest, which a browser's offer carries and
    /// its handshake is checked against. A native peer's is not read.
    pub fingerprint: Option<String>,
    /// What this peer may drive, as signaling reported it.
    pub permissions: lowlat_inject::event::Permissions,
    /// Whether this peer owns the machine, which decides only one thing: it
    /// takes the pointer from another guest rather than waiting for it
    /// ([`crate::floor`]).
    pub owner: bool,
}

/// Credentials the answer carries back.
///
/// **Generated at approval, not at registration.** They are bound to the socket
/// that was just opened for this attempt, so generating them earlier binds them
/// to nothing and generating them per registration leaks state for attempts
/// that are never approved.
#[derive(Debug, Clone)]
pub struct HostCredentials {
    pub ufrag: String,
    pub pwd: String,
    pub fingerprint: String,
    pub aes256: String,
    /// The port this guest was actually bound to, which is not necessarily the
    /// configured one. Advertising the configured port when the bind walked
    /// produces a peer that answers checks and never establishes.
    pub port: u16,
}

/// What went wrong.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum Error {
    /// No attempt with that identifier. A race with teardown rather than a
    /// fault, and callers treat it as one.
    UnknownAttempt,
    /// Already at the configured guest limit.
    AtCapacity,
    /// The attempt has already been approved.
    AlreadyBegun,
    /// Withdrawn before it was registered, so it is over before it began.
    Withdrawn,
    /// A socket could not be opened, or a thread could not be spawned.
    Io,
    /// Entropy or key material.
    Crypto,
    /// A browser offered no certificate digest, or one that is not a
    /// SHA-256 digest. Nothing its handshake could be checked against.
    Fingerprint,
}

impl core::fmt::Display for Error {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        let text = match self {
            Self::UnknownAttempt => "no such attempt",
            Self::AtCapacity => "at the configured guest limit",
            Self::AlreadyBegun => "attempt already approved",
            Self::Withdrawn => "attempt was withdrawn before it was registered",
            Self::Io => "socket or thread could not be created",
            Self::Crypto => "credentials could not be produced",
            Self::Fingerprint => "the offer's certificate digest is missing or malformed",
        };
        f.write_str(text)
    }
}

impl std::error::Error for Error {}

/// One reflexive server name, resolved to one address per address family.
///
/// **One of each, not whichever the resolver put first.** A dual-stack name
/// answers with both, ordered by what this machine's own addressing prefers, so
/// taking the head alone gives a host with global IPv6 a v6 reflexive address
/// and no v4 one -- and a v4-only peer is then offered nothing from us that it
/// can reach.
///
/// Empty when the name does not resolve at all. What to do about that is the
/// caller's: a configuration call refuses while the caller can still fix it, a
/// service carries on, because an attempt with no reflexive server still
/// punches on whatever it gathered locally.
pub fn resolve_server(name: &str) -> Vec<SocketAddr> {
    let Ok(resolved) = std::net::ToSocketAddrs::to_socket_addrs(name) else {
        return Vec::new();
    };
    let resolved: Vec<SocketAddr> = resolved.collect();
    [
        resolved.iter().find(|addr| addr.is_ipv4()),
        resolved.iter().find(|addr| addr.is_ipv6()),
    ]
    .into_iter()
    .flatten()
    .copied()
    .collect()
}

/// How the host is configured.
#[derive(Debug, Clone)]
pub struct Config {
    /// The base every guest's bind walks from.
    pub base_port: u16,
    /// Advertised capacity, and the only policy this seam applies.
    pub max_guests: usize,
    /// Reflexive servers, consulted for our own mapped address.
    pub servers: Vec<SocketAddr>,
    /// Whether shared address space counts as a host candidate.
    ///
    /// **Off unless asked for.** It is reachable when both ends are behind the
    /// same carrier translation or on the same overlay network, and a wasted
    /// check for every peer that is not ([`lowlat_net::host_addresses`]).
    pub shared_address_space: bool,
    /// The media stream every guest is served from, or `None` for a host that
    /// admits guests and sends them nothing. Absent is what the seam's own
    /// tests use, so they need neither a thread nor a device.
    pub stream: Option<crate::stream::Config>,
    /// Where a guest's microphone goes.
    ///
    /// **Absent for a host that has nobody to hand it to.** The setting that
    /// says a microphone is accepted lives with the rest of sound; this is the
    /// other half of it, the place the samples are put once decoded.
    pub microphone: Option<crate::microphone::Sender>,
    /// Whether one guest at a time may drive the pointer
    /// ([`crate::floor`]). Off by default: one person driving is a
    /// configuration, not a law.
    pub exclusive_pointer: bool,
    /// **A live-run probe, and nothing a shipped host should run.** Nothing on
    /// this machine vibrates, so the only way to exercise the path back to a
    /// peer's controller without a game is to raise an effect ourselves. Holding
    /// A and B on a pad sends one, and zero half a second later.
    pub rumble_probe: bool,
    /// How long a guest keeps the pointer after its last movement, when
    /// [`Config::exclusive_pointer`] is set. Clamped into the bounds in
    /// [`crate::floor`].
    pub exclusive_hold_ms: f64,
    /// Which congestion control level every guest's controller runs at.
    ///
    /// **Level 0 is the most aggressive, not "off".** Its threshold of zero
    /// declares congestion on any stale fragment once the window exceeds the
    /// floor, and it exists for compatibility with an older scheme.
    pub cg_level: usize,
}

/// How many withdrawn attempts are remembered.
///
/// Small and fixed: this exists to catch a withdrawal that overtakes its own
/// offer, which is a race of a few messages, not a history.
const TOMBSTONES: usize = 16;

struct Attempt {
    peer: Peer,
    /// The peer has signalled it is ready. Recorded rather than acted on: the
    /// engine checks whatever candidates arrive whenever they arrive.
    peer_ready: bool,
    /// Buffered until approval, because candidates trickle and the peer starts
    /// sending them before the answer reaches it.
    pending: Vec<Arrival>,
    guest: Option<Guest>,
    inject: Option<mpsc::Sender<Arrival>>,
    /// Application messages waiting to go to this guest.
    ///
    /// **The body is built where the caller is**, so the thread serving the
    /// guest allocates nothing: what travels here is already the bytes that go
    /// on the wire, terminator included.
    say: Option<mpsc::Sender<Said>>,
    /// What the application has asked of this guest, once it is running.
    ask: Option<mpsc::Sender<Ask>>,
    /// What this guest is doing, written by its own thread.
    telemetry: Arc<Telemetry>,
    /// The small number this guest is addressed by, kept so a message can be
    /// aimed at it without walking every attempt's thread.
    number: Option<u32>,
}

/// What one guest is doing, published by its own thread and read by anyone.
///
/// **Atomics rather than a lock, because the writer is on a frame path.** The
/// guest's loop updates these every pass and a reader asks whenever it likes;
/// a lock here would put a reader's cadence on the writer's path. Nothing here
/// is read as a set, so a torn read across two fields is a snapshot taken a
/// pass apart rather than a wrong answer.
#[derive(Debug, Default)]
pub(crate) struct Telemetry {
    /// Milliseconds since this guest's loop began.
    connected_ms: AtomicU32,
    /// When each kind of input last arrived, on the same clock. Zero means it
    /// never has, which is what an application asking "idle for how long"
    /// needs to tell apart from "idle since the start".
    keyboard_ms: AtomicU32,
    pointer_ms: AtomicU32,
    gamepad_ms: AtomicU32,
    frames: AtomicU32,
    window: AtomicU32,
    stale: AtomicU32,
    /// Times the rate this guest is allowed dropped, which is what congestion
    /// costs it.
    ///
    /// **One counter, not one per channel.** Only the video channel is rate
    /// controlled, here and in every peer this talks to, so a per-channel
    /// count would promise two numbers that can never be anything but zero.
    cg_events: AtomicU32,
    /// The smoothed round trip, as `f32` bits: an atomic float is not portable
    /// and the bits are.
    ///
    /// **One figure for the whole session, not one per channel.** There is one
    /// path under all of them and one round trip along it.
    network_bits: AtomicU32,
    control: ChannelTelemetry,
    audio: ChannelTelemetry,
    video: ChannelTelemetry,
}

/// One channel's share of a guest's telemetry.
///
/// **The fields that genuinely differ between channels, and only those.** What
/// is the same across all of them -- the round trip, the input stamps, the
/// congestion count -- is held once by [`Telemetry`] rather than repeated
/// here, so a reader is never left deciding which copy is authoritative.
#[derive(Debug, Default)]
pub(crate) struct ChannelTelemetry {
    packets_sent: AtomicU32,
    fast_rts: AtomicU32,
    slow_rts: AtomicU32,
    /// Rates, as `f32` bits.
    bitrate_bits: AtomicU32,
    encode_bits: AtomicU32,
    decode_bits: AtomicU32,
}

/// Which of a guest's channels a figure belongs to.
///
/// **Three, because this host runs three.** Control, one video stream and
/// sound; there is no fourth to name and nothing indexes these by number.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Channel {
    Control,
    Audio,
    Video,
}

/// What one channel measured on a pass.
///
/// **A structure rather than five positional arguments**, because four of them
/// are counts of similar things and a transposition between two of them would
/// read correctly and report the wrong number forever.
#[derive(Debug, Clone, Copy, Default)]
pub(crate) struct ChannelSample {
    pub(crate) packets_sent: u64,
    pub(crate) fast_rts: u64,
    pub(crate) slow_rts: u64,
    pub(crate) mbps: f64,
    /// What this channel's payload cost to produce. Zero on control, which
    /// encodes nothing.
    pub(crate) encode_ms: f64,
}

impl Telemetry {
    fn store(cell: &AtomicU32, value: f64) {
        #[allow(
            clippy::cast_possible_truncation,
            reason = "a reported rate, whose precision beyond f32 nobody reads"
        )]
        cell.store((value as f32).to_bits(), Ordering::Relaxed);
    }

    fn load(cell: &AtomicU32) -> f32 {
        f32::from_bits(cell.load(Ordering::Relaxed))
    }

    /// What the loop measured this pass, for the session as a whole.
    ///
    /// The window and the stale count are the video channel's, because that is
    /// the channel the controller steers; `cg_events` is what that steering
    /// has cost so far.
    pub(crate) fn measured(&self, window: u32, stale: u32, cg_events: u32, srtt: f64) {
        self.window.store(window, Ordering::Relaxed);
        self.stale.store(stale, Ordering::Relaxed);
        self.cg_events.store(cg_events, Ordering::Relaxed);
        Self::store(&self.network_bits, srtt);
    }

    /// The same, for one channel. `mbps` arrives in the control path's
    /// mebibits and is stored as the decimal megabits the boundary reports.
    pub(crate) fn channel_measured(&self, at: Channel, sample: ChannelSample) {
        let cell = self.cell(at);
        cell.packets_sent
            .store(saturating(sample.packets_sent), Ordering::Relaxed);
        cell.fast_rts
            .store(saturating(sample.fast_rts), Ordering::Relaxed);
        cell.slow_rts
            .store(saturating(sample.slow_rts), Ordering::Relaxed);
        Self::store(
            &cell.bitrate_bits,
            crate::rate::to_decimal_mbps(sample.mbps),
        );
        Self::store(&cell.encode_bits, sample.encode_ms);
    }

    /// What the peer said one of its decoders costs it.
    ///
    /// **The peer's own number, stored rather than derived.** It is the one
    /// figure in a guest's telemetry this host cannot measure, and the only
    /// reason it can be reported at all is that the guest volunteers it.
    pub(crate) fn decoded(&self, at: Channel, ms: f64) {
        Self::store(&self.cell(at).decode_bits, ms);
    }

    fn cell(&self, at: Channel) -> &ChannelTelemetry {
        match at {
            Channel::Control => &self.control,
            Channel::Audio => &self.audio,
            Channel::Video => &self.video,
        }
    }

    /// Note that this guest's loop has begun, and when.
    pub(crate) fn began(&self) {
        self.connected_ms.store(1, Ordering::Relaxed);
    }

    /// Record how far into the session this guest is, and how many frames it
    /// has been sent.
    pub(crate) fn progressed(&self, now_ms: f64, frames: u32) {
        #[allow(
            clippy::cast_possible_truncation,
            clippy::cast_sign_loss,
            reason = "a session duration in milliseconds, which overflows after forty-nine days"
        )]
        self.connected_ms.store(now_ms as u32, Ordering::Relaxed);
        self.frames.store(frames, Ordering::Relaxed);
    }

    /// Stamp whichever kinds of input moved since the last pass.
    pub(crate) fn stamped(
        &self,
        before: &lowlat_inject::event::Tally,
        now: &lowlat_inject::event::Tally,
        now_ms: f64,
    ) {
        #[allow(
            clippy::cast_possible_truncation,
            clippy::cast_sign_loss,
            reason = "a session duration in milliseconds"
        )]
        let at = now_ms as u32;
        // **One, not zero, when a stamp lands at the very first millisecond.**
        // Zero is what "never" is written as, and an application cannot tell a
        // guest that has never touched the keyboard from one that touched it
        // as the session opened unless the two differ.
        let at = at.max(1);
        if now.keys != before.keys {
            self.keyboard_ms.store(at, Ordering::Relaxed);
        }
        if now.buttons != before.buttons
            || now.wheels != before.wheels
            || now.motions != before.motions
        {
            self.pointer_ms.store(at, Ordering::Relaxed);
        }
        if now.pads != before.pads {
            self.gamepad_ms.store(at, Ordering::Relaxed);
        }
    }

    /// A snapshot, as the boundary publishes it.
    pub(crate) fn read(&self) -> Metrics {
        Metrics {
            connected_ms: self.connected_ms.load(Ordering::Relaxed),
            keyboard_ms: self.keyboard_ms.load(Ordering::Relaxed),
            pointer_ms: self.pointer_ms.load(Ordering::Relaxed),
            gamepad_ms: self.gamepad_ms.load(Ordering::Relaxed),
            frames: self.frames.load(Ordering::Relaxed),
            window: self.window.load(Ordering::Relaxed),
            stale: self.stale.load(Ordering::Relaxed),
            cg_events: self.cg_events.load(Ordering::Relaxed),
            network_ms: Self::load(&self.network_bits),
            control: Self::read_channel(&self.control),
            audio: Self::read_channel(&self.audio),
            video: Self::read_channel(&self.video),
        }
    }

    fn read_channel(cell: &ChannelTelemetry) -> ChannelMetrics {
        ChannelMetrics {
            packets_sent: cell.packets_sent.load(Ordering::Relaxed),
            fast_rts: cell.fast_rts.load(Ordering::Relaxed),
            slow_rts: cell.slow_rts.load(Ordering::Relaxed),
            bitrate_mbps: Self::load(&cell.bitrate_bits),
            encode_ms: Self::load(&cell.encode_bits),
            decode_ms: Self::load(&cell.decode_bits),
        }
    }
}

/// A cumulative counter, narrowed to what a reader reports it in.
///
/// **Saturating rather than wrapping.** A count that wraps reads as a session
/// that just started, and the counts here climb for as long as a guest is
/// connected; pinning at the ceiling is wrong by a knowable amount, where a
/// wrap is wrong by an unknowable one.
fn saturating(count: u64) -> u32 {
    u32::try_from(count).unwrap_or(u32::MAX)
}

/// One channel's telemetry, as a reader sees it.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct ChannelMetrics {
    /// Distinct fragments put on the wire. **First transmissions only**, so
    /// the resend counters below divide into it as a loss rate.
    pub packets_sent: u32,
    /// Retransmissions the peer asked for, and retransmissions the timeout had
    /// to find. The two apart are the difference between a path that reports
    /// its losses and one that swallows them.
    pub fast_rts: u32,
    pub slow_rts: u32,
    pub bitrate_mbps: f32,
    /// What this channel's payload cost this host to produce. **Zero on
    /// control**, which encodes nothing.
    pub encode_ms: f32,
    /// What the peer says this channel costs it to decode.
    ///
    /// **The peer's figure, not ours.** Zero until it has volunteered one, and
    /// zero forever on control, which is not decoded.
    pub decode_ms: f32,
}

/// One guest's telemetry, as a reader sees it.
///
/// **Shared figures once, per-channel figures per channel.** The round trip,
/// the input stamps and the congestion count describe the guest; the counters
/// and rates describe one channel of it, and this host runs three. Nothing
/// here is indexed by number, because a number would be a stream index this
/// host does not have.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct Metrics {
    pub connected_ms: u32,
    /// When each kind of input last arrived, on the same clock as
    /// `connected_ms`. **Zero means never**, which is not the same as zero
    /// milliseconds ago.
    pub keyboard_ms: u32,
    pub pointer_ms: u32,
    pub gamepad_ms: u32,
    pub frames: u32,
    /// Fragments outstanding, and how many of those are past due. These are
    /// what the congestion controller reads, and together they are what
    /// "chronically behind" means.
    pub window: u32,
    pub stale: u32,
    /// Times congestion cost this guest rate. **Video only**: it is the one
    /// channel a rate controller steers.
    pub cg_events: u32,
    /// The smoothed round trip to this peer. **One path, one figure**, which
    /// is why it is here rather than repeated in each channel.
    pub network_ms: f32,
    pub control: ChannelMetrics,
    pub audio: ChannelMetrics,
    pub video: ChannelMetrics,
}

/// Something the application asked of one running guest.
///
/// **A channel rather than shared state**, for the same reason the outbound
/// messages use one: the guest's own thread is the only thing that may touch
/// its session or its input devices, so an ask is delivered to it rather than
/// applied behind its back.
#[derive(Debug)]
enum Ask {
    /// End this guest, telling it why on the way out.
    Kick(i32),
    /// Change what it may drive, from now on.
    Permissions(lowlat_inject::event::Permissions),
    /// Type the attention chord on this guest's own keyboard.
    SecureAttention,
}

/// One message on its way to a guest, built where the caller is.
///
/// **Two opcodes share this shape and it is not a coincidence.** An
/// application message and a roster are both a body with its length in the
/// first argument, one number in the second and nothing in the third; only
/// what the number means differs -- a sub-identifier for one, the recipient's
/// own guest number for the other.
#[derive(Debug)]
struct Said {
    opcode: u8,
    /// The second argument. Its meaning belongs to the opcode.
    a1: u32,
    /// Already terminated. The far side reads both as C strings.
    body: Vec<u8>,
}

/// One connected guest, as the seam knows it.
#[derive(Debug, Clone, PartialEq)]
pub struct GuestInfo {
    /// What this guest is addressed by, and what it finds itself in a roster
    /// by.
    pub number: u32,
    /// The identifier the application registered this attempt under.
    ///
    /// **The link between the seam's two halves.** Everything before a guest
    /// is seated is addressed by attempt and everything after is addressed by
    /// number, and without this an application holding a peer per attempt
    /// cannot tell which peer an event about guest three is about.
    pub attempt: String,
    pub permissions: lowlat_inject::event::Permissions,
    pub owner: bool,
    pub metrics: Metrics,
}

/// A body with the terminator a peer reads it as a C string by, exactly once.
fn terminated(text: &[u8]) -> Vec<u8> {
    let mut body = Vec::with_capacity(lowlat_core::control::string_body_len(text.len()));
    body.extend_from_slice(text.strip_suffix(&[0]).unwrap_or(text));
    body.push(0);
    body
}

/// The seam.
#[derive(Debug)]
pub struct Admission {
    config: Config,
    /// Started once, here, because every guest is served from the same encode
    /// (docs/05-host.md section 1) and the seam is what outlives them all.
    stream: Option<Stream>,
    attempts: HashMap<String, Attempt>,
    /// Attempts withdrawn before they were ever registered.
    withdrawn: Vec<String>,
    /// **Handed out once**, to whoever is going to consume it. A poll waits
    /// for as long as its caller asked, and the seam's own lock must not be
    /// held for that long, so the consumer holds the queue directly rather
    /// than reaching it through here (docs/06-api.md 8).
    events: Option<crate::events::Receiver>,
    emit: crate::events::Sender,
    /// Who has the pointer, shared by every guest thread.
    floor: crate::floor::Floor,
    /// **A small number for each guest, and the only identifier that is one.**
    /// An attempt identifier is sixty characters of service-assigned text: it
    /// is what logs correlate on and it is no use naming a device or a pointer
    /// holder, so both use this and one line at admission joins them.
    next_guest: u32,
}

impl core::fmt::Debug for Attempt {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("Attempt")
            .field("pending", &self.pending.len())
            .field("peer_ready", &self.peer_ready)
            .field("running", &self.guest.is_some())
            .finish()
    }
}

impl Admission {
    pub fn new(config: Config) -> Self {
        let (emit, events) = crate::events::queue();
        Self::raising(config, emit, Some(events))
    }

    /// The same, raising into a queue somebody else already holds.
    ///
    /// **For a caller that must be able to poll before there is a host.** An
    /// application starts its polling thread before it starts hosting, so the
    /// queue outlives any one seam rather than arriving with it -- and events
    /// raised on the way down survive the seam that raised them.
    pub fn raising(
        config: Config,
        emit: crate::events::Sender,
        events: Option<crate::events::Receiver>,
    ) -> Self {
        let stream = config
            .stream
            .clone()
            .map(|stream| Stream::announcing(stream, Some(emit.clone())));
        let floor = crate::floor::Floor::announcing(
            config.exclusive_pointer,
            config.exclusive_hold_ms,
            Some(emit.clone()),
        );
        Self {
            config,
            stream,
            attempts: HashMap::new(),
            withdrawn: Vec::new(),
            events,
            emit,
            floor,
            next_guest: 1,
        }
    }

    /// Guests currently admitted, which is what the advertisement publishes.
    pub fn occupancy(&self) -> usize {
        self.attempts.values().filter(|a| a.guest.is_some()).count()
    }

    /// An offer arrived. Register it; the application decides what happens next.
    pub fn new_attempt(&mut self, id: &str, peer: Peer) -> Result<(), Error> {
        // A withdrawal can overtake the offer it withdraws. Admitting one then
        // spends a socket and a thread on a guest that has already gone, and
        // nothing later arrives to say so.
        if let Some(at) = self.withdrawn.iter().position(|seen| seen == id) {
            self.withdrawn.remove(at);
            return Err(Error::Withdrawn);
        }
        if self.occupancy() >= self.config.max_guests {
            return Err(Error::AtCapacity);
        }
        // A browser is trusted by its digest and nothing else, so an offer
        // without one has nothing a handshake could be checked against.
        if peer.transport == Transport::Web
            && peer
                .fingerprint
                .as_deref()
                .is_none_or(|text| lowlat_crypto::cert::parse_fingerprint(text).is_err())
        {
            return Err(Error::Fingerprint);
        }
        self.attempts.insert(
            id.to_string(),
            Attempt {
                peer,
                peer_ready: false,
                pending: Vec::new(),
                guest: None,
                say: None,
                ask: None,
                telemetry: Arc::new(Telemetry::default()),
                number: None,
                inject: None,
            },
        );
        Ok(())
    }

    /// A candidate arrived for an attempt.
    ///
    /// **`sync` marks a readiness signal, not an address**, and the flag is
    /// taken rather than left to the caller because the address that rides on
    /// one is arbitrary: a peer is entitled to send a placeholder, and one does
    /// send a literal `1.2.3.4:1234`. Adding that to the table spends checks on
    /// an unrelated host on the public internet.
    ///
    /// Unknown attempts are a no-op rather than an error: an identifier that
    /// has just been torn down is a race with the peer, not a fault.
    pub fn add_candidate(&mut self, id: &str, addr: SocketAddr, sync: bool, kind: Kind) {
        let Some(attempt) = self.attempts.get_mut(id) else {
            return;
        };
        let arrival = if sync {
            attempt.peer_ready = true;
            Arrival::PeerReady
        } else {
            Arrival::Candidate(addr, kind)
        };
        match (&attempt.inject, &attempt.guest) {
            (Some(inject), Some(guest)) => {
                if inject.send(arrival).is_ok() {
                    // The loop waits on its own deadline, so an arrival that
                    // only lands in the queue is not seen until that expires.
                    let _ = guest.wake_handle().notify();
                }
            }
            // Before approval there is nowhere to put it but the buffer.
            _ => attempt.pending.push(arrival),
        }
    }

    /// The application approves. Bind, start connectivity, and hand back the
    /// credentials the answer carries.
    /// `port` is where the bind **starts**, not where it must land: it walks
    /// when the port is taken, exactly as the configured base does, and the
    /// port it reached comes back in [`HostCredentials::port`]. Zero asks for
    /// the configured base instead, which is what an application with no
    /// opinion passes.
    ///
    /// **An application with an opinion has one for a reason** -- a mapping it
    /// made on the gateway, a rule it opened on the firewall, a pool it is
    /// allocating from -- and none of those survive the SDK choosing for it.
    pub fn begin_p2p(&mut self, id: &str, port: u16) -> Result<HostCredentials, Error> {
        if self.occupancy() >= self.config.max_guests {
            return Err(Error::AtCapacity);
        }
        let attempt = self.attempts.get_mut(id).ok_or(Error::UnknownAttempt)?;
        if attempt.guest.is_some() {
            return Err(Error::AlreadyBegun);
        }

        let local = lowlat_crypto::credentials().map_err(|_| Error::Crypto)?;
        let seed = lowlat_crypto::transaction_seed().map_err(|_| Error::Crypto)?;
        let keying = match attempt.peer.transport {
            Transport::Bud => {
                // **Which cipher is the offer's own statement.** An offer that
                // carried a media key takes the 256-bit mode, keyed from ours;
                // one that did not comes from a generation with no such field,
                // and both ends key from this host's fingerprint under the
                // legacy 128-bit mode. The peer's own material is never the
                // key either way -- presence is the whole of what it says.
                let cipher = if attempt.peer.aes256.is_some() {
                    Cipher::Aes256
                } else {
                    Cipher::Aes128
                };
                let source = match cipher {
                    Cipher::Aes256 => &local.aes256,
                    Cipher::Aes128 => &local.fingerprint,
                };
                // **Key and nonce prefix together, and both are needed.** The
                // nonce is the credential's four-byte prefix followed by the
                // counter, never four zeros, so a session built from the key
                // alone seals records no peer can open and rejects every
                // record a peer sends. That looks exactly like a path that
                // established and carries nothing. The prefix follows the key,
                // so its offset moves with the cipher.
                let key_len = cipher.key_len();
                let (key, prefix) =
                    lowlat_crypto::key_material(source, key_len).map_err(|_| Error::Crypto)?;
                let mut material = [0u8; MATERIAL_LEN];
                material
                    .get_mut(..key_len)
                    .ok_or(Error::Crypto)?
                    .copy_from_slice(key.get(..key_len).ok_or(Error::Crypto)?);
                material
                    .get_mut(key_len..key_len + prefix.len())
                    .ok_or(Error::Crypto)?
                    .copy_from_slice(&prefix);
                if cipher == Cipher::Aes128 {
                    lowlat_common::log_info!(
                        "guest: attempt={} takes the legacy cipher, the offer carried no media key",
                        id
                    );
                }
                Keying::Bud { material, cipher }
            }
            // A browser's session keys itself in its handshake; what this side
            // holds is the digest the peer's certificate must carry.
            Transport::Web => {
                let expect = attempt
                    .peer
                    .fingerprint
                    .as_deref()
                    .and_then(|text| lowlat_crypto::cert::parse_fingerprint(text).ok())
                    .ok_or(Error::Fingerprint)?;
                lowlat_common::log_info!("guest: attempt={} takes the browser pipe", id);
                Keying::Web { expect }
            }
        };
        // The answer's digest: the process certificate's for a browser, which
        // pastes it into its own description, and the random material a
        // native peer keys the legacy cipher from.
        let fingerprint = match keying {
            Keying::Bud { .. } => local.fingerprint.clone(),
            Keying::Web { .. } => lowlat_crypto::cert::certificate()
                .map_err(|_| Error::Crypto)?
                .fingerprint_sdp(),
        };

        // Walks from where it was asked to start, so a second concurrent guest
        // lands on the next free port rather than failing to bind at all, and
        // **takes any port rather than refusing the guest** once the walk is
        // exhausted. Nothing advertises the port that was asked for: every
        // candidate is built from the address the socket reports, so landing
        // somewhere unexpected costs a mapping, not a session.
        let start = if port == 0 {
            self.config.base_port
        } else {
            port
        };
        let socket = Socket::open_or_any_port(start).map_err(|_| Error::Io)?;
        // **Where it landed, which is not necessarily where it was asked to
        // start.** Everything advertised is built from this.
        let bound = socket.local_addr().map_err(|_| Error::Io)?.port();
        let wake = Wake::new().map_err(|_| Error::Io)?;

        let (inject, arrivals) = mpsc::channel::<Arrival>();
        for arrival in attempt.pending.drain(..) {
            let _ = inject.send(arrival);
        }
        let (say, said) = mpsc::channel::<Said>();
        let (ask, asked) = mpsc::channel::<Ask>();
        let telemetry = Arc::clone(&attempt.telemetry);

        let attempt_id = id.to_string();
        let guest_number = self.next_guest;
        self.next_guest = self.next_guest.wrapping_add(1);
        let floor = self.floor.clone();
        let emit = self.emit.clone();
        let servers = self.config.servers.clone();
        let seats = self.stream.as_ref().map(Stream::seats);
        let video = self.config.stream.as_ref().map(|s| (s.width, s.height));
        let ours = (local.ufrag.clone(), local.pwd.clone());
        let theirs = (attempt.peer.ufrag.clone(), attempt.peer.pwd.clone());
        let permissions = attempt.peer.permissions;
        let owner = attempt.peer.owner;
        let rumble_probe = self.config.rumble_probe;
        let microphone = self.config.microphone.clone();

        let guest = Guest::spawn(wake, move |wake, running| {
            run_guest(
                Attached {
                    socket,
                    servers,
                    ours,
                    theirs,
                    keying,
                    seed,
                    driven: Driven {
                        attempt_id,
                        emit,
                        microphone,
                        arrivals,
                        said,
                        asked,
                        telemetry,
                        seats,
                        video,
                        guest: guest_number,
                        floor,
                        permissions,
                        owner,
                        rumble_probe,
                    },
                },
                wake,
                running,
            );
        })
        .map_err(|_| Error::Io)?;

        attempt.inject = Some(inject);
        attempt.guest = Some(guest);
        attempt.say = Some(say);
        attempt.ask = Some(ask);
        attempt.number = Some(guest_number);

        // **Gathered here rather than by the application.** Which local
        // addresses are worth offering is a connectivity decision with a rule
        // behind it, and an application that had to re-derive that rule would
        // get a different answer per integration. The port is the one that was
        // actually bound, which is not the one that was asked for as soon as a
        // second guest walks.
        for ip in lowlat_net::host_addresses(self.config.shared_address_space) {
            self.emit.send(Event::Candidate {
                attempt: id.to_string(),
                addr: SocketAddr::new(ip, bound),
                from_stun: false,
                lan: true,
            });
        }

        // **After the candidates it unblocks, which is the order a peer sends
        // in.** A captured exchange puts every real candidate on the wire first
        // and the marker a second later, last: it reads as "that is all of
        // mine, now yours" rather than "I am ready, begin". A peer entitled to
        // withhold its own candidates until it sees one is therefore entitled
        // to expect ours to have arrived by then ([04 §3](../../../docs/04-signaling.md)).
        self.emit.send(Event::Ready {
            attempt: id.to_string(),
        });

        Ok(HostCredentials {
            ufrag: local.ufrag,
            pwd: local.pwd,
            fingerprint,
            // **A legacy answer carries no media key**, and neither does a
            // browser's. The peer has no field to read one from, and the
            // empty string is the truth about the session rather than an
            // omission: a legacy attempt is keyed from the digest above and
            // a browser's keys itself.
            aes256: match keying {
                Keying::Bud {
                    cipher: Cipher::Aes256,
                    ..
                } => local.aes256,
                Keying::Bud { .. } | Keying::Web { .. } => String::new(),
            },
            port: bound,
        })
    }

    /// Rejection, withdrawal, disconnect, or reaping an attempt that has just
    /// reported it is over.
    ///
    /// **Emits nothing.** The queue carries what the application did not cause;
    /// this call is the application causing it, and reporting it back produced
    /// a second terminal event for an attempt that had already reported one.
    pub fn end_connection(&mut self, id: &str) {
        match self.attempts.remove(id) {
            Some(mut attempt) => {
                if let Some(guest) = attempt.guest.as_mut() {
                    guest.stop();
                }
            }
            // Withdrawn before it was ever registered. Remembered, because the
            // offer it withdraws may still be in flight behind it.
            None => {
                if !self.withdrawn.iter().any(|seen| seen == id) {
                    if self.withdrawn.len() >= TOMBSTONES {
                        self.withdrawn.remove(0);
                    }
                    self.withdrawn.push(id.to_string());
                }
            }
        }
    }

    /// The next event, or `None`. Never blocks.
    /// Send one guest an application message.
    ///
    /// **The body is built here, on the caller's thread.** What reaches the
    /// thread serving the guest is already the bytes that go on the wire, so
    /// nothing on the path to a peer allocates to send one.
    ///
    /// **The terminator is written whether or not the caller supplied one.**
    /// An established peer reads the body as a C string, so one that ends
    /// without it is read past; and a caller that supplied one must not be
    /// given two, because the length counts them both and the extra byte is
    /// then part of the message.
    ///
    /// Answers whether the guest is one that could be reached at all. A body
    /// past what a peer will accept is refused here rather than being sent and
    /// silently dropped at the far end.
    pub fn send_user_data(&mut self, guest: u32, id: u32, text: &[u8]) -> bool {
        if past_the_cap(text) {
            lowlat_common::log_warn!(
                "guest: refusing an application message of {} bytes for guest {guest}",
                text.len()
            );
            return false;
        }
        let Some(attempt) = self
            .attempts
            .values()
            .find(|attempt| attempt.number == Some(guest))
        else {
            return false;
        };
        let Some(say) = attempt.say.as_ref() else {
            return false;
        };
        say.send(Said {
            opcode: lowlat_core::control::op::USER_DATA,
            a1: id,
            body: terminated(text),
        })
        .is_ok()
    }

    /// Tell every guest who is connected.
    ///
    /// **The same body reaches all of them and the second argument does not**:
    /// each guest is sent its own number alongside, because that is how a peer
    /// finds itself in the list and learns what it is allowed to do. A roster
    /// with nobody's own number in it describes a room the reader is not in.
    ///
    /// The body is built by the caller. It is an encoding this layer has no
    /// business owning, and the crate that would parse it is deliberately
    /// outside the boundary.
    pub fn send_roster(&mut self, body: &[u8]) -> usize {
        let terminated = terminated(body);
        self.attempts
            .values()
            .filter_map(|attempt| Some((attempt.number?, attempt.say.as_ref()?)))
            .filter(|(number, say)| {
                say.send(Said {
                    opcode: lowlat_core::control::op::GUEST_LIST,
                    a1: *number,
                    body: terminated.clone(),
                })
                .is_ok()
            })
            .count()
    }

    /// Who is connected, as much as this layer knows.
    ///
    /// **Only what it decides.** A name, an avatar or an account are the
    /// application's to know; what belongs here is the number a guest is
    /// addressed by, what it is permitted to drive, and whether it owns the
    /// machine.
    /// End one guest, telling it why on the way out.
    ///
    /// **The reason is the protocol's own**, not this crate's: it reaches the
    /// peer as a disconnect status, and a peer carries on through a zero. What
    /// it costs is a message, a moment for it to arrive, and the seat.
    ///
    /// Answers whether there was a guest of that number to end.
    pub fn kick_guest(&mut self, guest: u32, reason: i32) -> bool {
        // Refused here, where the reason enters the ask channel, and not only
        // at the public boundary: a peer carries on through a zero status, so
        // a kick carrying one ends nobody and reads as a kick that worked.
        if reason == 0 {
            return false;
        }
        let Some(attempt) = self
            .attempts
            .values()
            .find(|attempt| attempt.number == Some(guest))
        else {
            return false;
        };
        attempt
            .ask
            .as_ref()
            .is_some_and(|ask| ask.send(Ask::Kick(reason)).is_ok())
    }

    /// Change what one guest may drive, while it is connected.
    ///
    /// **Recorded here and applied there.** The roster is answered from this
    /// side, so it has to know; the injector belongs to the guest's own thread,
    /// so that side is asked rather than reached into.
    ///
    /// Answers whether there was a guest of that number to change.
    pub fn set_permissions(
        &mut self,
        guest: u32,
        permissions: lowlat_inject::event::Permissions,
    ) -> bool {
        let Some(attempt) = self
            .attempts
            .values_mut()
            .find(|attempt| attempt.number == Some(guest))
        else {
            return false;
        };
        attempt.peer.permissions = permissions;
        attempt
            .ask
            .as_ref()
            .is_some_and(|ask| ask.send(Ask::Permissions(permissions)).is_ok())
    }

    /// Type the attention chord on one guest's own keyboard.
    ///
    /// **Asked rather than reached into**, like every other thing that touches
    /// a guest's devices: the injector belongs to that guest's thread.
    ///
    /// Answers whether there was a guest of that number to ask. Whether it was
    /// typed is that thread's answer and is said on its log line, because the
    /// keyboard permission is read there.
    pub fn secure_attention(&mut self, guest: u32) -> bool {
        let Some(attempt) = self
            .attempts
            .values()
            .find(|attempt| attempt.number == Some(guest))
        else {
            return false;
        };
        attempt
            .ask
            .as_ref()
            .is_some_and(|ask| ask.send(Ask::SecureAttention).is_ok())
    }

    pub fn guests(&self) -> Vec<GuestInfo> {
        let mut found: Vec<GuestInfo> = self
            .attempts
            .iter()
            .filter_map(|(id, attempt)| {
                Some(GuestInfo {
                    number: attempt.number?,
                    attempt: id.clone(),
                    permissions: attempt.peer.permissions,
                    owner: attempt.peer.owner,
                    metrics: attempt.telemetry.read(),
                })
            })
            .collect();
        // **Ordered, because a map is not.** A roster that reshuffles itself
        // every time it is sent is one a reader cannot diff.
        found.sort_by_key(|guest| guest.number);
        found
    }

    /// What size the stream is really producing, once it is known.
    ///
    /// Nothing until a display has been opened, which is the honest answer
    /// before then: the size is the display's to decide.
    pub fn picture(&self) -> Option<(u32, u32)> {
        self.stream.as_ref().and_then(Stream::picture)
    }

    /// What is being captured, as a checksum of its name.
    ///
    /// **The loop's answer, not the request's.** A guest can ask for one
    /// output and a display can move to another card on its own, and only the
    /// loop knows which of those happened last.
    pub fn captured(&self) -> u32 {
        self.stream.as_ref().map_or(0, Stream::captured)
    }

    /// What the running encoder codes, or nothing before one exists.
    pub fn colour(&self) -> Option<(crate::stream::Codec, bool, bool)> {
        self.stream.as_ref().and_then(crate::stream::Stream::colour)
    }

    /// Capture a different output, or the first one lit.
    ///
    /// **The seam forwards it and judges nothing.** Which outputs exist is the
    /// application's to look up ([`crate::display::Display::outputs`]) and a
    /// name that is not lit is refused where the display is opened, because
    /// that is the only place that can know.
    pub fn select_output(&self, id: Option<String>) {
        if let Some(stream) = self.stream.as_ref() {
            stream.select_output(id);
        }
    }

    /// Say where the captured picture sits in the desktop around it.
    ///
    /// **The one thing about the display that has to be told rather than
    /// read.** A display device reports a position inside its own framebuffer
    /// and knows nothing of the desktop that framebuffer belongs to, so this
    /// arrives from whatever is inside the session laying it out, and it is
    /// what a guest's absolute input is mapped against.
    pub fn set_place(&self, place: Option<lowlat_capture::desktop::Placement>) {
        if let Some(stream) = self.stream.as_ref() {
            stream.set_place(place);
        }
    }

    /// Which way the session has turned the captured output, as last told.
    ///
    /// **The stream's answer, which is the session's.** A caller that read the
    /// layout for itself would be asking the session over a socket a service
    /// account cannot reach, and would answer flat for a display that is not.
    pub fn rotation(&self) -> lowlat_core::video::Rotation {
        self.stream
            .as_ref()
            .map_or(lowlat_core::video::Rotation::None, Stream::rotation)
    }

    /// Send every guest the same application message.
    ///
    /// Answers how many it reached, which is not the guest count: one whose
    /// thread has already gone is not reachable and is not an error.
    pub fn send_user_data_all(&mut self, id: u32, text: &[u8]) -> usize {
        let guests: Vec<u32> = self.attempts.values().filter_map(|a| a.number).collect();
        guests
            .into_iter()
            .filter(|guest| self.send_user_data(*guest, id, text))
            .count()
    }

    pub fn poll_event(&mut self) -> Option<crate::events::Received> {
        self.events.as_ref()?.try_recv()
    }

    /// Change the video settings that do not need anything rebuilt.
    ///
    /// **The output is not one of them and travels separately.** A different
    /// output is a different picture, so it costs the rebuild an output change
    /// has always cost; everything else here reaches the running loop.
    pub fn set_video(&self, video: crate::stream::LiveVideo) {
        if let Some(stream) = self.stream.as_ref() {
            stream.set_video(video);
        }
    }

    /// Change what sound is set to, while a host runs.
    pub fn set_audio(&self, settings: &crate::stream::SoundSettings) {
        if let Some(stream) = self.stream.as_ref() {
            stream.set_audio(settings);
        }
    }

    /// What sound is set to now.
    ///
    /// **Asked of the stream rather than remembered here**, which is what makes
    /// a read-back the host's answer rather than a copy of the last call.
    pub fn audio(&self) -> crate::stream::SoundSettings {
        self.stream
            .as_ref()
            .map_or_else(Default::default, crate::stream::Stream::audio)
    }

    /// What sound is doing now, which is not what it is set to.
    pub fn audio_state(&self) -> (bool, Option<String>) {
        self.stream
            .as_ref()
            .map_or((false, None), crate::stream::Stream::sound_state)
    }

    /// What the stream is running at now.
    pub fn video(&self) -> Option<crate::stream::LiveVideo> {
        self.stream.as_ref().map(crate::stream::Stream::video)
    }

    /// Take the queue, so a caller can poll it without holding this.
    ///
    /// **Once, and then this stops answering.** Two consumers would each see
    /// part of the stream and each be told a different fraction of what was
    /// dropped, so the queue has one owner and handing it over is what makes
    /// that true rather than a rule somebody has to remember.
    pub fn take_events(&mut self) -> Option<crate::events::Receiver> {
        self.events.take()
    }
}

/// Everything one guest's loop owns for its lifetime.
/// How a guest's media half is keyed: the native cipher and its material,
/// or the digest a browser's certificate must carry.
#[derive(Debug, Clone, Copy)]
enum Keying {
    Bud {
        /// The key and the four-byte nonce prefix that follows it, packed
        /// at the front; the cipher says how much of it is key.
        material: [u8; MATERIAL_LEN],
        cipher: Cipher,
    },
    Web {
        expect: [u8; lowlat_crypto::cert::FINGERPRINT_LEN],
    },
}

/// What a guest thread is built from.
struct Attached {
    socket: Socket,
    servers: Vec<SocketAddr>,
    ours: (String, String),
    theirs: (String, String),
    keying: Keying,
    seed: [u8; 16],
    driven: Driven,
}

/// What the guest loop is driven by, whichever pipe carries it.
struct Driven {
    attempt_id: String,
    emit: crate::events::Sender,
    arrivals: mpsc::Receiver<Arrival>,
    /// Application messages the seam wants sent to this guest.
    said: mpsc::Receiver<Said>,
    /// What the application has asked of this guest.
    asked: mpsc::Receiver<Ask>,
    /// Where this guest publishes what it is doing.
    telemetry: Arc<Telemetry>,
    /// Where a guest's microphone goes, when this host takes one.
    microphone: Option<crate::microphone::Sender>,
    /// A way onto the stream, taken once this guest is streamable.
    seats: Option<Seats>,
    /// The stream's configured dimensions, which the video header carries
    /// until the picture's own are known.
    video: Option<(u32, u32)>,
    /// This guest's small number, used where a name has to be short.
    guest: u32,
    /// Who has the pointer.
    floor: crate::floor::Floor,
    /// What this guest may drive.
    permissions: lowlat_inject::event::Permissions,
    /// Whether it may take the pointer from another guest.
    owner: bool,
    /// The live-run rumble probe.
    rumble_probe: bool,
}

/// Lend one channel's receive storage to the session.
fn attach_recv<'a>(
    session: &mut Session<'a>,
    channel: u8,
    bodies: &'a mut [u8],
    meta: &'a mut [SlotMeta],
) -> bool {
    match RecvRing::new(bodies, meta, SLOT) {
        Ok(ring) => session.attach_recv(channel, ring).is_ok(),
        Err(_) => false,
    }
}

/// Lend one channel's send storage to the session.
fn attach_send<'a>(
    session: &mut Session<'a>,
    channel: u8,
    bodies: &'a mut [u8],
    meta: &'a mut [SendSlot],
) -> bool {
    match SendRing::new(bodies, meta, SLOT, channel) {
        Ok(ring) => session.attach_send(channel, ring).is_ok(),
        Err(_) => false,
    }
}

/// Take everything the peer has said on the control channel.
///
/// **A take that fails is terminal.** The channel only advances when a message
/// is consumed, so a body that does not fit or a prefix that does not parse
/// would be read again on the next pass and every pass after it, at full
/// speed. Ending the attempt reports what a silent spin would not.
/// Notice that this guest no longer has the pointer, and let go of what it
/// was holding with it.
///
/// **This is the whole reason the check is on a timer rather than on a
/// message.** A guest loses the pointer by going quiet, so there is no message
/// of its own to answer, and the release it eventually sends would arrive
/// after somebody else had taken over and be dropped for want of the pointer.
/// A button would stay down on a machine that guest is no longer driving.
fn follow_pointer<S: lowlat_inject::event::Sink>(
    input: &mut Input<S>,
    floor: &crate::floor::Floor,
    guest: u32,
    now_ms: f64,
) {
    // **A button that is still down keeps the pointer.** A guest mid-drag
    // sends nothing while it pauses, so time alone cannot tell a gesture that
    // ended from one that paused; the button can. Without this a pause of half
    // a second hands the cursor to somebody else and takes the first guest's
    // button away in the middle of its own drag.
    if input.injector.holds_pointer_button() {
        floor.refresh(guest, now_ms);
    }
    let holds = floor.holds(guest, now_ms);
    input.injector.set_floor(holds, &mut input.sink);
}

/// What a guest needs to ask for the pointer.
#[derive(Debug, Clone, Copy)]
struct Pointer<'a> {
    floor: &'a crate::floor::Floor,
    guest: u32,
    owner: bool,
    now_ms: f64,
}

/// Opcodes that move the pointer, and so ask for it.
///
/// **Only these.** Keyboards do not conflict the way pointers do and pads are
/// each their own device, so arbitrating either would stop two people using
/// one session for no gain (docs/05-host.md section 7.1).
const fn moves_the_pointer(opcode: u8) -> bool {
    matches!(
        opcode,
        control::op::MOUSE_BUTTON
            | control::op::MOUSE_WHEEL
            | control::op::MOUSE_MOTION
            | control::op::MOUSE_MOTION_STREAM
    )
}

/// Where a taken message goes, beyond the parts that steer input.
///
/// **Bundled because they arrive together and mean nothing apart**: what was
/// counted, what the application is told, and what a guest's microphone is
/// decoded into.
struct Consumers<'a> {
    count: &'a mut u64,
    said: &'a mut dyn FnMut((u32, Vec<u8>)),
    ear: Option<&'a mut crate::microphone::Ear>,
    /// Which opcodes this peer has been seen to send.
    ///
    /// **So that what a peer sends can be read rather than guessed at.** An
    /// opcode nothing here handles is passed over in silence, which is right --
    /// the protocol is additive -- but it leaves no way to tell "the peer sent
    /// nothing" from "the peer sent something we ignored", and those two have
    /// completely different causes.
    census: &'a mut [bool; 256],
    /// Where a figure only the peer can measure is recorded.
    telemetry: &'a Telemetry,
}

fn drain_control<M: Media, S: lowlat_inject::event::Sink>(
    session: &mut M,
    negotiation: &mut Negotiation,
    mut input: Option<&mut Input<S>>,
    pointer: Pointer<'_>,
    inbound: &mut [u8],
    consumers: Consumers<'_>,
) -> Result<(), Outcome> {
    let Consumers {
        count,
        said,
        mut ear,
        census,
        telemetry,
    } = consumers;
    loop {
        let Some(taken) = session.take_message(CONTROL_CHANNEL, inbound) else {
            return Ok(());
        };
        let Ok(len) = taken else {
            return Err(Outcome::ControlStalled);
        };
        // Counted where it is consumed, so the figure says what the peer sent
        // rather than what parsed.
        *count += 1;
        // A body we cannot parse is skipped rather than fatal: it has already
        // been consumed, so the channel is still moving.
        let Some(content) = inbound.get(..len) else {
            return Err(Outcome::ControlStalled);
        };
        let Ok(message) = control::parse(content) else {
            continue;
        };
        // **A peer that is leaving says so here.** Nothing in signaling
        // reports it, so this message is the only prompt notice there is.
        if message.opcode == control::op::DISCONNECT {
            // **The argument is read, not just the opcode.** It is a status
            // and a negative one is the far side reporting a fault of its own.
            return Err(Outcome::PeerLeft(i32::from_ne_bytes(
                message.a0.to_ne_bytes(),
            )));
        }
        // **Handed on rather than read.** The sub-identifier and the body are
        // an application's own protocol, and a host that acted on either would
        // be inventing one for it (docs/05-host.md section 5). It is offered
        // to the application and to nothing else here.
        if let Some((id, text)) = control::user_data(&message) {
            said((id, text.to_vec()));
        }
        // **What the peer says its decoder costs it**, which is the one number
        // in a guest's telemetry no host can measure. The arguments are
        // transposed against the outbound form -- microseconds first, then the
        // kind -- and reading it with the outbound layout yields a latency of
        // nothing.
        //
        // **Kind zero is taken as video.** An older peer reports one and names
        // no kind at all; accepting it recovers a figure that would otherwise
        // be discarded, and no peer sends a zero meaning anything else.
        if message.opcode == control::op::ENCODE_LATENCY {
            let ms = f64::from(message.a0) / 1000.0;
            match message.a1 {
                0 | 1 => telemetry.decoded(Channel::Video, ms),
                2 => telemetry.decoded(Channel::Audio, ms),
                _ => {}
            }
        }
        // **Said once per opcode, not once per message.** A peer sends tens of
        // thousands of these; what is worth a line is the first of each kind.
        if let Some(first) = census.get_mut(usize::from(message.opcode))
            && !*first
        {
            *first = true;
            lowlat_common::log_info!(
                "guest: peer sends {}({}) a0={} a1={} a2={} body={}",
                control::op::name(message.opcode),
                message.opcode,
                message.a0,
                message.a1,
                message.a2,
                message.body.len()
            );
        }
        // **A guest's microphone, when this host said it would take one.**
        // Absent when it did not, so nothing is decoded for a stream nobody
        // asked for.
        if let Some(ear) = ear.as_deref_mut() {
            ear.hear(&message);
        }
        // **Two consumers, one channel, and no opcode belongs to both.** Each
        // ignores what the other handles, which is why both are offered every
        // message rather than one being given first refusal: ordering them
        // would look like it mattered and nothing would ever exercise it.
        let _ = negotiation.on_control(&message);
        if let Some(input) = input.as_deref_mut() {
            // **Asking is the same as using it.** A guest holds the pointer
            // because it is moving something, and this is the only evidence
            // of that there is.
            if moves_the_pointer(message.opcode) {
                let holds = pointer
                    .floor
                    .claim(pointer.guest, pointer.owner, pointer.now_ms);
                input.injector.set_floor(holds, &mut input.sink);
            }
            input.injector.on_control(&message, &mut input.sink);
        }
    }
}

/// Pass on what the peer declared, and any reinitialization it asked for.
///
/// **Declared first, then the request.** The loop reads every seat's flags
/// when it takes a reinitialization request, so a request that arrived ahead
/// of the flags it is asking for would be answered against the old ones.
///
/// **Taken rather than read**, so one request produces one reinitialization
/// however many times the loop passes before the encoder acts on it.
fn forward_declaration(negotiation: &mut Negotiation, seat: Option<&SeatHold>, declared: &mut u32) {
    let Some(seat) = seat else { return };
    let flags = negotiation.flags();
    if flags != *declared {
        *declared = flags;
        seat.declare(flags);
    }
    if negotiation.take_reconfigure() {
        lowlat_common::log_info!("guest: peer asked to reinitialize, flags={flags:#x}");
        seat.request_reconfigure();
    }
}

/// Ask a peer's controller to vibrate.
fn send_rumble<M: Media>(session: &mut M, pad: u32, large: u8, small: u8) {
    send_control(
        session,
        &control::Control {
            a0: pad,
            a1: u32::from(large),
            a2: u32::from(small),
            opcode: control::op::RUMBLE,
            body: &[],
        },
    );
}

/// Whether a body built from this text is past what a peer will take.
///
/// **The terminator counts toward the ceiling**, because it is part of the
/// body that travels: a text of exactly the maximum makes a body one over it.
fn past_the_cap(text: &[u8]) -> bool {
    lowlat_core::control::string_body_len(text.len()) > lowlat_core::control::USER_DATA_MAX
}

/// Send one message that was built elsewhere.
///
/// **The body is written as it was handed over.** Building it belongs where
/// the caller is, so nothing on this thread allocates to send one, and the
/// terminator a peer reads it as a C string by is already there.
fn send_said<M: Media>(session: &mut M, message: &Said) {
    send_control(
        session,
        &control::Control {
            // **The length counts the terminator**, which is what a reader
            // treating this as a C string needs, and a body sized by the text
            // alone leaves it reading one byte past what arrived.
            a0: u32::try_from(message.body.len()).unwrap_or(u32::MAX),
            a1: message.a1,
            a2: 0,
            opcode: message.opcode,
            body: &message.body,
        },
    );
}

/// Tell the peer the session is over, and why.
///
/// **Sent before the session is torn down, not after.** The message rides the
/// control channel like any other and needs a turn of the shell to reach the
/// wire; a caller that returns immediately drops it.
fn send_disconnect<M: Media>(session: &mut M, reason: i32) {
    #[allow(
        clippy::cast_sign_loss,
        reason = "the status is a signed value carried in an unsigned argument, and the peer                   reads it back as signed"
    )]
    send_control(
        session,
        &control::Control {
            a0: reason as u32,
            a1: 0,
            a2: 0,
            opcode: control::op::DISCONNECT,
            body: &[],
        },
    );
}

/// Notice that the stream's encoder was rebuilt underneath this guest.
///
/// **A new encoder is a new reference chain and a new set of parameter sets.**
/// The peer learns that from the generation the video header carries, so the
/// generation moves here and the announcement follows on the next frame,
/// exactly as it does when a guest first takes a seat. A guest that never
/// noticed would keep naming the encoder that no longer exists.
fn follow_epoch(
    negotiation: &mut Negotiation,
    packetiser: Option<&mut Packetiser>,
    seat: Option<&SeatHold>,
    seen: &mut u32,
) {
    let (Some(seat), Some(packetiser)) = (seat, packetiser) else {
        return;
    };
    let epoch = seat.epoch();
    if epoch == *seen {
        return;
    }
    *seen = epoch;
    // **The depth is taken from the encoder that just replaced the old one**,
    // not from what this guest was admitted with. A reinitialisation is
    // exactly when it can change, and the header a peer builds its decoder
    // from is the only place it is said.
    packetiser.set_ten_bit(seat.ten_bit());
    packetiser.reconfigured();
    negotiation.encoder_initialised(packetiser.generation());
    lowlat_common::log_info!(
        "guest: encoder reinitialised, generation={}",
        packetiser.generation()
    );
}

/// Queue everything the stream has published to this guest.
///
/// **A refusal is a lost frame and it is reported, never swallowed.** The gate
/// admitted this frame against a window it read one frame ago, so a transport
/// that has moved since can still refuse it; the whole message is refused
/// rather than truncated, so the next predicted frame would reference a
/// picture the peer never received. Only the gate may latch, and the gate is
/// on the stream's thread, so the guest says so and the stream acts on it.
fn send_frames<M: Media>(
    session: &mut M,
    seat: &SeatHold,
    packetiser: &mut Packetiser,
    negotiation: &mut Negotiation,
) -> u64 {
    let mut sent = 0u64;
    while let Some(frame) = seat.next_frame() {
        let keyframe = frame.keyframe();
        let Some(header) = packetiser.header(keyframe) else {
            seat.missed_frame();
            continue;
        };
        if session
            .send_message(VIDEO_CHANNEL, header, frame.bytes())
            .is_err()
        {
            seat.missed_frame();
            continue;
        }

        // What the frame owes the peer beyond the picture: the generation,
        // once after an initialisation. The latency figure is on the clock
        // rather than on the frame, and goes out from the loop.
        sent += 1;
        let reports = negotiation.on_frame(seat.encode_latency_ms());
        if let Some(message) = reports.generation_message(0) {
            lowlat_common::log_info!(
                "guest: first video generation={} bytes={} keyframe={} header={:02x?} nal_prefix={:02x?}",
                message.a1,
                frame.bytes().len(),
                u8::from(keyframe),
                header,
                &frame.bytes()[..frame.bytes().len().min(16)]
            );
            send_control(session, &message);
        }
    }
    sent
}

/// Hand this guest whatever sound has been published to it.
///
/// **Refused rather than retransmitted.** The channel is reliable and ordered,
/// so a packet dropped after it is numbered is a gap the peer waits on; a
/// window with no room for the whole message means this packet is discarded and
/// the next one takes its place. Nothing is latched and no refresh is owed,
/// because no packet depends on the one before it.
///
/// Reports what it sent and what it had to drop, because **the two together
/// are the only place sound appears in a live run**: the picture's numbers say
/// nothing about it, and a refusal here is invisible on the wire by design.
fn send_audio<M: Media>(session: &mut M, seat: &SeatHold, raw: bool, sound: &mut AudioSent) {
    let header = crate::audio::header(raw);
    while let Some(packet) = seat.next_audio() {
        if session
            .send_message(AUDIO_CHANNEL, &header, packet.bytes())
            .is_err()
        {
            // Popped and refused is a packet gone: nothing puts it back, and
            // the next one takes its place.
            sound.dropped = sound.dropped.saturating_add(1);
            return;
        }
        sound.packets = sound.packets.saturating_add(1);
    }
}

/// What this guest's sound has cost so far.
#[derive(Debug, Default)]
struct AudioSent {
    packets: u64,
    dropped: u64,
}

/// Queue one control message.
///
/// A refusal is dropped rather than reported: everything sent this way is a
/// cadence that repeats, so a message lost to a full control window is
/// replaced by the next one rather than being worth a retry of its own.
fn send_control<M: Media>(session: &mut M, message: &control::Control<'_>) {
    let mut header = [0u8; control::CONTROL_HEADER_LEN];
    let Ok(written) = control::encode_header(&mut header, message) else {
        return;
    };
    let Some(head) = header.get(..written) else {
        return;
    };
    let _ = session.send_message(CONTROL_CHANNEL, head, message.body);
}

/// Throughput on the video channel, as the rate controller wants it.
///
/// **Mebibits per second over a measured interval**, and the interval has to
/// be long enough to mean something: sampled every pass, most intervals are a
/// fraction of a millisecond and the figure is noise. Held between recomputes
/// rather than reported as zero, because zero is a claim the path carried
/// nothing.
#[derive(Debug, Default)]
struct Throughput {
    last_bytes: u64,
    last_ms: f64,
    mbps: f64,
}

impl Throughput {
    /// The shortest interval worth dividing by. Half a second is also the
    /// period the controller's increase runs on at sixty frames a second.
    const INTERVAL_MS: f64 = 500.0;

    fn sample(&mut self, bytes: u64, now_ms: f64) -> f64 {
        let elapsed = now_ms - self.last_ms;
        if elapsed < Self::INTERVAL_MS {
            return self.mbps;
        }
        let moved = bytes.saturating_sub(self.last_bytes);
        // Mebibits, not megabits. The controller's peak is compared against
        // this, so the unit has to be the one it was tuned in.
        #[allow(
            clippy::cast_precision_loss,
            reason = "a byte count over half a second; f64 is exact far past it"
        )]
        let bits = (moved * 8) as f64;
        self.mbps = bits / 1_048_576.0 / (elapsed / 1000.0);
        self.last_bytes = bytes;
        self.last_ms = now_ms;
        self.mbps
    }
}

/// No injection, for the paths and the tests that do not have any.
///
/// Named rather than spelled out at each call, because `None` alone leaves the
/// sink's type for the caller to invent.
#[cfg(test)]
const NO_INPUT: Option<&mut Input<Devices>> = None;

/// A guest's virtual devices and the state of what it is holding on them.
///
/// **Kept together because neither half is useful alone**, and because the two
/// have the same lifetime: the devices are created when the guest is admitted
/// and destroyed when its thread returns.
///
/// **Generic over where the events go** so the routing above it can be tested
/// against a recorder rather than against the running session's real devices.
/// The guest thread only ever builds the one variant.
struct Input<S> {
    injector: Injector,
    sink: S,
}

impl Input<Devices> {
    /// Create a guest's devices, or report why not and carry on without them.
    ///
    /// **A session without input is worth more than no session.** Every reason
    /// this fails is a deployment problem on the host rather than anything the
    /// peer did, and refusing the guest would report it as a connection
    /// failure to the one party who cannot fix it.
    fn open(label: &str, video: Option<(u32, u32)>) -> Option<Self> {
        let (width, height) = video?;
        // **Not placed yet, and it does not have to be.** A guest is seated
        // before the loop has opened a display, so the layout is not known
        // here; the loop below picks it up on the pass after it is.
        let extents = desktop_extents(width, height, Rotation::None, None);
        match Devices::create(label) {
            Ok(devices) => Some(Self {
                injector: Injector::new(extents),
                sink: devices,
            }),
            Err(error) => {
                lowlat_common::log_warn!(
                    "inject: no devices for this guest, input is off, error={error}"
                );
                None
            }
        }
    }
}

/// The extents a peer's absolute coordinates arrive in, and where they land.
///
/// **The output's shape, not the encoded frame's**, and on a quarter turn
/// those differ. A peer swaps the dimensions the stream declares before it
/// transforms a pointer position, because what it is looking at is the desktop
/// rather than the buffer, so the coordinates arrive already in that
/// orientation. The host therefore swaps the extents it maps into and rotates
/// nothing. Rotating here as well turns the pointer through a right angle and
/// looks almost right, which is the worst way for it to be wrong.
///
/// **The rectangle needs no turning for the same reason.** It is measured in
/// the desktop the peer is looking at, which is already in that orientation.
fn desktop_extents(width: u32, height: u32, rotation: Rotation, place: Option<Place>) -> Extents {
    let (width, height) = match rotation {
        Rotation::Deg90 | Rotation::Deg270 => (height, width),
        _ => (width, height),
    };
    match place {
        Some(place) => Extents::placed(width, height, place),
        None => Extents::alone(width, height),
    }
}

/// One guest's loop, from approval until teardown.
///
/// Everything it borrows is owned here, on this thread, which is what lets the
/// endpoint hold references into storage allocated once at the top.
fn run_guest(args: Attached, wake: Wake, running: &lowlat_net::Running) {
    let Attached {
        socket,
        servers,
        ours,
        theirs,
        keying,
        seed,
        driven,
    } = args;
    let mut conn = Conn::new(
        Credentials {
            local_ufrag: &ours.0,
            local_pwd: &ours.1,
            remote_ufrag: &theirs.0,
            remote_pwd: &theirs.1,
        },
        seed,
        0.0,
    );
    for server in &servers {
        let _ = conn.add_server(*server);
    }

    match keying {
        Keying::Bud { material, cipher } => {
            // Allocated once, here, and lent to the rings for the life of the
            // thread. **Video receive is absent on purpose**: video is host to
            // guest only, and the group acknowledgement reports zero for an
            // unattached channel, which is the truth about a channel the peer
            // never sends on.
            let mut control_recv_bodies = vec![0u8; SLOT * CONTROL_RECV_SLOTS];
            let mut control_recv_meta = vec![SlotMeta::default(); CONTROL_RECV_SLOTS];
            let mut control_send_bodies = vec![0u8; SLOT * CONTROL_SEND_SLOTS];
            let mut control_send_meta = vec![SendSlot::default(); CONTROL_SEND_SLOTS];
            let mut video_send_bodies = vec![0u8; SLOT * VIDEO_SEND_SLOTS];
            let mut video_send_meta = vec![SendSlot::default(); VIDEO_SEND_SLOTS];
            // **Sound gets its own window, because it is its own channel.**
            // Sized for the deepest packet either codec produces times the
            // queue a guest may be behind by, which is a fifth of a second.
            let mut audio_send_bodies = vec![0u8; SLOT * AUDIO_SEND_SLOTS];
            let mut audio_send_meta = vec![SendSlot::default(); AUDIO_SEND_SLOTS];

            let Ok(envelope) = Envelope::from_credential(&material, cipher) else {
                return;
            };
            let mut session = Session::new(envelope, 1, 0.0);
            if !attach_recv(
                &mut session,
                CONTROL_CHANNEL,
                &mut control_recv_bodies,
                &mut control_recv_meta,
            ) || !attach_send(
                &mut session,
                CONTROL_CHANNEL,
                &mut control_send_bodies,
                &mut control_send_meta,
            ) || !attach_send(
                &mut session,
                VIDEO_CHANNEL,
                &mut video_send_bodies,
                &mut video_send_meta,
            ) || !attach_send(
                &mut session,
                AUDIO_CHANNEL,
                &mut audio_send_bodies,
                &mut audio_send_meta,
            ) {
                return;
            }
            let shell = Shell::new(socket, wake, Endpoint::new(conn, session));
            drive(driven, shell, running);
        }
        Keying::Web { expect } => {
            let session = match WebSession::client(expect, 1, 0.0) {
                Ok(session) => session,
                Err(error) => {
                    lowlat_common::log_error!(
                        "guest: attempt={} has no browser session, error={error}",
                        driven.attempt_id
                    );
                    return;
                }
            };
            let shell = Shell::new(socket, wake, Endpoint::new(conn, session));
            drive(driven, shell, running);
        }
    }
}

/// The guest loop, on whichever pipe the shell carries.
///
/// Everything here is written against the media seam and nothing else, so
/// the loop that drives a native session and the loop that drives a
/// browser's are this one function instantiated twice.
fn drive<M: Media>(args: Driven, mut shell: Shell<'_, M>, running: &lowlat_net::Running) {
    let mut inbound = vec![0u8; MAX_INBOUND];
    args.telemetry.began();
    let mut reported: Vec<SocketAddr> = Vec::new();
    // The negotiation, from the moment the media path exists. Absent before
    // that, because the five-second deadline runs from there and not from
    // approval: a peer cannot declare itself over a path it does not have.
    let mut negotiation: Option<Negotiation> = None;
    // A place on the stream, taken once this guest has declared itself. Held
    // for the rest of the session and given back by dropping it.
    let mut seat: Option<SeatHold> = None;
    let mut packetiser = args.video.map(|(width, height)| {
        Packetiser::new(
            u16::try_from(width).unwrap_or(u16::MAX),
            u16::try_from(height).unwrap_or(u16::MAX),
            // Flat until the session says which way the display is turned,
            // which arrives with the placement below.
            Rotation::None,
            // Eight bits until a seated guest asks otherwise and an encoder
            // is rebuilt for it; the consensus is what will supply this.
            false,
        )
    });
    // **Created here, at admission, rather than when the first key arrives.**
    // A device takes a fifth of a second to become usable and there is nothing
    // to wait on; starting now puts that behind connectivity and session
    // initialization, which are longer, so it costs nothing anybody can see.
    let mut input = Input::open(&args.guest.to_string(), args.video);
    if let Some(input) = input.as_mut() {
        // **The one line that joins the two identifiers.** Everything else
        // logs the attempt, and a device name and a pointer holder both need
        // something short; this is where a support question crosses between
        // them.
        lowlat_common::log_info!(
            "guest: number={} attempt={} owner={} keyboard={} pointer={} gamepad={}",
            args.guest,
            args.attempt_id,
            u8::from(args.owner),
            u8::from(args.permissions.keyboard),
            u8::from(args.permissions.pointer),
            u8::from(args.permissions.gamepad)
        );
        input
            .injector
            .set_permissions(args.permissions, &mut input.sink);
    }
    // A reason the application gave for ending this guest, waiting for the one
    // path below that knows how to end one.
    let mut asked_kick: Option<i32> = None;
    // What the tally said last pass, so a stamp is written when input arrived
    // rather than on every pass regardless.
    let mut counted = lowlat_inject::event::Tally::default();
    let mut throughput = Throughput::default();
    // What the peer acknowledged receiving, sampled on the same interval as
    // what it was offered. The two apart are the loss picture.
    let mut delivered = Throughput::default();
    // What this guest has been told about the pointer, and what it holds.
    let mut pointer = crate::cursor::Sender::new();
    let mut declared = false;
    // What was last published to the seat, so a declaration that has not moved
    // is not republished on every pass.
    let mut declared_flags = 0u32;
    // The picture size this guest is describing, once the stream has settled
    // on one.
    let mut followed: Option<(u16, u16)> = None;
    // Where that picture sits in the desktop, once a session has said.
    let mut placed: Option<Place> = None;
    // Which way the session has turned it, from the same source.
    let mut oriented = Rotation::None;
    // The last position published as commanded, so one that has not moved is
    // not republished on every pass.
    let mut commanded: Option<(i32, i32)> = None;
    // Which encoder this guest's peer has been told about. Set from the seat
    // rather than from zero, because a guest that joins after a
    // reinitialization has not missed one.
    let mut seen_epoch = 0u32;
    // Why this session is ending and when that was decided, so the message has
    // time to reach the peer before the session goes away.
    let mut kicked: Option<(i32, f64)> = None;
    let mut inbound_messages: u64 = 0;
    let mut sent: u64 = 0;
    // A guest's microphone, built when this host says it will take one and
    // dropped when it stops. **Nothing is decoded while it is absent.**
    let mut ear: Option<crate::microphone::Ear> = None;
    // What the peer has been told about it, so it is told once and again only
    // when the answer changes.
    let mut announced: Option<bool> = None;
    // What this peer has been seen to send, so the first of each kind says so.
    let mut census = [false; 256];
    // What sound has cost this guest, and what its channel is carrying.
    let mut sound = AudioSent::default();
    let mut sound_rate = Throughput::default();
    // What this guest's control channel is carrying. Small and bursty, and the
    // roster reports it because a stock reader has a field for it.
    let mut control_rate = Throughput::default();
    let mut reported_ms = 0.0f64;
    // The resend counters at the last report, so the line carries per-window
    // deltas, and the widest acknowledgement silence seen since it.
    let mut nack_resends_seen = 0u64;
    let mut timeout_resends_seen = 0u64;
    let mut ack_gap_peak = 0.0f64;
    // Latch for the soft liveness warning, so a stall is said once on the
    // transition rather than every pass for a minute.
    let mut stalled_said = false;
    // The live-run probe: when it fires and whether the chord has been let go
    // of since, so holding the two buttons does not rumble continuously.
    let mut probe_until: Option<f64> = None;
    let mut probe_armed = true;
    let mut pass: u32 = 0;

    while !running.stopping() {
        // Candidates are injected where the application's work is pulled, after
        // the wake has been taken, so nothing enqueued from here on is lost.
        // **The size the stream settled on, checked every pass rather than
        // once.** A guest takes its seat before the loop has opened a display,
        // so at that moment the size is not known yet; and a display can change
        // size while a session is running. The number the peer is told is the
        // coordinate space its absolute input comes back in, so a guest
        // describing the stream with the configured size puts every position
        // through the ratio between the two: a 2560 wide display described as
        // 1920 reaches the right edge three quarters of the way across.
        //
        // **Where the picture sits in the desktop arrives separately and
        // later**, because it is read from the session once the display is
        // open, so the two are followed together rather than one gating the
        // other. The size and the turn rebuild the framing, because the
        // header carries both; the placement changes nothing a peer can see.
        //
        // **The turn is the session's, read beside the placement.** A turned
        // display is drawn turned into a framebuffer that keeps its shape, so
        // the picture is on its side and the peer is told by how much; it
        // turns the picture back and maps its pointer in the desktop's
        // orientation, which is why the extents swap below.
        let settled = seat.as_ref().and_then(SeatHold::picture);
        let situated = seat.as_ref().and_then(SeatHold::place);
        let turned = seat.as_ref().map_or(Rotation::None, SeatHold::rotation);
        if (settled, situated, turned) != (followed, placed, oriented)
            && let Some((width, height)) = settled
            && args.video.is_some()
        {
            if followed != settled || oriented != turned {
                lowlat_common::log_info!(
                    "guest: the stream is {width}x{height} rotation={}, following it for the \
                     picture and for absolute input",
                    turned as u8
                );
                let mut framing = Packetiser::new(width, height, turned, false);
                framing.reconfigured();
                if let Some(negotiation) = negotiation.as_mut() {
                    negotiation.encoder_initialised(framing.generation());
                }
                packetiser = Some(framing);
            }
            if let Some(place) = situated.filter(|_| placed != situated) {
                lowlat_common::log_info!(
                    "guest: the picture is {}x{} at {},{} of a {}x{} desktop, placing input in it",
                    place.width,
                    place.height,
                    place.x,
                    place.y,
                    place.desktop_width,
                    place.desktop_height
                );
            }
            followed = settled;
            placed = situated;
            oriented = turned;
            if let Some(input) = input.as_mut() {
                input.injector.set_extents(desktop_extents(
                    u32::from(width),
                    u32::from(height),
                    turned,
                    situated,
                ));
            }
        }

        let arrivals = &args.arrivals;
        let seated = seat.as_ref();
        let mut framing = packetiser.as_mut();
        let mut declaring = negotiation.as_mut();
        let outbound = &mut sent;
        let sounded = &mut sound;
        // **A loop that stops has to say so.** Leaving here without an
        // outcome strands the attempt: its port, its seat and its share of
        // the advertised capacity are all released by the reaping the event
        // triggers, and nothing else releases them. The session is over either
        // way; the difference is whether the host knows.
        let turn = match shell.turn(|endpoint| {
            while let Ok(arrival) = arrivals.try_recv() {
                match arrival {
                    Arrival::Candidate(addr, kind) => {
                        let _ = endpoint.conn().add_candidate(addr, kind);
                    }
                    Arrival::PeerReady => endpoint.conn().set_peer_ready(),
                }
            }
            if let (Some(seat), Some(packetiser), Some(negotiation)) =
                (seated, framing.as_deref_mut(), declaring.as_deref_mut())
            {
                *outbound += send_frames(endpoint.session(), seat, packetiser, negotiation);
            }
            // **Sound needs no packetiser and no negotiation**, so it is sent
            // whether or not a picture can be: a guest whose encoder failed
            // still hears the desktop, which is the difference between a
            // session that is broken and one that is blank.
            if let Some(seat) = seated {
                // **What the seat says, not what the peer asked for.** A host
                // that does not permit the uncompressed form sends the
                // compressed one, and the header has to agree with the bytes.
                send_audio(endpoint.session(), seat, seat.audio_raw(), sounded);
            }
        }) {
            Ok(turn) => turn,
            Err(error) => {
                lowlat_common::log_warn!("guest: the transport stopped, err={error}");
                args.emit.send(Event::Ended {
                    attempt: args.attempt_id.clone(),
                    outcome: Outcome::TransportFailed,
                });
                return;
            }
        };
        // The pass runs on the shell's clock, read after its wait returned, so
        // every deadline below sees the same time the session was driven with.
        let now = turn.now;

        // Release anything held while the devices were becoming usable. On
        // its own timer, so a guest that pressed one key and waited does not
        // hold it until it presses a second.
        //
        // **And ask whether this guest still has the pointer**, which is the
        // only way one that stopped moving ever finds out it lost it: it sends
        // nothing further, so there is no message to answer.
        if let Some(input) = input.as_mut() {
            input.sink.tick();
            follow_pointer(input, &args.floor, args.guest, now);
            // **What a local application asks a pad to do goes back to the
            // peer holding it.** Nothing on this machine can vibrate; the
            // controller is somewhere else.
            while let Some(rumble) = input.sink.rumble() {
                send_rumble(
                    shell.endpoint().session(),
                    rumble.pad,
                    rumble.large,
                    rumble.small,
                );
            }
            if args.rumble_probe {
                let chord = input.injector.pad_holding(PROBE_CHORD);
                match (probe_until, chord) {
                    (None, Some(pad)) if probe_armed => {
                        lowlat_common::log_info!("input: rumble probe, pad={pad}");
                        send_rumble(shell.endpoint().session(), pad, u8::MAX, u8::MAX);
                        probe_until = Some(now + PROBE_MS);
                        probe_armed = false;
                    }
                    (Some(until), _) if now >= until => {
                        // **Zero, always.** A controller told to vibrate and
                        // never told to stop vibrates until its battery dies.
                        let pad = chord.unwrap_or(0);
                        send_rumble(shell.endpoint().session(), pad, 0, 0);
                        probe_until = None;
                    }
                    (None, None) => probe_armed = true,
                    _ => {}
                }
            }
        }

        // **Every pass, not on the reporting cadence.** The declaration is on a
        // deadline and input has a human waiting on it, so neither may sit in a
        // ring until a counter comes round.
        if let Some(negotiation) = negotiation.as_mut()
            && let Err(outcome) = drain_control(
                shell.endpoint().session(),
                negotiation,
                input.as_mut(),
                Pointer {
                    floor: &args.floor,
                    guest: args.guest,
                    owner: args.owner,
                    now_ms: now,
                },
                &mut inbound,
                Consumers {
                    count: &mut inbound_messages,
                    said: &mut |(id, text)| {
                        args.emit.send(Event::UserData {
                            guest: args.guest,
                            id,
                            text,
                        });
                    },
                    ear: ear.as_mut(),
                    census: &mut census,
                    telemetry: &args.telemetry,
                },
            )
        {
            args.emit.send(Event::Ended {
                attempt: args.attempt_id.clone(),
                outcome,
            });
            return;
        }

        if let Some(negotiation) = negotiation.as_mut() {
            forward_declaration(negotiation, seat.as_ref(), &mut declared_flags);
            follow_epoch(
                negotiation,
                packetiser.as_mut(),
                seat.as_ref(),
                &mut seen_epoch,
            );
        }

        // The path first, then the declaration it carries. A transition seen a
        // cadence late would spend that time off the deadline the peer is
        // being held to.
        match shell.endpoint().conn().state() {
            lowlat_core::conn::State::Established(addr) if negotiation.is_none() => {
                negotiation = Some(Negotiation::opened(now));
                args.emit.send(Event::Established {
                    attempt: args.attempt_id.clone(),
                    addr,
                });
            }
            lowlat_core::conn::State::Failed(failure) => {
                // The type is the diagnosis: a probe timeout is the one
                // outcome that justifies escalating to a relay, and no
                // candidates is a signaling gap rather than a network one.
                lowlat_common::log_info!(
                    "guest: punch failed, outcome={failure:?} attempt={}",
                    args.attempt_id
                );
                args.emit.send(Event::Ended {
                    attempt: args.attempt_id.clone(),
                    outcome: Outcome::ConnectivityFailed,
                });
                return;
            }
            _ => {}
        }

        // **Decided elsewhere, said here.** The stream thread owns no session
        // and cannot write to a peer; this is the only place that can, so the
        // reason it left on the seat becomes a message.
        if kicked.is_none()
            && let Some(reason) = asked_kick
                .take()
                .or_else(|| seat.as_ref().and_then(SeatHold::kicked))
        {
            lowlat_common::log_info!("guest: ending this session, reason={reason}");
            send_disconnect(shell.endpoint().session(), reason);
            // The seat goes back now rather than at the end of the grace
            // below: nothing more is going to be sent on it, and a seat held
            // open is capacity another guest cannot have.
            seat = None;
            kicked = Some((reason, now));
        }
        // **The message is on a reliable channel and needs time to get
        // there.** Returning on the pass that queued it tears the session down
        // with the reason still in the ring, and the peer learns nothing.
        if let Some((reason, at)) = kicked
            && now - at >= KICK_GRACE_MS
        {
            args.emit.send(Event::Ended {
                attempt: args.attempt_id.clone(),
                outcome: Outcome::Kicked(reason),
            });
            return;
        }

        if let Some(negotiation) = negotiation.as_mut()
            && negotiation.tick(now) == State::Abandoned
        {
            args.emit.send(Event::Ended {
                attempt: args.attempt_id.clone(),
                outcome: Outcome::NeverDeclared,
            });
            return;
        }

        // What the peer said it can decode, once, where a live run can see
        // it. A stream that renders nothing is diagnosed from here first.
        if !declared && let Some(asked) = negotiation.as_ref().and_then(Negotiation::asked) {
            declared = true;
            // **Read once, here, and never assumed.** A peer that did not say
            // it keeps pointer pictures is sent the picture every time.
            pointer.caches(asked.caches_cursor);
            lowlat_common::log_info!(
                "guest: declared attempt={} max_w={} max_h={} res={}x{} fps={} flags={:#x}",
                args.attempt_id,
                asked.max_width,
                asked.max_height,
                asked.resolution_x,
                asked.resolution_y,
                asked.refresh_rate,
                asked.flags
            );
            // **What a peer declares is a preference, not a requirement**, and
            // every bit here is one: a client offers the codec and the two
            // colour axes as "prefer this if the host has it" and follows what
            // the stream turns out to be. So none of this decides whether a
            // guest can be served, and a line saying it did was reporting a
            // failure on every ordinary connection -- it fired for a guest that
            // then streamed for four hundred pictures. Said at all only because
            // it is what every colour decision downstream is computed from.
            if asked.hevc() || asked.color444() || asked.ten_bit() {
                lowlat_common::log_info!(
                    "guest: attempt={} prefers hevc={} 444={} 10bit={}; the stream carries what \
                     every seat can take",
                    args.attempt_id,
                    u8::from(asked.hevc()),
                    u8::from(asked.color444()),
                    u8::from(asked.ten_bit())
                );
            }
        }

        // **A seat is taken when the guest becomes streamable, not when it
        // connects.** A seat held by a peer that has not declared itself is a
        // share of the bitrate budget spent on something that may never
        // decode a frame.
        if seat.is_none()
            && negotiation.as_ref().is_some_and(Negotiation::ready)
            && let Some(seats) = args.seats.as_ref()
            && let Ok(handle) = shell.wake_handle()
            // **A second handle for sound**, because the thread that publishes
            // it is not the one that publishes pictures and neither may hold
            // the other's. Both point at this loop's own wake.
            && let Ok(for_sound) = shell.wake_handle()
        {
            seat = seats.take(handle, for_sound);
            if let (Some(seat), Some(asked)) = (
                seat.as_ref(),
                negotiation.as_ref().and_then(Negotiation::asked),
            ) {
                // **What the peer asked for, which is not always what it
                // gets.** The uncompressed form is a permission a host grants
                // as well as one a guest requests, and the seat is where the
                // two meet.
                seat.declare_audio(asked.raw_audio);
                lowlat_common::log_info!(
                    "guest: sound asked for is {}, sent as {}",
                    if asked.raw_audio {
                        "uncompressed"
                    } else {
                        "compressed"
                    },
                    if seat.audio_raw() {
                        "uncompressed"
                    } else {
                        "compressed"
                    }
                );
            }
            match (seat.is_some(), negotiation.as_mut(), packetiser.as_ref()) {
                (true, Some(negotiation), Some(packetiser)) => {
                    // **The generation goes out on the frame after this**, so
                    // a peer learns the reference chain started rather than
                    // inferring it from the stream.
                    negotiation.encoder_initialised(packetiser.generation());
                    if let Some(seat) = seat.as_ref() {
                        seen_epoch = seat.epoch();
                    }
                    // Free insurance: thirteen bytes, no body, and a stock
                    // host sends it before its first frame. The peer stores it
                    // and nothing gates on it, so the cost of sending it is
                    // the cost of being wrong about that.
                    send_control(
                        shell.endpoint().session(),
                        &control::Control {
                            a0: 1,
                            a1: 0,
                            a2: 0,
                            opcode: control::op::HOST_MODE,
                            body: &[],
                        },
                    );
                }
                // **Capacity is the one refusal that used to be silent.** The
                // offer was accepted and the path was built, and then the
                // guest sat connected receiving nothing until its own liveness
                // deadline noticed, minutes later.
                (false, _, _) => {
                    lowlat_common::log_warn!("guest: every seat is taken");
                    send_disconnect(shell.endpoint().session(), status::NO_ROOM);
                    kicked = Some((status::NO_ROOM, now));
                }
                _ => lowlat_common::log_warn!("guest: seated with nothing to send on"),
            }
        }

        // **Where this guest told the pointer to be**, which is what the
        // hotspot is derived from: nothing reports a pointer's hotspot, and
        // the difference between a command and where the display then drew the
        // pointer is exactly it. Read from the injector rather than from the
        // message, so a position the permission gate or the arbiter refused is
        // not reported as one the pointer was put at.
        if let Some(seat) = seat.as_ref()
            && let Some((x, y)) = input.as_ref().and_then(|i| i.injector.commanded())
            && commanded != Some((x, y))
        {
            commanded = Some((x, y));
            seat.command_pointer(
                u16::try_from(x).unwrap_or(u16::MAX),
                u16::try_from(y).unwrap_or(u16::MAX),
            );
        }

        // **The pointer, per guest, because what it is owed depends on what it
        // already holds.** The stream reads it once; this decides whether the
        // picture travels or only its name, and sends nothing at all on the
        // passes where nothing about it moved.
        // **Whether this guest is the one driving**, which decides what it is
        // shown: a guest without the arbitrated pointer sees a refused shape
        // rather than finding out by nothing happening.
        let holds = args.floor.holds(args.guest, now);
        if let Some(seat) = seat.as_ref()
            && let Some(message) = pointer.next(seat, holds)
        {
            let _ = shell
                .endpoint()
                .session()
                .send_message(CONTROL_CHANNEL, message, &[]);
        }

        // **A peer sends no microphone audio until it is told it may.** Told
        // once when a seat exists, and again whenever the answer changes: a
        // host that stops taking one and says nothing leaves a peer sending
        // into a channel nobody reads.
        if seat.is_some() {
            let accepting = seat
                .as_ref()
                .is_some_and(crate::stream::SeatHold::accept_microphone);
            if announced != Some(accepting) {
                let (id, body) = crate::microphone::announcement(accepting);
                send_said(
                    shell.endpoint().session(),
                    &Said {
                        opcode: control::op::USER_DATA,
                        a1: id,
                        body,
                    },
                );
                announced = Some(accepting);
                lowlat_common::log_info!(
                    "guest: attempt={} microphone accepted={accepting}",
                    args.attempt_id
                );
            }
            // Built on the first pass that wants it, and given back when it is
            // no longer wanted, which also frees the codec's state.
            if accepting && ear.is_none() {
                ear = args
                    .microphone
                    .clone()
                    .and_then(|out| crate::microphone::Ear::new(args.guest, out));
            } else if !accepting && ear.is_some() {
                ear = None;
            }
        }

        // **Whatever the application asked to be sent, before anything else
        // this pass.** It is rare and small; draining it here keeps it off the
        // frame path and out of the shell's own closure.
        while let Ok(message) = args.said.try_recv() {
            send_said(shell.endpoint().session(), &message);
        }

        // **Taken here, applied by this thread.** Only this thread may touch
        // this guest's session or its input devices, so an ask arrives as a
        // message rather than being applied behind its back.
        while let Ok(ask) = args.asked.try_recv() {
            match ask {
                Ask::Kick(reason) => {
                    // **Left where the stream leaves one**, so the ending
                    // below is the one path rather than a second one that has
                    // to stay in step with it: the message, the grace period
                    // and the seat going back are all already there.
                    asked_kick = Some(reason);
                }
                Ask::Permissions(permissions) => {
                    lowlat_common::log_info!(
                        "guest: number={} permissions changed keyboard={} pointer={} gamepad={}",
                        args.guest,
                        u8::from(permissions.keyboard),
                        u8::from(permissions.pointer),
                        u8::from(permissions.gamepad)
                    );
                    if let Some(input) = input.as_mut() {
                        input.injector.set_permissions(permissions, &mut input.sink);
                    }
                }
                Ask::SecureAttention => {
                    // **Typed or not typed, and nothing else is decided here.**
                    // Whether the machine is one where the chord means a leave
                    // dialog rather than a restart is the asking program's
                    // question; this end types keys and reports the keyboard
                    // permission, which is the only part it knows.
                    let typed = input
                        .as_mut()
                        .is_some_and(|input| input.injector.secure_attention(&mut input.sink));
                    lowlat_common::log_info!(
                        "guest: number={} asked for the attention chord, typed={}",
                        args.guest,
                        u8::from(typed)
                    );
                }
            }
        }

        // **When each kind of input last arrived**, which is the one question an
        // application asking about an idle guest can ask nobody else. Stamped
        // from the tally moving rather than from a message arriving, so input
        // the permission gate or the arbiter refused does not count as a guest
        // still being there.
        if let Some(input) = input.as_ref() {
            let now_tally = input.injector.tally();
            args.telemetry.stamped(&counted, &now_tally, now);
            counted = now_tally;
        }

        // What the stream's controller and gate are steered by. Cheap, and it
        // reads state this loop already owns.
        if let Some(seat) = seat.as_ref()
            && let Some(pressure) = shell.endpoint().session().send_pressure(VIDEO_CHANNEL)
        {
            let window = pressure.window;
            let stale = pressure.stale;
            let measured = throughput.sample(pressure.bytes_sent, now);
            // What the path delivered, beside what it was offered. The
            // controller still steers by the offered figure; this one is for
            // the person reading the line.
            let got = delivered.sample(pressure.acked_bytes, now);
            // **The widest silence from the peer, sampled on wakes.** The
            // timer caps the spacing between wakes, so a gap longer than the
            // cadence is seen while it is happening rather than after it.
            ack_gap_peak = ack_gap_peak.max(now - shell.endpoint().session().last_ack_in_ms());
            seat.report(window, stale, measured);
            // **Published where it is already computed.** These are the
            // controller's own inputs; an application asking what a guest is
            // doing gets the numbers the host is steering by rather than a
            // second set derived somewhere else.
            args.telemetry.measured(
                window,
                stale,
                seat.cg_events(),
                shell.endpoint().session().srtt_ms(),
            );
            args.telemetry.channel_measured(
                Channel::Video,
                ChannelSample {
                    packets_sent: pressure.packets_sent,
                    fast_rts: pressure.nack_resends,
                    slow_rts: pressure.timeout_resends,
                    mbps: measured,
                    encode_ms: seat.encode_latency_ms(),
                },
            );
            // **The other two channels on the same pass**, from the rings that
            // already carry the counters. A roster that describes only the
            // video channel says nothing about a peer whose sound has stopped
            // or whose control traffic is backing up, and those are different
            // faults with different causes.
            let session = shell.endpoint().session();
            if let Some(pressure) = session.send_pressure(AUDIO_CHANNEL) {
                args.telemetry.channel_measured(
                    Channel::Audio,
                    ChannelSample {
                        packets_sent: pressure.packets_sent,
                        fast_rts: pressure.nack_resends,
                        slow_rts: pressure.timeout_resends,
                        mbps: sound_rate.sample(pressure.bytes_sent, now),
                        encode_ms: seat.audio_encode_latency_ms(),
                    },
                );
            }
            if let Some(pressure) = session.send_pressure(CONTROL_CHANNEL) {
                args.telemetry.channel_measured(
                    Channel::Control,
                    ChannelSample {
                        packets_sent: pressure.packets_sent,
                        fast_rts: pressure.nack_resends,
                        slow_rts: pressure.timeout_resends,
                        mbps: control_rate.sample(pressure.bytes_sent, now),
                        // Nothing encodes control traffic and nothing decodes
                        // it into a picture, so both figures stay zero here as
                        // they do in every peer this talks to.
                        encode_ms: 0.0,
                    },
                );
            }

            // **The line a live run is read from.** Frames leaving, the window
            // the gate is judging, and what the path is actually carrying: a
            // stream that stops is one of the three going flat.
            if now - reported_ms >= PROGRESS_MS {
                reported_ms = now;
                // Resends since the last report, by cause. A gap the peer
                // reported apart from one the timeout had to find.
                let nacks = pressure.nack_resends.saturating_sub(nack_resends_seen);
                let rtos = pressure
                    .timeout_resends
                    .saturating_sub(timeout_resends_seen);
                nack_resends_seen = pressure.nack_resends;
                timeout_resends_seen = pressure.timeout_resends;
                let ack_gap = ack_gap_peak;
                ack_gap_peak = 0.0;
                // **What the peer is still doing, not only what we are.** A
                // guest that stops acknowledging while its own messages keep
                // arriving is alive and has stopped reading; one that goes
                // silent both ways has torn the session down. The two have
                // different causes and the log has to tell them apart.
                let rx = shell
                    .endpoint()
                    .session()
                    .recv_cumulative(CONTROL_CHANNEL)
                    .unwrap_or(0);
                // **What the ring refused, which delivery cannot show.**
                // Duplicates are a peer retransmitting what was already
                // taken; out-of-window and oversized stores are a peer past
                // this ring's bounds, and both read as plain loss from the
                // far side.
                let rx_drops = shell
                    .endpoint()
                    .session()
                    .recv_drops(CONTROL_CHANNEL)
                    .unwrap_or_default();
                let input_tally = input
                    .as_ref()
                    .map(|i| i.injector.tally())
                    .unwrap_or_default();
                // **Datagrams, not fragments.** `rx_frag` counts what arrived
                // on a channel and reached the application; an acknowledgement
                // is neither. Without the raw count the two ways a stream dies
                // look identical in this line: a peer that has stopped reading
                // and a peer whose acknowledgements are arriving and not being
                // applied both show a window that only grows.
                let datagrams = shell.stats();
                // **The round trip is the proof an acknowledgement landed.** A
                // sample exists only where one named a fragment still held, so
                // a smoothed trip that never leaves zero says the inbound
                // datagrams are not acknowledgements this session applied --
                // which is a different fault from a peer that has stopped
                // sending them at all, and the two are otherwise identical
                // from here.
                let srtt = shell.endpoint().session().srtt_ms();
                // The smallest recent sample beside the smoothed one: the
                // gradient between them is the queue building.
                let rtt_min = shell.endpoint().session().rtt_min_ms();
                // **What sound is costing on the wire**, which is the only
                // place it can be seen: a silent desktop keeps sending
                // compressed packets, so the count climbing says nothing about
                // whether silence is being paid for and the rate says all of
                // it.
                let sound_mbps = shell
                    .endpoint()
                    .session()
                    .send_pressure(AUDIO_CHANNEL)
                    .map_or(0.0, |p| sound_rate.sample(p.bytes_sent, now));
                // **What a guest's microphone delivered, and what it cost.** A
                // packet the codec refused and one that made it panic are
                // counted apart: the second is the number that says whether
                // the containment is doing real work on this peer's traffic.
                let mic = ear.as_ref().map_or((0, 0, 0), |ear| {
                    let (refused, panicked) = ear.refused();
                    (ear.taken(), refused, panicked)
                });
                args.telemetry
                    .progressed(now, u32::try_from(sent).unwrap_or(u32::MAX));
                // **What this guest was allowed and what it was coded in.**
                // A picture is decided by the two together, and a room that
                // gains a less capable guest changes both at once: the rate
                // divides and the codec drops to what every seat can decode.
                // Neither is visible from the rate a guest actually used.
                let allowed = seat.allowed_mbps();
                let codec = seat
                    .colour()
                    .map_or("none", |(codec, _, _)| crate::stream::codec_name(codec));
                lowlat_common::log_info!(
                    "guest: attempt={} frames={sent} window={window} stale={stale} allowed={allowed:.1} codec={codec} mbps={measured:.2} delivered={got:.2} nacks={nacks} rtos={rtos} encode_ms={:.2} rx_frag={rx} rx_msg={inbound_messages} rx_dup={} rx_oow={} rx_big={} dg_in={} dg_out={} rej={} srtt={:.1} rtt_min={rtt_min:.1} ack_gap={ack_gap:.0} keys={} btn={} wheel={} motion={} pad={} snd={} snd_drop={} snd_mbps={sound_mbps:.3} mic={} mic_refused={} mic_panicked={}",
                    args.attempt_id,
                    seat.encode_latency_ms(),
                    rx_drops.duplicate,
                    rx_drops.out_of_window,
                    rx_drops.too_large,
                    datagrams.datagrams_in,
                    datagrams.datagrams_out,
                    datagrams.rejected,
                    srtt,
                    input_tally.keys,
                    input_tally.buttons,
                    input_tally.wheels,
                    input_tally.motions,
                    input_tally.pads,
                    sound.packets,
                    sound.dropped,
                    mic.0,
                    mic.1,
                    mic.2
                );
            }
        }

        pass = pass.wrapping_add(1);
        if pass % REPORT_EVERY != 0 {
            continue;
        }

        // Trickled as they are found. The engine retains them, so this reports
        // what is new rather than what was returned by one call.
        let fresh: Vec<SocketAddr> = shell
            .endpoint()
            .conn()
            .reflexive()
            .filter(|addr| !reported.contains(addr))
            .collect();
        for addr in fresh {
            reported.push(addr);
            args.emit.send(Event::Candidate {
                attempt: args.attempt_id.clone(),
                addr,
                // A v6 address goes out marked lan whatever discovered it:
                // no translation to negotiate, so the peer checks it at once
                // and keeps its one probe for a translated path.
                from_stun: addr.is_ipv4(),
                lan: addr.is_ipv6(),
            });
        }

        // **A pipe that failed on a path that exists.** The native pipe never
        // reports one; a browser's does, and it is the one ending that is
        // neither a silence nor a departure, so it is named before liveness
        // gets a chance to call it a peer gone.
        if let Some(fault) = shell.endpoint().fault() {
            lowlat_common::log_warn!(
                "guest: attempt={} pipe failed, fault={fault:?}",
                args.attempt_id
            );
            args.emit.send(Event::Ended {
                attempt: args.attempt_id.clone(),
                outcome: Outcome::HandshakeFailed,
            });
            return;
        }

        // **The latency figure is on the clock, from the moment the path
        // exists.** A seat waiting on a display sends no frames, and a peer
        // that reads silence on the control channel as a dead link must not
        // be given any; the figure is zero until a picture has been timed.
        if let Some(negotiation) = negotiation.as_mut()
            && let Some(message) = negotiation.latency_report(now, 0)
        {
            send_control(shell.endpoint().session(), &message);
        }

        // Only once there is a path. Before that nothing has arrived by
        // definition, so liveness would read as dead from the first pass.
        if negotiation.is_some() {
            let outcome = match shell.endpoint().health(now) {
                lowlat_core::session::Health::Dead => Some(Outcome::PeerGone),
                // **The window says this and nothing else does.** A peer that
                // keeps acknowledging while receiving nothing is alive by
                // every inbound measure, and everything queued for it is
                // retransmitted until something ends the session.
                lowlat_core::session::Health::Undeliverable => {
                    // **Both channels, because either can be the one that
                    // stopped.** A peer whose control channel keeps up while
                    // its video ring backs up is a different fault from a path
                    // that has gone away, and these two numbers are what tell
                    // them apart afterwards.
                    let video = shell
                        .endpoint()
                        .session()
                        .send_pressure(VIDEO_CHANNEL)
                        .unwrap_or_default();
                    let control = shell
                        .endpoint()
                        .session()
                        .send_pressure(CONTROL_CHANNEL)
                        .unwrap_or_default();
                    lowlat_common::log_warn!(
                        "guest: nothing acknowledged for {DELIVERY_DEADLINE_MS:.0} ms, \
                         video window={} stale={}, control window={} stale={}",
                        video.window,
                        video.stale,
                        control.window,
                        control.stale
                    );
                    Some(Outcome::Undeliverable)
                }
                // **The soft failure is worth one line.** Nothing has arrived
                // for a minute; the session is not ended for it, but a live
                // run reading backwards from a hard failure wants the moment
                // the silence began, and this is the only place that sees it.
                lowlat_core::session::Health::Stalled => {
                    if !stalled_said {
                        stalled_said = true;
                        lowlat_common::log_warn!(
                            "guest: attempt={} stalled, nothing received for {:.0} ms",
                            args.attempt_id,
                            lowlat_core::session::LIVENESS_SOFT_MS
                        );
                    }
                    None
                }
                lowlat_core::session::Health::Alive => {
                    stalled_said = false;
                    None
                }
            };
            if let Some(outcome) = outcome {
                args.emit.send(Event::Ended {
                    attempt: args.attempt_id.clone(),
                    outcome,
                });
                return;
            }
        }
    }
}

#[cfg(test)]
mod tests_support {
    use super::Peer;

    pub(super) fn peer() -> Peer {
        Peer {
            permissions: lowlat_inject::event::Permissions::default(),
            owner: false,
            ufrag: "aaaa".into(),
            pwd: "passwordforaaaa".into(),
            aes256: None,
            transport: super::Transport::Bud,
            fingerprint: None,
        }
    }

    /// A peer whose offer carried a media key, as every current client's does.
    pub(super) fn modern_peer() -> Peer {
        Peer {
            aes256: Some("deadbeef".into()),
            ..peer()
        }
    }
}

#[cfg(test)]
mod disconnect_status {
    use lowlat_core::control;

    /// **A peer's parting status survives the wire as a signed value.**
    ///
    /// It is written into an unsigned argument and read back out of one, and
    /// every status that matters here is negative, so a conversion that
    /// saturates or clamps anywhere along the way turns "my decoder failed"
    /// into zero -- which is the value that means a peer simply left. The two
    /// are the difference between a diagnosis and a shrug, and nothing else in
    /// the system can tell them apart afterwards.
    #[test]
    fn a_negative_status_survives_the_round_trip() {
        // The three a peer really stops on, from the vendored enumeration:
        // a failed decode, a decoder that supports nothing we sent, and a
        // colour format it cannot read. Plus zero, the ordinary departure.
        for reason in [-14_i32, -17, -18, 0] {
            let mut bytes = [0_u8; 32];
            #[expect(
                clippy::cast_sign_loss,
                reason = "the status is signed and the argument that carries it is not"
            )]
            let written = control::encode_header(
                &mut bytes,
                &control::Control {
                    a0: reason as u32,
                    a1: 0,
                    a2: 0,
                    opcode: control::op::DISCONNECT,
                    body: &[],
                },
            )
            .expect("encode");
            let parsed = control::parse(&bytes[..written]).expect("parse");
            assert_eq!(parsed.opcode, control::op::DISCONNECT);
            assert_eq!(
                i32::from_ne_bytes(parsed.a0.to_ne_bytes()),
                reason,
                "a status of {reason} did not survive being carried"
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::tests_support::*;
    use super::*;

    fn admission(max_guests: usize) -> Admission {
        Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            // Ephemeral, so the tests do not fight the machine for a fixed port.
            base_port: 0,
            shared_address_space: false,
            max_guests,
            servers: Vec::new(),
            stream: None,
        })
    }

    /// As [`admission`], but on a fixed base rather than an ephemeral one, for
    /// the tests that are about which port was chosen.
    fn admission_on(base: u16) -> Admission {
        Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            base_port: base,
            shared_address_space: false,
            max_guests: 4,
            servers: Vec::new(),
            stream: None,
        })
    }

    #[test]
    fn an_unknown_attempt_is_a_no_op_rather_than_a_fault() {
        let mut seam = Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            base_port: 0,
            shared_address_space: false,
            max_guests: 1,
            servers: Vec::new(),
            stream: None,
        });
        // A candidate for an identifier that never existed, or has just been
        // torn down, is a race with the peer and not an error.
        seam.add_candidate(
            "nope",
            "127.0.0.1:9000".parse().unwrap(),
            false,
            Kind::Reflexive,
        );
        assert_eq!(
            seam.begin_p2p("nope", 0).unwrap_err(),
            Error::UnknownAttempt
        );
    }

    #[test]
    fn capacity_is_the_only_policy_and_it_is_applied_at_admission() {
        let mut seam = admission(1);
        seam.new_attempt("one", peer()).expect("register");
        seam.new_attempt("two", peer()).expect("register");
        seam.begin_p2p("one", 0).expect("first guest");
        // Registering was fine; admitting past the limit is not.
        assert_eq!(seam.begin_p2p("two", 0).unwrap_err(), Error::AtCapacity);
        assert_eq!(seam.occupancy(), 1);
        seam.end_connection("one");
    }

    /// Candidates trickle, and the peer starts sending them before the answer
    /// has reached it. One that arrives before approval must be kept, not
    /// **Both families of a dual-stack name are asked, not whichever the
    /// resolver put first.**
    ///
    /// The order follows this machine's own addressing, so keeping the head
    /// alone gives a host with global v6 a v6 reflexive address and no v4 one,
    /// and a v4-only peer is then offered nothing from us it can reach.
    #[test]
    fn a_dual_stack_server_name_resolves_to_one_of_each_family() {
        // Stated rather than assumed: where localhost answers on one family
        // only this cannot tell the two behaviours apart, and saying so beats
        // passing without having checked.
        let families: std::collections::BTreeSet<bool> =
            std::net::ToSocketAddrs::to_socket_addrs("localhost:3478")
                .expect("localhost must resolve")
                .map(|addr| addr.is_ipv6())
                .collect();
        assert_eq!(
            families.len(),
            2,
            "this check needs a localhost that answers on both families"
        );

        let found = resolve_server("localhost:3478");
        assert_eq!(
            found.iter().filter(|a| a.is_ipv4()).count(),
            1,
            "no v4 reflexive server from a dual-stack name: {found:?}"
        );
        assert_eq!(
            found.iter().filter(|a| a.is_ipv6()).count(),
            1,
            "no v6 reflexive server from a dual-stack name: {found:?}"
        );
    }

    /// A name that resolves to nothing is empty, not a panic and not a guess.
    #[test]
    fn a_name_that_does_not_resolve_is_empty() {
        assert!(resolve_server("no-such-host.invalid:3478").is_empty());
    }

    /// dropped: on a wide-area path it may be the only one that works.
    #[test]
    fn candidates_arriving_before_approval_are_kept() {
        let mut seam = admission(4);
        seam.new_attempt("a", peer()).expect("register");
        seam.add_candidate(
            "a",
            "203.0.113.9:41000".parse().unwrap(),
            false,
            Kind::Reflexive,
        );
        seam.add_candidate(
            "a",
            "203.0.113.9:41001".parse().unwrap(),
            false,
            Kind::Reflexive,
        );

        let buffered = seam.attempts.get("a").map(|a| a.pending.len());
        assert_eq!(buffered, Some(2), "a candidate before approval was dropped");

        seam.begin_p2p("a", 0).expect("approve");
        let drained = seam.attempts.get("a").map(|a| a.pending.len());
        assert_eq!(drained, Some(0), "buffered candidates were not handed over");
        seam.end_connection("a");
    }

    /// Generated at approval, bound to the socket just opened for the attempt.
    /// Earlier binds them to nothing; per registration leaks state for attempts
    /// that are never approved.
    #[test]
    fn credentials_appear_at_approval_and_are_not_reused() {
        let mut seam = admission(4);
        seam.new_attempt("a", modern_peer()).expect("register");
        seam.new_attempt("b", modern_peer()).expect("register");
        let first = seam.begin_p2p("a", 0).expect("approve a");
        let second = seam.begin_p2p("b", 0).expect("approve b");

        assert_eq!(first.ufrag.len(), 8);
        assert_eq!(first.pwd.len(), 32);
        assert_eq!(first.fingerprint.len(), 64);
        assert_eq!(first.aes256.len(), 254);
        assert_ne!(first.aes256, second.aes256, "two guests shared a media key");
        assert_ne!(first.ufrag, second.ufrag);

        seam.end_connection("a");
        seam.end_connection("b");
    }

    /// **An offer without a media key selects the legacy cipher.** The field
    /// does not exist for that peer generation, so the session keys from this
    /// host's fingerprint under the 128-bit mode, and the answer carries no
    /// media key: the empty field is the truth about the session, not an
    /// omission.
    #[test]
    fn an_offer_without_a_media_key_selects_the_legacy_cipher() {
        let mut seam = admission(4);
        seam.new_attempt("old", peer()).expect("register");
        let creds = seam.begin_p2p("old", 0).expect("approve");

        assert!(
            creds.aes256.is_empty(),
            "the answer carried a media key the peer cannot read"
        );
        assert_eq!(
            creds.fingerprint.len(),
            64,
            "the fingerprint is the session key material and must decode"
        );
        seam.end_connection("old");
    }

    /// One socket per guest, so a second concurrent guest cannot have the base
    /// port and walks to the next. A host that cannot walk cannot admit a
    /// second guest at all on a configured port. *Named regression test.*
    /// **An exhausted walk takes any port rather than refusing the guest.**
    ///
    /// A host whose range is occupied can still serve: nothing advertises the
    /// port that was asked for, because every candidate is built from the
    /// address the socket reports. Refusing instead turns a busy range into a
    /// guest who cannot connect at all, which is the harsher failure and not
    /// what a peer does.
    #[test]
    fn an_exhausted_walk_still_admits_the_guest() {
        let probe = Socket::open(0).expect("probe");
        let base = probe.local_addr().expect("addr").port();
        drop(probe);

        // Occupy the whole walk, so nothing in the range can be bound.
        let mut held = Vec::new();
        // Written out rather than taken from the walk's own constant, so a
        // fixture cannot scale with the thing it is meant to pin.
        for step in 0..50u16 {
            let Some(port) = base.checked_add(step) else {
                break;
            };
            if let Ok(socket) = Socket::open(port)
                && socket.local_addr().ok().map(|a| a.port()) == Some(port)
            {
                held.push(socket);
            }
        }
        assert!(!held.is_empty(), "the range could not be occupied");

        let mut seam = admission_on(base);
        seam.new_attempt("a", peer()).expect("register");
        let ours = seam
            .begin_p2p("a", 0)
            .expect("an occupied range must not refuse the guest");
        assert_ne!(ours.port, 0, "no port was reported");
        seam.end_connection("a");
        drop(held);
    }

    /// **A port the caller supplies is where the bind starts**, and zero means
    /// the configured base instead.
    ///
    /// An application that manages its own gateway mapping, firewall rule or
    /// port pool has an opinion for a reason, and none of those survive this
    /// library choosing for it. The base is set to something the supplied port
    /// is not, so a bind that ignored the argument lands somewhere this can
    /// see.
    #[test]
    fn a_supplied_port_is_where_the_bind_starts() {
        let probe = Socket::open(0).expect("probe");
        let asked = probe.local_addr().expect("addr").port();
        drop(probe);
        let other = Socket::open(0).expect("probe");
        let base = other.local_addr().expect("addr").port();
        drop(other);
        assert_ne!(
            asked, base,
            "the two probes must differ for this to prove anything"
        );

        let mut seam = admission_on(base);
        seam.new_attempt("a", peer()).expect("register");
        let ours = seam.begin_p2p("a", asked).expect("approve");
        assert_eq!(
            ours.port, asked,
            "the supplied port was ignored and the configured base used instead"
        );
        seam.end_connection("a");

        // And zero asks for the base.
        seam.new_attempt("b", peer()).expect("register");
        let theirs = seam.begin_p2p("b", 0).expect("approve");
        assert_eq!(
            theirs.port, base,
            "zero did not fall back to the configured base"
        );
        seam.end_connection("b");
    }

    #[test]
    fn concurrent_guests_land_on_consecutive_ports() {
        // A base the first guest can actually take. Ephemeral would give each
        // guest an unrelated port and prove nothing about walking.
        let probe = Socket::open(0).expect("probe");
        let base = probe.local_addr().expect("addr").port();
        drop(probe);

        let mut seam = Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            base_port: base,
            shared_address_space: false,
            max_guests: 4,
            servers: Vec::new(),
            stream: None,
        });
        seam.new_attempt("a", peer()).expect("register a");
        seam.new_attempt("b", peer()).expect("register b");
        seam.new_attempt("c", peer()).expect("register c");

        let a = seam.begin_p2p("a", 0).expect("approve a").port;
        let b = seam.begin_p2p("b", 0).expect("approve b").port;
        let c = seam.begin_p2p("c", 0).expect("approve c").port;

        assert_eq!(a, base, "the first guest did not take the configured port");
        assert_eq!(b, base + 1, "the second guest did not walk");
        assert_eq!(c, base + 2, "the third guest did not walk");

        seam.end_connection("a");
        seam.end_connection("b");
        seam.end_connection("c");
    }

    /// A readiness marker is not a candidate. A peer is entitled to put a
    /// placeholder address on one, and one sends a literal `1.2.3.4:1234`;
    /// checking that address spends the attempt on an unrelated host.
    /// *Named regression test.*
    #[test]
    fn a_sync_marker_never_becomes_a_candidate() {
        let mut seam = admission(4);
        seam.new_attempt("a", peer()).expect("register");
        seam.add_candidate("a", "1.2.3.4:1234".parse().unwrap(), true, Kind::Reflexive);

        let attempt = seam.attempts.get("a").expect("attempt");
        assert!(attempt.peer_ready, "the marker was not recorded");
        // Forwarded so the engine can lift its gate, but as readiness --
        // never as the arbitrary address that rode along with it.
        assert_eq!(attempt.pending.len(), 1, "the marker was not forwarded");
        assert!(
            attempt
                .pending
                .iter()
                .all(|arrival| matches!(arrival, Arrival::PeerReady)),
            "a readiness marker was queued as a candidate"
        );
    }

    /// A peer may withhold every real candidate until it has seen one of ours,
    /// so approval must produce it without being prompted.
    /// *Named regression test.*
    #[test]
    fn approval_asks_for_a_readiness_marker_to_be_sent() {
        let mut seam = admission(4);
        seam.new_attempt("a", peer()).expect("register");
        seam.begin_p2p("a", 0).expect("approve");

        let mut saw_ready = false;
        while let Some(received) = seam.poll_event() {
            if received.event
                == (Event::Ready {
                    attempt: "a".to_string(),
                })
            {
                saw_ready = true;
            }
        }
        assert!(saw_ready, "approval did not ask for a readiness marker");
        seam.end_connection("a");
    }

    /// A withdrawal can overtake the offer it withdraws. Admitting the offer
    /// then spends a socket and a thread on a guest that has already gone, and
    /// nothing later arrives to say so -- the port stays held for the life of
    /// the host. *Named regression test.*
    /// **A stamp at the very first millisecond must not read as never.** Zero
    /// is how "this has never happened" is written, so an application kicking
    /// idle guests would see a guest that touched the keyboard as the session
    /// opened as one that has never touched it at all.
    ///
    /// The seated-guest test cannot catch this: a guest that sends nothing
    /// never reaches the stamping at all, so the rule went unexercised until
    /// deleting it changed no result.
    #[test]
    fn input_at_the_first_millisecond_is_not_reported_as_never() {
        let telemetry = Telemetry::default();
        let quiet = lowlat_inject::event::Tally::default();
        assert_eq!(telemetry.read().keyboard_ms, 0, "nothing has happened yet");

        let typed = lowlat_inject::event::Tally {
            keys: 1,
            ..Default::default()
        };
        telemetry.stamped(&quiet, &typed, 0.0);
        assert_ne!(
            telemetry.read().keyboard_ms,
            0,
            "input at millisecond zero was recorded as never having happened"
        );

        // And the other two kinds are stamped by their own counters, not by
        // whichever moved: a guest driving the pointer has not touched the pad.
        let moved = lowlat_inject::event::Tally {
            keys: 1,
            motions: 5,
            ..Default::default()
        };
        telemetry.stamped(&typed, &moved, 40.0);
        let read = telemetry.read();
        assert_eq!(read.pointer_ms, 40);
        assert_eq!(
            read.gamepad_ms, 0,
            "a pad that was never touched was stamped"
        );
        assert_ne!(
            read.keyboard_ms, 40,
            "a keyboard that did not move was restamped"
        );
    }

    #[test]
    fn a_withdrawal_that_overtakes_its_offer_refuses_the_offer() {
        let mut seam = admission(4);
        seam.end_connection("late");
        assert_eq!(
            seam.new_attempt("late", peer()).unwrap_err(),
            Error::Withdrawn
        );
        assert_eq!(seam.occupancy(), 0);

        // Only the once: a second offer with that identifier is a new attempt.
        seam.new_attempt("late", peer())
            .expect("the tombstone is consumed");
        seam.end_connection("late");
    }

    /// **The queue is handed over once, and the seam stops answering for it.**
    /// A poll waits for as long as its caller asked and the seam's lock must
    /// not be held for that long, so whoever polls holds the queue itself. Two
    /// consumers would each see part of the stream and each be told a
    /// different fraction of what was lost.
    #[test]
    fn the_event_queue_is_handed_over_once_and_carries_what_the_seam_raises() {
        let mut seam = admission(4);
        let events = seam.take_events().expect("the queue is there to take");
        assert!(
            seam.take_events().is_none(),
            "the queue was handed to a second consumer"
        );

        seam.new_attempt("a", peer()).expect("register");
        seam.begin_p2p("a", 0).expect("approve");

        // It reaches the holder rather than the seam, which now reports
        // nothing at all.
        assert!(seam.poll_event().is_none(), "the seam still answers polls");

        // **The marker comes last, after the candidates it unblocks.** That is
        // the order a peer sends in, and a peer entitled to withhold its own
        // candidates until it sees one is entitled to expect ours by then.
        let mut seen = Vec::new();
        while let Some(taken) = events.recv_timeout(core::time::Duration::from_secs(5)) {
            let ready = matches!(taken.event, Event::Ready { .. });
            seen.push(taken.event);
            if ready {
                break;
            }
        }
        let (last, candidates) = seen.split_last().expect("approval raises events");
        assert_eq!(
            *last,
            Event::Ready {
                attempt: "a".to_string()
            },
            "the readiness marker was not the last thing raised"
        );
        assert!(
            !candidates.is_empty(),
            "no candidate was raised before the marker"
        );
        assert!(
            candidates
                .iter()
                .all(|event| matches!(event, Event::Candidate { .. })),
            "something other than a candidate came before the marker: {candidates:?}"
        );
        seam.end_connection("a");
    }

    /// A browser whose certificate is not the one its offer named is a
    /// handshake fault, reported as its own outcome rather than as a peer
    /// gone: a path existed and the pipe on it did not. Driven end to end
    /// through the seam, a real socket and a real peer, whose identity is
    /// simply not the digest the offer carried.
    #[test]
    fn a_web_guest_fault_ends_the_attempt_with_a_handshake_outcome() {
        use lowlat_core::endpoint::Endpoint;
        use lowlat_net::web::{Role, WebSession};

        let mut seam = admission(4);
        let events = seam.take_events().expect("the queue");
        let theirs = lowlat_crypto::cert::Certificate::generate().unwrap();
        // The digest the offer names is not the peer's.
        let named = lowlat_crypto::cert::format_fingerprint(&[0xEE; 32]);
        seam.new_attempt(
            "web",
            Peer {
                transport: Transport::Web,
                fingerprint: Some(named),
                ..peer()
            },
        )
        .expect("register");
        let host = seam.begin_p2p("web", 0).expect("approve");
        let host_addr = SocketAddr::new(
            std::net::IpAddr::V6(std::net::Ipv6Addr::LOCALHOST),
            host.port,
        );

        // The peer: the other end of the same credentials, on its own socket,
        // expecting the digest this process really presents.
        let ours = lowlat_crypto::cert::certificate().unwrap();
        let socket = Socket::open(0).expect("socket");
        let mut peer_addr = socket.local_addr().expect("addr");
        peer_addr.set_ip(std::net::IpAddr::V6(std::net::Ipv6Addr::LOCALHOST));
        let mut conn = Conn::new(
            Credentials {
                local_ufrag: "aaaa",
                local_pwd: "passwordforaaaa",
                remote_ufrag: &host.ufrag,
                remote_pwd: &host.pwd,
            },
            [0x5A; 16],
            0.0,
        );
        conn.add_candidate(host_addr, Kind::Direct).unwrap();
        conn.set_peer_ready();
        let session = WebSession::new(Role::Server, Some(*ours.fingerprint()), &theirs, 1, 0.0)
            .expect("session");
        let mut shell = Shell::new(
            socket,
            Wake::new().expect("wake"),
            Endpoint::new(conn, session),
        );
        seam.add_candidate("web", peer_addr, false, Kind::Direct);
        seam.add_candidate("web", peer_addr, true, Kind::Direct);

        let started = std::time::Instant::now();
        let mut ended = None;
        while started.elapsed() < core::time::Duration::from_secs(10) && ended.is_none() {
            shell.turn(|_| {}).expect("turn");
            while let Some(taken) = events.recv_timeout(core::time::Duration::from_millis(1)) {
                if let Event::Ended { outcome, .. } = taken.event {
                    ended = Some(outcome);
                }
            }
        }
        assert_eq!(ended, Some(Outcome::HandshakeFailed));
        assert!(
            shell.endpoint().path().is_some(),
            "the peer never found the path"
        );
        seam.end_connection("web");
    }

    #[test]
    fn ending_an_attempt_frees_the_slot_without_reporting_it() {
        let mut seam = admission(1);
        seam.new_attempt("a", peer()).expect("register");
        seam.begin_p2p("a", 0).expect("approve");
        seam.end_connection("a");

        assert_eq!(seam.occupancy(), 0);
        // The application caused this, so it needs no event back. A second
        // terminal event for an attempt that already reported one is what this
        // asserts against.
        let mut terminal = 0;
        while let Some(received) = seam.poll_event() {
            if matches!(received.event, Event::Ended { .. }) {
                terminal += 1;
            }
        }
        assert_eq!(terminal, 0, "an application-initiated end reported itself");
    }
}

/// The ring geometry and the control path, driven through real rings rather
/// than against the constants that configure them.
#[cfg(test)]
mod geometry {
    use super::*;
    use lowlat_core::control::{Control, op};

    const KEY: [u8; 32] = [7u8; 32];

    /// Storage for one endpoint, in the shape [`run_guest`] builds.
    struct Arena {
        control_recv_bodies: Vec<u8>,
        control_recv_meta: Vec<SlotMeta>,
        control_send_bodies: Vec<u8>,
        control_send_meta: Vec<SendSlot>,
        video_send_bodies: Vec<u8>,
        video_send_meta: Vec<SendSlot>,
    }

    impl Arena {
        fn new() -> Self {
            Self {
                control_recv_bodies: vec![0u8; SLOT * CONTROL_RECV_SLOTS],
                control_recv_meta: vec![SlotMeta::default(); CONTROL_RECV_SLOTS],
                control_send_bodies: vec![0u8; SLOT * CONTROL_SEND_SLOTS],
                control_send_meta: vec![SendSlot::default(); CONTROL_SEND_SLOTS],
                video_send_bodies: vec![0u8; SLOT * VIDEO_SEND_SLOTS],
                video_send_meta: vec![SendSlot::default(); VIDEO_SEND_SLOTS],
            }
        }

        /// A peer's session: the same rings, plus a receive ring on video so
        /// what a guest sends can be read back the way a client reads it.
        fn peer<'a>(&'a mut self, video_recv: &'a mut VideoRecv) -> Session<'a> {
            let envelope = Envelope::from_key(&KEY).expect("envelope");
            let mut session = Session::new(envelope, 1, 0.0);
            assert!(attach_recv(
                &mut session,
                CONTROL_CHANNEL,
                &mut self.control_recv_bodies,
                &mut self.control_recv_meta,
            ));
            assert!(attach_send(
                &mut session,
                CONTROL_CHANNEL,
                &mut self.control_send_bodies,
                &mut self.control_send_meta,
            ));
            assert!(attach_recv(
                &mut session,
                VIDEO_CHANNEL,
                &mut video_recv.bodies,
                &mut video_recv.meta,
            ));
            session
        }

        /// A session wired exactly as a guest's is.
        fn session(&mut self) -> Session<'_> {
            let envelope = Envelope::from_key(&KEY).expect("envelope");
            let mut session = Session::new(envelope, 1, 0.0);
            assert!(attach_recv(
                &mut session,
                CONTROL_CHANNEL,
                &mut self.control_recv_bodies,
                &mut self.control_recv_meta,
            ));
            assert!(attach_send(
                &mut session,
                CONTROL_CHANNEL,
                &mut self.control_send_bodies,
                &mut self.control_send_meta,
            ));
            assert!(attach_send(
                &mut session,
                VIDEO_CHANNEL,
                &mut self.video_send_bodies,
                &mut self.video_send_meta,
            ));
            session
        }
    }

    /// The video receive ring a peer has and a host does not.
    struct VideoRecv {
        bodies: Vec<u8>,
        meta: Vec<SlotMeta>,
    }

    impl VideoRecv {
        fn new() -> Self {
            Self {
                bodies: vec![0u8; SLOT * VIDEO_SEND_SLOTS],
                meta: vec![SlotMeta::default(); VIDEO_SEND_SLOTS],
            }
        }
    }

    /// A body the initialization parser accepts, in the shape a peer sends.
    fn declaration() -> Vec<u8> {
        let mut body = br#"{"_version":1,"_max_w":1920,"_max_h":1080,"_flags":8,"resolutionX":1920,"resolutionY":1080,"refreshRate":60}"#.to_vec();
        // The terminating NUL a peer puts on it, which the parser strips.
        body.push(0);
        body
    }

    fn control_bytes(control: &Control<'_>) -> Vec<u8> {
        let mut header = [0u8; lowlat_core::control::CONTROL_HEADER_LEN];
        let written = lowlat_core::control::encode_header(&mut header, control).expect("header");
        let mut out = header[..written].to_vec();
        out.extend_from_slice(control.body);
        out
    }

    /// Move every datagram one session has to send into the other, and report
    /// the largest one that crossed.
    fn pump(from: &mut Session<'_>, into: &mut Session<'_>, now_ms: f64) -> usize {
        let mut datagram = [0u8; lowlat_core::MAX_DATAGRAM];
        let mut scratch = [0u8; lowlat_core::MAX_DATAGRAM];
        let mut largest = 0usize;
        while let Some(result) = from.get_output(now_ms, &mut datagram) {
            let len = result.expect("output");
            largest = largest.max(len);
            let wire = datagram.get(..len).expect("written");
            let _ = into.process_input(wire, now_ms, &mut scratch);
        }
        largest
    }

    /// **The slot width is the fragment width, so it is also the datagram
    /// width.** A ring sized for headroom does not gain headroom; it emits
    /// datagrams no probe has justified, and a peer that cannot take one
    /// discards the whole datagram rather than truncating it. Widening `SLOT`
    /// past the floor fails this. *Named regression test.*
    #[test]
    fn no_emitted_datagram_exceeds_the_floor_the_peer_is_known_to_accept() {
        let mut arena = Arena::new();
        let mut ours = arena.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();

        // Big enough to fragment many times over, so the full-size fragment is
        // the common case here rather than the exception.
        let unit = vec![0xA5u8; 200 * SLOT];
        ours.send_message(VIDEO_CHANNEL, &[], &unit).expect("queue");

        let largest = pump(&mut ours, &mut theirs, 1.0);
        assert!(
            largest <= lowlat_core::DEFAULT_DATAGRAM,
            "emitted a {largest}-byte datagram, past the {}-byte floor",
            lowlat_core::DEFAULT_DATAGRAM
        );
        // And the fragments really were full, or the bound above is vacuous.
        assert_eq!(largest, lowlat_core::DEFAULT_DATAGRAM);
    }

    /// Seal a keepalive that reports `channels` cumulative counts, which is
    /// how a peer's group acknowledgement reveals its channel count and so its
    /// generation.
    fn identifying_keepalive(channels: usize) -> ([u8; 256], usize) {
        use lowlat_core::packet::{Ack, AckKind, encode_ack};
        let ack = Ack {
            reported: channels,
            kind: AckKind::Keepalive,
            nack: false,
            trigger_channel: 0,
            trigger_seq: 0,
            cumulative: [0u32; lowlat_core::packet::CHANNEL_COUNT],
        };
        // encode_ack always writes the full array; the reported prefix is what
        // a shorter datagram would have carried, so truncate to it.
        let mut cleartext = [0u8; 256];
        let full = encode_ack(&mut cleartext, &ack).expect("encode");
        let len = lowlat_core::packet::HEADER_LEN + channels * 4;
        assert!(len <= full);
        let env = Envelope::from_key(&KEY).expect("envelope");
        let mut wire = [0u8; 256];
        let sealed = env.seal(1, &cleartext[..len], &mut wire).expect("seal");
        (wire, sealed)
    }

    /// The video ring is the peer's ring depth, which is also the delivery
    /// gate's top ceiling: a frame the gate admits must fit the ring it is
    /// admitted into. Sizing the ring from control traffic fails this.
    ///
    /// **The top ceiling is the current generation's**, whose peer reports the
    /// full channel count; the send window holds to the shallow floor until it
    /// does, so the peer is identified here exactly as the control handshake
    /// identifies it before any video. *Named regression test.*
    #[test]
    fn the_video_ring_holds_a_frame_as_large_as_the_gate_will_admit() {
        let mut arena = Arena::new();
        let mut session = arena.session();

        let ceiling = crate::gate::ceiling(30.0) as usize;
        assert_eq!(
            ceiling, VIDEO_SEND_SLOTS,
            "the ring and the gate's top ceiling have parted company"
        );

        // A current-generation peer identifies itself by acknowledging with
        // the full channel count, which opens the window to the deep ring.
        let (wire, len) = identifying_keepalive(lowlat_core::packet::CHANNEL_COUNT);
        let mut scratch = [0u8; 256];
        session
            .process_input(&wire[..len], 1.0, &mut scratch)
            .expect("keepalive");

        // Exactly the ceiling's worth of fragments. **The length prefix rides
        // in the first fragment**, so the largest frame that fits is four
        // bytes short of the arithmetic anyone would write down.
        let frame = vec![0u8; ceiling * SLOT - lowlat_core::message::LENGTH_PREFIX_LEN];
        let queued = session
            .send_message(VIDEO_CHANNEL, &[], &frame)
            .expect("a frame at the ceiling was refused");
        assert_eq!(queued as usize, ceiling);

        // And nothing beyond it: the window is the peer's depth, not ours to
        // exceed.
        assert!(
            session.send_message(VIDEO_CHANNEL, &[], &[0u8; 1]).is_err(),
            "the ring accepted a fragment past the peer's ring depth"
        );
    }

    /// Before the peer is identified the window holds to the shallow-ring
    /// floor, and a peer that acknowledges with fewer than the full channel
    /// count -- an older generation -- never opens it. *Named regression
    /// test.*
    #[test]
    fn an_unidentified_peer_holds_the_window_to_the_floor() {
        use lowlat_core::channel::PEER_RING_FLOOR;
        let floor = PEER_RING_FLOOR as usize;

        let mut arena = Arena::new();
        let mut session = arena.session();

        // A frame at the floor fits; one fragment past it does not, with no
        // acknowledgement seen yet.
        let frame = vec![0u8; floor * SLOT - lowlat_core::message::LENGTH_PREFIX_LEN];
        assert_eq!(
            session
                .send_message(VIDEO_CHANNEL, &[], &frame)
                .expect("a frame at the floor was refused") as usize,
            floor
        );
        assert!(
            session.send_message(VIDEO_CHANNEL, &[], &[0u8; 1]).is_err(),
            "ran past the floor against an unidentified peer"
        );

        // A four-channel peer is the shallow generation and does not open it.
        let (wire, len) = identifying_keepalive(4);
        let mut scratch = [0u8; 256];
        session
            .process_input(&wire[..len], 1.0, &mut scratch)
            .expect("keepalive");
        assert!(
            session.send_message(VIDEO_CHANNEL, &[], &[0u8; 1]).is_err(),
            "a short acknowledgement opened the window past the floor"
        );
    }

    /// Records what a guest's devices would have been written.
    #[derive(Debug, Default)]
    struct Recorder {
        events: Vec<(lowlat_inject::event::Device, lowlat_inject::event::Event)>,
    }

    impl lowlat_inject::event::Sink for Recorder {
        fn emit(
            &mut self,
            device: lowlat_inject::event::Device,
            events: &[lowlat_inject::event::Event],
        ) {
            self.events
                .extend(events.iter().map(|event| (device, *event)));
        }
    }

    /// A pointer nobody is arbitrating, for the tests that are not about it.
    fn no_pointer() -> Pointer<'static> {
        static FREE: std::sync::OnceLock<crate::floor::Floor> = std::sync::OnceLock::new();
        Pointer {
            floor: FREE.get_or_init(|| crate::floor::Floor::new(false)),
            guest: 1,
            owner: false,
            now_ms: 0.0,
        }
    }

    fn recording_input() -> Input<Recorder> {
        Input {
            injector: Injector::new(Extents::alone(1920, 1080)),
            sink: Recorder::default(),
        }
    }

    /// Send control messages from a peer and drain them into the host.
    fn drain_from_peer(
        input: Option<&mut Input<Recorder>>,
        messages: &[Control<'_>],
    ) -> Negotiation {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();
        for message in messages {
            theirs
                .send_message(CONTROL_CHANNEL, &[], &control_bytes(message))
                .expect("queue");
        }
        pump(&mut theirs, &mut ours, 1.0);

        let mut negotiation = Negotiation::opened(0.0);
        let mut inbound = vec![0u8; MAX_INBOUND];
        drain_control(
            &mut ours,
            &mut negotiation,
            input,
            no_pointer(),
            &mut inbound,
            Consumers {
                count: &mut 0,
                said: &mut |_| {},
                ear: None,
                census: &mut [false; 256],
                telemetry: &Telemetry::default(),
            },
        )
        .expect("drained");
        negotiation
    }

    /// The same, reporting what the peer's messages left in a guest's
    /// telemetry rather than what they left in the negotiation.
    fn telemetry_from_peer(messages: &[Control<'_>]) -> Metrics {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();
        for message in messages {
            theirs
                .send_message(CONTROL_CHANNEL, &[], &control_bytes(message))
                .expect("queue");
        }
        pump(&mut theirs, &mut ours, 1.0);

        let telemetry = Telemetry::default();
        let mut negotiation = Negotiation::opened(0.0);
        let mut inbound = vec![0u8; MAX_INBOUND];
        drain_control(
            &mut ours,
            &mut negotiation,
            NO_INPUT,
            no_pointer(),
            &mut inbound,
            Consumers {
                count: &mut 0,
                said: &mut |_| {},
                ear: None,
                census: &mut [false; 256],
                telemetry: &telemetry,
            },
        )
        .expect("drained");
        telemetry.read()
    }

    /// **The one figure a host cannot measure, kept rather than dropped.** A
    /// peer volunteers what its decoder costs it, and the arguments are
    /// transposed against the outbound form: microseconds first, then the kind.
    /// Reading it with the outbound layout yields a latency of nothing, which
    /// is exactly what it looked like before.
    #[test]
    fn a_peers_decode_report_lands_on_the_channel_it_names() {
        let read = telemetry_from_peer(&[
            Control {
                a0: 1922,
                a1: 1,
                a2: 0,
                opcode: op::ENCODE_LATENCY,
                body: &[],
            },
            Control {
                a0: 4000,
                a1: 2,
                a2: 0,
                opcode: op::ENCODE_LATENCY,
                body: &[],
            },
        ]);
        assert!(
            (read.video.decode_ms - 1.922).abs() < 1e-4,
            "video decode was {}",
            read.video.decode_ms
        );
        assert!(
            (read.audio.decode_ms - 4.0).abs() < 1e-4,
            "audio decode was {}",
            read.audio.decode_ms
        );
        assert!(
            read.control.decode_ms.abs() < f32::EPSILON,
            "control is not decoded and must not carry a figure"
        );
    }

    /// An older peer reports a decode time and names no kind at all. Taking
    /// the zero as video recovers a figure that would otherwise be discarded,
    /// and no peer sends a zero meaning anything else.
    #[test]
    fn a_decode_report_with_no_kind_is_taken_as_video() {
        let read = telemetry_from_peer(&[Control {
            a0: 2500,
            a1: 0,
            a2: 0,
            opcode: op::ENCODE_LATENCY,
            body: &[],
        }]);
        assert!(
            (read.video.decode_ms - 2.5).abs() < 1e-4,
            "video decode was {}",
            read.video.decode_ms
        );
    }

    /// A kind this host does not know is passed over rather than landing
    /// somewhere. The protocol is additive, and guessing which channel a new
    /// kind belongs to would report a number against the wrong one.
    #[test]
    fn a_decode_report_of_an_unknown_kind_lands_nowhere() {
        let read = telemetry_from_peer(&[Control {
            a0: 9000,
            a1: 7,
            a2: 0,
            opcode: op::ENCODE_LATENCY,
            body: &[],
        }]);
        assert!(read.video.decode_ms.abs() < f32::EPSILON);
        assert!(read.audio.decode_ms.abs() < f32::EPSILON);
        assert!(read.control.decode_ms.abs() < f32::EPSILON);
    }

    /// **A count that wraps reads as a session that just started.** The
    /// transport counters are cumulative and sixty-four bit; what a reader is
    /// given is thirty-two, and pinning it at the ceiling is wrong by a
    /// knowable amount where a wrap is wrong by an unknowable one.
    #[test]
    fn a_counter_past_the_reported_width_pins_rather_than_wraps() {
        let telemetry = Telemetry::default();
        telemetry.channel_measured(
            Channel::Video,
            ChannelSample {
                packets_sent: u64::from(u32::MAX) + 1,
                fast_rts: 3,
                slow_rts: 4,
                mbps: 0.0,
                encode_ms: 0.0,
            },
        );
        let read = telemetry.read();
        assert_eq!(read.video.packets_sent, u32::MAX);
        assert_eq!(read.video.fast_rts, 3);
        assert_eq!(read.video.slow_rts, 4);
    }

    /// A control message longer than the old 64 KiB take buffer but inside
    /// the protocol's ceiling is delivered, not fatal. A take that does not
    /// fit ends the attempt, so an undersized buffer turned a legal message
    /// into a dead session.
    #[test]
    fn a_user_data_message_past_sixty_four_kib_is_delivered() {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();

        let text = vec![b'q'; 100 * 1024];
        let mut body = text.clone();
        body.push(0);
        theirs
            .send_message(
                CONTROL_CHANNEL,
                &[],
                &control_bytes(&Control {
                    a0: u32::try_from(body.len()).expect("length"),
                    a1: 7,
                    a2: 0,
                    opcode: op::USER_DATA,
                    body: &body,
                }),
            )
            .expect("queue");
        pump(&mut theirs, &mut ours, 1.0);

        let mut negotiation = Negotiation::opened(0.0);
        let mut inbound = vec![0u8; MAX_INBOUND];
        let mut heard: Option<(u32, Vec<u8>)> = None;
        drain_control(
            &mut ours,
            &mut negotiation,
            NO_INPUT,
            no_pointer(),
            &mut inbound,
            Consumers {
                count: &mut 0,
                said: &mut |said| heard = Some(said),
                ear: None,
                census: &mut [false; 256],
                telemetry: &Telemetry::default(),
            },
        )
        .expect("a message inside the protocol ceiling ended the attempt");

        let (id, heard) = heard.expect("the message was not handed up");
        assert_eq!(id, 7);
        assert_eq!(heard, text);
    }

    /// **Both consumers of the control channel get what is theirs.** The
    /// declaration and the input share one channel and one drain, and before
    /// there was anywhere to put input the drain counted it as unhandled and
    /// dropped it. Everything below this is covered by the inject crate; what
    /// is covered nowhere else is that the guest loop hands the message over
    /// at all, and that adding a second consumer did not cost the first one.
    #[test]
    fn both_consumers_of_the_control_channel_get_what_is_theirs() {
        let mut input = recording_input();
        let body = declaration();
        let negotiation = drain_from_peer(
            Some(&mut input),
            &[
                Control {
                    a0: 0,
                    a1: 0,
                    a2: 0,
                    opcode: op::INIT,
                    body: &body,
                },
                Control {
                    a0: 4,
                    a1: 0,
                    a2: 1,
                    opcode: op::KEYBOARD,
                    body: &[],
                },
            ],
        );

        assert!(negotiation.ready(), "the declaration was not taken");
        let keys: Vec<(u16, i32)> = input
            .sink
            .events
            .iter()
            .filter(|(_, e)| e.kind == 0x01)
            .map(|(_, e)| (e.code, e.value))
            .collect();
        assert_eq!(keys, vec![(30, 1)], "the keystroke did not reach injection");
    }

    /// Two guests through the real drain, sharing one arbiter.
    fn two_guests_move(exclusive: bool, gap_ms: f64) -> (Recorder, Recorder) {
        let floor = crate::floor::Floor::new(exclusive);
        let motion = Control {
            a0: 0,
            a1: 100,
            a2: 100,
            opcode: op::MOUSE_MOTION,
            body: &[],
        };
        let mut first = recording_input();
        let mut second = recording_input();
        // The first moves, the second tries while the first still holds it,
        // and then the first moves again.
        for (guest, at) in [(1u32, 0.0), (2, gap_ms), (1, gap_ms + 1.0)] {
            let input = if guest == 1 { &mut first } else { &mut second };
            drain_one(
                input,
                Pointer {
                    floor: &floor,
                    guest,
                    owner: false,
                    now_ms: at,
                },
                &motion,
            );
        }
        (first.sink, second.sink)
    }

    fn drain_one(input: &mut Input<Recorder>, pointer: Pointer<'_>, message: &Control<'_>) {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();
        theirs
            .send_message(CONTROL_CHANNEL, &[], &control_bytes(message))
            .expect("queue");
        pump(&mut theirs, &mut ours, 1.0);
        let mut negotiation = Negotiation::opened(0.0);
        let mut inbound = vec![0u8; MAX_INBOUND];
        drain_control(
            &mut ours,
            &mut negotiation,
            Some(input),
            pointer,
            &mut inbound,
            Consumers {
                count: &mut 0,
                said: &mut |_| {},
                ear: None,
                census: &mut [false; 256],
                telemetry: &Telemetry::default(),
            },
        )
        .expect("drained");
    }

    /// **With it off, both guests drive at once**, which is the default and
    /// the ordinary case of two people sharing a desktop.
    #[test]
    fn both_guests_drive_the_pointer_when_it_is_not_arbitrated() {
        let (first, second) = two_guests_move(false, 1.0);
        assert!(!first.events.is_empty());
        assert!(!second.events.is_empty());
    }

    /// With it on, the one that moved first keeps it while it keeps moving.
    #[test]
    fn the_guest_that_moved_first_keeps_the_pointer() {
        let (first, second) = two_guests_move(true, 1.0);
        assert!(
            !first.events.is_empty(),
            "the first guest lost its own pointer"
        );
        assert!(
            second.events.is_empty(),
            "a second guest drove at the same time"
        );
    }

    /// And hands it over once it stops.
    #[test]
    fn the_pointer_goes_to_the_next_guest_once_the_first_stops() {
        let (_first, second) = two_guests_move(true, crate::floor::HOLD_MS);
        assert!(!second.events.is_empty(), "the pointer never changed hands");
    }

    /// **The guest that lost the pointer lets go of what it was holding.** It
    /// went quiet, so nothing it sends will ever say so; only the pass notices.
    /// Without this a button stays down on a machine somebody else is driving,
    /// because the release arrives after the handover and is dropped with the
    /// rest of that guest's pointer input.
    #[test]
    fn a_guest_that_loses_the_pointer_lets_go_of_its_buttons() {
        let floor = crate::floor::Floor::new(true);
        let mut holder = recording_input();
        let press = Control {
            a0: 1,
            a1: 1,
            a2: 0,
            opcode: op::MOUSE_BUTTON,
            body: &[],
        };
        drain_one(
            &mut holder,
            Pointer {
                floor: &floor,
                guest: 1,
                owner: false,
                now_ms: 0.0,
            },
            &press,
        );
        assert!(!holder.sink.events.is_empty(), "the press never landed");
        holder.sink.events.clear();

        // It goes quiet, and somebody else takes over.
        let later = crate::floor::HOLD_MS + 1.0;
        assert!(floor.claim(2, false, later));

        follow_pointer(&mut holder, &floor, 1, later);
        let released: Vec<u16> = holder
            .sink
            .events
            .iter()
            .filter(|(_, e)| e.kind == 0x01 && e.value == 0)
            .map(|(_, e)| e.code)
            .collect();
        assert_eq!(released, vec![0x110], "the button was left down");
    }

    /// The whole defect, through the drain: a guest holds a button, pauses
    /// longer than the hold, and must still have the pointer and its button.
    #[test]
    fn a_paused_drag_keeps_both_the_pointer_and_its_button() {
        let floor = crate::floor::Floor::new(true);
        let mut dragger = recording_input();
        drain_one(
            &mut dragger,
            Pointer {
                floor: &floor,
                guest: 1,
                owner: false,
                now_ms: 0.0,
            },
            &Control {
                a0: 1,
                a1: 1,
                a2: 0,
                opcode: op::MOUSE_BUTTON,
                body: &[],
            },
        );
        dragger.sink.events.clear();

        // It pauses, for four times the hold, saying nothing at all.
        let mut now = 0.0;
        for _ in 0..8 {
            now += crate::floor::HOLD_MS / 2.0;
            follow_pointer(&mut dragger, &floor, 1, now);
        }
        assert!(
            dragger.sink.events.is_empty(),
            "a paused drag had its button taken away"
        );
        assert!(
            !floor.claim(2, false, now),
            "another guest took the pointer mid-drag"
        );
    }

    /// A guest that still has it is left alone. **It has to be holding
    /// something for this to mean anything**: a pass that released
    /// unconditionally would emit nothing here either, and the check would
    /// pass while every button came up on every pass.
    #[test]
    fn a_guest_that_still_has_the_pointer_is_not_disturbed() {
        let floor = crate::floor::Floor::new(true);
        let mut holder = recording_input();
        drain_one(
            &mut holder,
            Pointer {
                floor: &floor,
                guest: 1,
                owner: false,
                now_ms: 0.0,
            },
            &Control {
                a0: 1,
                a1: 1,
                a2: 0,
                opcode: op::MOUSE_BUTTON,
                body: &[],
            },
        );
        assert!(!holder.sink.events.is_empty(), "the press never landed");
        holder.sink.events.clear();

        follow_pointer(&mut holder, &floor, 1, 10.0);
        assert!(
            holder.sink.events.is_empty(),
            "a guest still holding the pointer had its button taken away"
        );
    }

    /// **A quarter turn swaps the extents and nothing else.** The peer sends
    /// coordinates in the desktop's orientation already; a host that also
    /// rotated them would put the pointer at a right angle to where it was
    /// asked for, which reads as an input bug rather than a geometry one.
    #[test]
    fn a_quarter_turn_swaps_the_extents_and_a_half_turn_does_not() {
        let upright = desktop_extents(1920, 1080, Rotation::None, None);
        assert_eq!((upright.width, upright.height), (1920, 1080));
        for rotation in [Rotation::Deg90, Rotation::Deg270] {
            let turned = desktop_extents(1920, 1080, rotation, None);
            assert_eq!((turned.width, turned.height), (1080, 1920), "{rotation:?}");
        }
        // A half turn leaves the shape alone, so swapping there would be a
        // pointer that works upright and breaks upside down.
        let half = desktop_extents(1920, 1080, Rotation::Deg180, None);
        assert_eq!((half.width, half.height), (1920, 1080));
    }

    /// **The terminator is written whether or not the caller supplied one**,
    /// and never twice. An established peer reads the body as a C string, so a
    /// body that ends without one is read past; and the declared length counts
    /// both, so a second terminator becomes part of the message.
    #[test]
    fn an_application_message_is_terminated_exactly_once() {
        for text in [&b"hello"[..], b"hello\0"] {
            let mut body = Vec::new();
            body.extend_from_slice(text.strip_suffix(&[0]).unwrap_or(text));
            body.push(0);
            assert_eq!(body, b"hello\0", "text={text:?}");
            assert_eq!(
                body.len(),
                lowlat_core::control::string_body_len(5),
                "the length a peer is told must count the terminator once"
            );
        }
    }

    /// **A message longer than a peer will take is refused before it is sent.**
    /// The far end drops it without a word, so a sender that does not check
    /// loses the message with no way to find out.
    ///
    /// **Tested at the boundary and not through the send**, which was tried
    /// and proved nothing: with no guest to aim at, a message refused for its
    /// length and one refused for having nowhere to go are the same answer,
    /// and removing the check entirely left the test passing.
    #[test]
    fn the_cap_counts_the_terminator_that_travels_with_the_text() {
        let max = lowlat_core::control::USER_DATA_MAX;
        assert!(
            !past_the_cap(&vec![b'x'; max - 1]),
            "the largest body that fits was refused"
        );
        assert!(
            past_the_cap(&vec![b'x'; max]),
            "a text of exactly the maximum makes a body one byte over it"
        );
    }

    /// A guest that is not there is not an error, and not a send either.
    #[test]
    fn an_application_message_to_nobody_reaches_nobody() {
        let mut seam = Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            base_port: 0,
            shared_address_space: false,
            max_guests: 1,
            servers: Vec::new(),
            stream: None,
        });
        assert!(!seam.send_user_data(1, 0, b"hello"));
        assert_eq!(seam.send_user_data_all(0, b"hello"), 0);
    }

    /// A guest with no devices is still a guest: its input is dropped and
    /// everything else about the session carries on.
    #[test]
    fn a_guest_without_devices_still_negotiates() {
        let body = declaration();
        let negotiation = drain_from_peer(
            None,
            &[Control {
                a0: 0,
                a1: 0,
                a2: 0,
                opcode: op::INIT,
                body: &body,
            }],
        );
        assert!(negotiation.ready());
    }

    /// **The declaration arrives on channel 0, and nothing else reports it.**
    /// A guest whose control channel is unattached has its declaration counted
    /// as unhandled and dropped, while the group acknowledgement reports zero
    /// for that channel forever, so the peer retransmits it until it gives up.
    /// Attaching video alone fails this. *Named regression test.*
    #[test]
    fn a_peers_declaration_reaches_the_negotiation_through_the_real_rings() {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();

        let body = declaration();
        let message = control_bytes(&Control {
            a0: 0,
            a1: 0,
            a2: 0,
            opcode: op::INIT,
            body: &body,
        });
        theirs
            .send_message(CONTROL_CHANNEL, &[], &message)
            .expect("queue");
        pump(&mut theirs, &mut ours, 1.0);

        let mut negotiation = Negotiation::opened(0.0);
        let mut inbound = vec![0u8; MAX_INBOUND];
        drain_control(
            &mut ours,
            &mut negotiation,
            NO_INPUT,
            no_pointer(),
            &mut inbound,
            Consumers {
                count: &mut 0,
                said: &mut |_| {},
                ear: None,
                census: &mut [false; 256],
                telemetry: &Telemetry::default(),
            },
        )
        .expect("drained");

        assert!(
            negotiation.ready(),
            "the declaration did not reach the negotiation"
        );
        let asked = negotiation.asked().expect("what the peer asked for");
        assert_eq!((asked.max_width, asked.max_height), (1920, 1080));
        assert_eq!(asked.refresh_rate, 60);
    }

    /// **The guest's whole outbound half, end to end.** A coded frame is
    /// framed, fragmented, sealed, carried, reassembled, and read back as the
    /// video message a client reads: the header at the offsets section 11.3
    /// fixes, then the bitstream, byte for byte.
    ///
    /// Every earlier check stops short of this. The packetiser's own tests
    /// read the header out of a fragment it wrote; the corpus comparison
    /// checks headers against a recording. Neither sends anything through a
    /// send ring, and the send ring is where the fragment sizing and the
    /// window live.
    #[test]
    fn a_coded_frame_crosses_to_a_peer_whole() {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut video = VideoRecv::new();
        let mut theirs = theirs.peer(&mut video);

        // Big enough to fragment many times, with content that is a function
        // of its offset so a misplaced fragment cannot pass.
        let unit: Vec<u8> = (0..40_000u32).map(|at| (at % 251) as u8).collect();
        let mut packetiser = Packetiser::new(1920, 1080, lowlat_core::video::Rotation::None, false);
        let header = packetiser.header(true).expect("header").to_vec();
        ours.send_message(VIDEO_CHANNEL, &header, &unit)
            .expect("queue");

        // Several passes: the outstanding cap releases a bounded number of
        // fragments per pass, so one drain does not carry a frame this size.
        let mut taken = Vec::new();
        for round in 0..64 {
            let now = f64::from(round) * 20.0;
            pump(&mut ours, &mut theirs, now);
            pump(&mut theirs, &mut ours, now);
            let mut out = vec![0u8; 64 * 1024];
            if let Some(Ok(len)) = theirs.take_message(VIDEO_CHANNEL, &mut out) {
                out.truncate(len);
                taken = out;
                break;
            }
        }

        assert!(!taken.is_empty(), "the frame never arrived whole");
        let (head, body) = taken.split_at(lowlat_core::video::VIDEO_HEADER_LEN);
        let parsed = lowlat_core::video::parse(head).expect("a video header");
        assert_eq!((parsed.width, parsed.height), (1920, 1080));
        assert_eq!(parsed.rotation, lowlat_core::video::Rotation::None);
        assert!(
            !parsed.ten_bit,
            "an eight-bit stream claimed ten-bit colour on the wire"
        );
        assert_eq!(body, unit, "the bitstream did not arrive intact");
    }

    /// **The generation a peer is told is the generation its frames carry.**
    /// Announced on the frame after the encoder is ready and repeated in every
    /// video header, so the two are read from one place or they disagree, and
    /// a peer that trusted either would be tracking a reference chain that
    /// does not exist. *Named regression test.*
    #[test]
    fn the_announced_generation_is_the_one_the_header_carries() {
        let mut packetiser = Packetiser::new(1920, 1080, lowlat_core::video::Rotation::None, false);
        let mut negotiation = Negotiation::opened(0.0);
        let body = declaration();
        let raw = control_bytes(&Control {
            a0: 0,
            a1: 0,
            a2: 0,
            opcode: op::INIT,
            body: &body,
        });
        let declared = control::parse(&raw).expect("parsed");
        assert!(negotiation.on_control(&declared));
        assert!(negotiation.ready());

        negotiation.encoder_initialised(packetiser.generation());
        let reports = negotiation.on_frame(3.0);
        let announced = reports.generation_message(0).expect("an announcement");
        assert_eq!(announced.opcode, op::ENCODER_GENERATION);
        assert_eq!(announced.a0, 0, "the stream index is argument zero");

        let header = packetiser.header(true).expect("header");
        let carried = lowlat_core::video::parse(header).expect("a video header");
        assert_eq!(
            announced.a1, carried.frame_id,
            "the announcement and the header disagree about the generation"
        );

        // Once only. A second announcement would tell a peer the chain
        // restarted when nothing did.
        assert!(negotiation.on_frame(3.0).generation_message(0).is_none());
    }

    /// A take that does not fit does not consume the message, so the same one
    /// is read again on the next pass and every pass after it. Reporting it
    /// costs a session; spinning on it costs a core, silently.
    /// *Named regression test.*
    #[test]
    fn a_message_too_long_to_take_ends_the_attempt_rather_than_spinning() {
        let mut ours = Arena::new();
        let mut ours = ours.session();
        let mut theirs = Arena::new();
        let mut theirs = theirs.session();

        let body = vec![b'x'; 4096];
        theirs
            .send_message(CONTROL_CHANNEL, &[], &body)
            .expect("queue");
        pump(&mut theirs, &mut ours, 1.0);

        let mut negotiation = Negotiation::opened(0.0);
        // Shorter than the message that arrived, which is the condition the
        // real buffer is sized to avoid.
        let mut inbound = vec![0u8; 1024];
        assert_eq!(
            drain_control(
                &mut ours,
                &mut negotiation,
                NO_INPUT,
                no_pointer(),
                &mut inbound,
                Consumers {
                    count: &mut 0,
                    said: &mut |_| {},
                    ear: None,
                    census: &mut [false; 256],
                    telemetry: &Telemetry::default(),
                }
            ),
            Err(Outcome::ControlStalled),
            "a message that cannot be taken was not reported"
        );
    }
}

#[cfg(test)]
mod reclamation {
    use super::tests_support::*;
    use super::*;

    /// A guest that ends gives its port back, so the next one lands on the base
    /// again rather than walking past it. *Named regression test.*
    ///
    /// The failure this guards is slow and silent: a host that never reclaims
    /// walks one port further per session and, after enough of them, cannot
    /// admit anyone at all. It took a live run to notice, because every short
    /// test admits one guest and stops.
    #[test]
    fn a_port_is_reclaimed_when_its_guest_ends() {
        let probe = Socket::open(0).expect("probe");
        let base = probe.local_addr().expect("addr").port();
        drop(probe);

        let mut seam = Admission::new(Config {
            microphone: None,
            exclusive_pointer: false,
            rumble_probe: false,
            exclusive_hold_ms: crate::floor::HOLD_MS,
            cg_level: 1,
            base_port: base,
            shared_address_space: false,
            max_guests: 4,
            servers: Vec::new(),
            stream: None,
        });

        let mut ports = Vec::new();
        for round in 0..4 {
            let id = format!("guest-{round}");
            seam.new_attempt(&id, peer()).expect("register");
            ports.push(seam.begin_p2p(&id, 0).expect("approve").port);
            seam.end_connection(&id);
        }

        assert_eq!(
            ports,
            vec![base; 4],
            "the port walked instead of being reclaimed"
        );
        assert_eq!(seam.occupancy(), 0);
    }
}
