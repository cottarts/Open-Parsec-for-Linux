#!/usr/bin/env python3
"""Open Parsec native management UI, using the authenticated local host channel."""
import ctypes, json, os, shlex, socket, subprocess, threading, sys
from pathlib import Path
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk, GLib, Gio, GdkPixbuf
import control
LOGO=Path(__file__).with_name("assets")/"openparsec.png"
from host_channel import Channel

class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id='org.openparsec.Desktop',flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.directory=Path(GLib.get_user_config_dir())/'openparsec'
        self.state={};self.online=False;self.fields={};self.busy=False
        self.background = '--background' in sys.argv
        self.connect('activate',self.activate_ui)
    def activate_ui(self,*_):
        if hasattr(self,'window'):self.window.show_all();self.window.present();return
        self.hold()
        self.window=Gtk.ApplicationWindow(application=self,title='Open Parsec')
        self.window.set_icon_from_file(str(LOGO))
        self.window.set_default_size(780,620)
        self.window.connect('delete-event',lambda w,e:(w.hide() or True))
        css=Gtk.CssProvider();css.load_from_data(b'window { background: #1a1a1c; color: #ffffff; } .nav { background: #1f1f21; padding: 8px; } .title { font-size: 20px; font-weight: 500; } .subtitle { color: #99999d; } button { background: #29292d; color: #a040ff; border: none; box-shadow: none; padding: 8px 14px; } button.primary { background: #a040ff; color: white; border-radius: 8px; } entry, spinbutton, combobox { min-height: 30px; } .card { background: #333334; border-radius: 8px; padding: 24px; }')
        Gtk.StyleContext.add_provider_for_screen(self.window.get_screen(),css,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        outer=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);self.window.add(outer)
        top=Gtk.Box(spacing=8);top.get_style_context().add_class('nav');outer.pack_start(top,False,False,0)
        self.button(top,'↪',self.account_dialog)
        self.count=Gtk.Label(label='Open Parsec');top.pack_start(self.count,True,True,0)
        self.button(top,'↻',self.refresh)
        self.button(top,'⚙',self.settings_dialog)
        self.stack=Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        outer.pack_start(self.stack,True,True,0)
        self.home();self.sessions_page()
        bottom=Gtk.Box(homogeneous=True,spacing=16);bottom.get_style_context().add_class('nav');outer.pack_end(bottom,False,False,0)
        self.button(bottom,'▣  Hosts',lambda:self.stack.set_visible_child_name('home'))
        self.button(bottom,'♙  Sessions',lambda:self.stack.set_visible_child_name('sessions'))
        self.message=Gtk.Label(xalign=0,margin=8,wrap=True);outer.pack_end(self.message,False,False,0)
        self.tray();self.channel=Channel(lambda online,state:GLib.idle_add(self.render,online,state))
        if not self.background:self.window.show_all()
        self.background=False
    def page(self,title,key):
        scroll=Gtk.ScrolledWindow();box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=16,margin=28)
        scroll.add(box);self.stack.add_titled(scroll,key,title);return box
    def refresh(self):
        self.render(self.online,self.state);self.tell('Host status refreshed.')
    def account_dialog(self):
        dialog=Gtk.Dialog(title='Parsec account',transient_for=self.window,modal=True)
        dialog.add_button('Close',Gtk.ResponseType.CLOSE)
        box=dialog.get_content_area();box.set_margin_start(24);box.set_margin_end(24);box.set_spacing(16)
        self.text(box,'Sign in to make this host available to Parsec clients.')
        self.button(box,'Sign in',lambda:self.terminal(['sudo','open-parsec-login','--install']))
        self.button(box,'Open Parsec client',self.open_parsec)
        dialog.show_all();dialog.run();dialog.destroy()
    def settings_dialog(self):
        dialog=Gtk.Dialog(title='Settings',transient_for=self.window,modal=True)
        dialog.set_default_size(480,420);dialog.add_button('Close',Gtk.ResponseType.CLOSE)
        box=dialog.get_content_area();box.set_spacing(12);box.set_margin_start(24);box.set_margin_end(24)
        self.settings(box)
        dialog.show_all();dialog.run();dialog.destroy()
        self.fields={}
    def text(self,box,text):
        label=Gtk.Label(label=text,xalign=0,wrap=True,selectable=True);box.pack_start(label,False,False,0);return label
    def button(self,box,text,fn):
        button=Gtk.Button(label=text);button.connect('clicked',lambda *_:fn());box.pack_start(button,False,False,0);return button
    def tell(self,text):self.message.set_text(text)
    def home(self):
        box=self.page('Hosts','home')
        center=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=18);center.set_halign(Gtk.Align.CENTER);center.set_size_request(400,-1)
        box.pack_start(center,False,False,10)
        card=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);card.get_style_context().add_class('card');center.add(card)
        image=Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(str(LOGO),64,64,True));card.add(image)
        config=control.load(self.directory)
        self.hostname=Gtk.Label(label=config['name'] if config['name']!='Open Parsec' else socket.gethostname());self.hostname.get_style_context().add_class('title');card.add(self.hostname)
        self.status=Gtk.Label(label='Connecting to host…');self.status.get_style_context().add_class('subtitle');card.add(self.status)
        self.stream=Gtk.Label(wrap=True,justify=Gtk.Justification.CENTER);card.add(self.stream)
        self.host_action=self.button(card,'Start hosting',self.toggle_host);self.host_action.get_style_context().add_class('primary')
        self.text(center,'This computer • Linux host').set_halign(Gtk.Align.CENTER)
    def toggle_host(self):
        self.terminal(['sudo','systemctl','stop' if self.online else 'start','open-parsecd.service'])
    def sessions_page(self):
        box=self.page('Sessions','sessions')
        self.guests=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);box.pack_start(self.guests,False,False,0)
    def settings(self,box):
        config=control.load(self.directory)
        grid=Gtk.Grid(column_spacing=20,row_spacing=12);box.pack_start(grid,False,False,0)
        specs=[('name','Computer name',None),('codec','Codec',['h264','hevc']),('encoder','Encoder',['auto','nvenc','vaapi']),('fps','Frames per second',(15,144)),('bitrate','Maximum bitrate (Mbps)',(2,100)),('output','Default display',None)]
        for i,(key,title,choices) in enumerate(specs):
            grid.attach(Gtk.Label(label=title,xalign=0),0,i,1,1)
            if isinstance(choices,list):
                widget=Gtk.ComboBoxText()
                for value in choices:widget.append(value,value.upper())
                widget.set_active_id(config[key])
            elif choices:
                widget=Gtk.SpinButton.new_with_range(*choices,1);widget.set_value(config[key])
            else:widget=Gtk.Entry(text=config[key])
            widget.set_hexpand(True);grid.attach(widget,1,i,1,1);self.fields[key]=widget
        self.allow=Gtk.CheckButton(label='Allow Parsec guests');self.allow.set_active(config['allow_guests']);box.pack_start(self.allow,False,False,0)
        self.text(box,'Leave display empty for automatic selection. Available codecs depend on your hardware.')
        self.button(box,'Save settings',self.save)
        self.button(box,'Apply and restart host',self.apply)
    def values(self):
        result=control.load(self.directory)
        for key,widget in self.fields.items():
            result[key]=widget.get_active_id() if isinstance(widget,Gtk.ComboBoxText) else widget.get_value_as_int() if isinstance(widget,Gtk.SpinButton) else widget.get_text()
        result['allow_guests']=self.allow.get_active();result['owner_uid']=os.getuid()
        return control.checked(result)
    def save(self):
        try:control.save(self.directory,self.values());self.hostname.set_text(self.values()['name']);self.tell('Settings saved.');return True
        except (ValueError,OSError) as error:self.tell(str(error));return False
    def apply(self):
        if self.save():
            # Root executes fixed system tools; data was checked before export.
            source=str(self.directory/'settings.env')
            command='sudo install -m 600 '+shlex.quote(source)+' /etc/openparsec/settings.env && sudo systemctl restart open-parsecd.service'
            self.terminal(['/bin/sh','-c',command])
    def terminal(self,argv):
        terminal=GLib.find_program_in_path('x-terminal-emulator')
        if not terminal:self.tell('No terminal available for sudo authentication.');return
        subprocess.Popen([terminal,'-e',*argv]);self.tell('Action opened in the terminal. Enter your password there.')
    def request(self,message):
        try:self.channel.request(message);self.tell('Request sent to host. Status will update automatically.')
        except (OSError,ValueError) as error:self.tell(str(error))
    def open_parsec(self):
        if Path('/usr/bin/parsecd').exists():subprocess.Popen(['/usr/bin/parsecd'])
        else:self.tell('Official Parsec client is not installed.')
    def render(self,online,state):
        self.online=online;self.state=state
        guests=state.get('guests',[])
        text=('Host online • '+str(len(guests))+' session(s)' if guests else 'Host online • idle') if online else 'Host unavailable'
        self.status.set_text(text);self.tray_status.set_label(text)
        self.count.set_text('1 local host' if online else 'Local host offline')
        self.host_action.set_label('Stop hosting' if online else 'Start hosting')
        self.stream.set_text(f"{state.get('output','')}  •  {state.get('width',0)} × {state.get('height',0)}  •  {state.get('fps',0)} FPS  •  {state.get('codec','').upper()}  •  {state.get('bitrate',0)} Mbps" if guests else 'Ready for a remote connection' if online else 'Start hosting to accept a connection.')
        for child in self.guests.get_children():self.guests.remove(child)
        if not guests:self.text(self.guests,'No clients connected.').set_halign(Gtk.Align.CENTER)
        for guest in guests:
            row=Gtk.Box(spacing=12);row.get_style_context().add_class('card');name=str(guest.get('name') or 'Remote client')
            row.pack_start(Gtk.Label(label=name+(' • connected' if guest.get('connected') else ' • connecting'),xalign=0),True,True,0)
            self.button(row,'Disconnect',lambda ident=guest.get('id'):self.request({'kick':ident}));self.guests.pack_start(row,False,False,0)
        self.guests.show_all()
        self.lib.app_indicator_set_icon_full(self.indicator,os.fsencode(LOGO),text.encode())
    def tray(self):
        self.lib=ctypes.CDLL('libayatana-appindicator3.so.1')
        self.lib.app_indicator_new.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];self.lib.app_indicator_new.restype=ctypes.c_void_p
        self.lib.app_indicator_set_status.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.lib.app_indicator_set_menu.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
        self.lib.app_indicator_set_icon_full.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
        ctypes.pythonapi.PyCapsule_GetPointer.argtypes=[ctypes.py_object,ctypes.c_char_p];ctypes.pythonapi.PyCapsule_GetPointer.restype=ctypes.c_void_p
        self.indicator=self.lib.app_indicator_new(b'open-parsec',os.fsencode(LOGO),0);self.lib.app_indicator_set_status(self.indicator,1)
        self.menu=Gtk.Menu();self.tray_status=Gtk.MenuItem(label='Open Parsec');self.tray_status.set_sensitive(False);self.menu.append(self.tray_status)
        for title,callback in [('Show Open Parsec',lambda:self.activate()),('Parsec client',self.open_parsec),('Quit application',self.quit)]:
            item=Gtk.MenuItem(label=title);item.connect('activate',lambda _,fn=callback:fn());self.menu.append(item)
        self.menu.show_all();self.lib.app_indicator_set_menu(self.indicator,ctypes.pythonapi.PyCapsule_GetPointer(self.menu.__gpointer__,None))

if __name__=='__main__':
    GLib.set_prgname('org.openparsec.Desktop')
    GLib.set_application_name('Open Parsec')
    Gtk.Window.set_default_icon_name('org.openparsec.Desktop')
    App().run([arg for arg in sys.argv if arg != '--background'])
