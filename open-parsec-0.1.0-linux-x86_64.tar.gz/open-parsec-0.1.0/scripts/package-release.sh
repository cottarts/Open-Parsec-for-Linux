#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
version=${1:-0.1.0}
case "$version" in ''|*[!0-9A-Za-z.-]*) echo 'Invalid release version' >&2; exit 2;; esac
[ -x bin/open-parsecd ] && [ -x bin/open-parsec-probe ] || { echo 'Build binaries first.' >&2; exit 2; }
mkdir -p dist
archive="open-parsec-$version-linux-x86_64.tar.gz"
# Include source and all license notices alongside binaries.
tar --exclude='./dist' --exclude='./target' --exclude='./.git' --exclude='./local' --exclude='./node_modules' --exclude='*/__pycache__' --exclude='./packaging/openparsec/edid' --exclude='./scripts/install-gnome-ipad.sh' --exclude='./scripts/rollback-gnome-ipad.sh' --exclude='*.env' --transform="s,^\.,open-parsec-$version," -czf "dist/$archive" .
(cd dist && sha256sum "$archive" > "$archive.sha256")
printf 'Release: dist/%s\n' "$archive"
