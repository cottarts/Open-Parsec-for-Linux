#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
profile=${1:-dev}
case "$profile" in dev) cargo build --locked -p lowlatd -p open-parsec-probe; build=debug;; release) cargo build --locked --release -p lowlatd -p open-parsec-probe; build=release;; *) echo 'Usage: build-openparsec.sh [dev|release]' >&2; exit 2;; esac
mkdir -p bin
cp "target/$build/open-parsecd" "target/$build/open-parsec-probe" bin/
strip bin/open-parsecd bin/open-parsec-probe
printf 'Open Parsec compilé (%s), binaires dans bin/\n' "$profile"
