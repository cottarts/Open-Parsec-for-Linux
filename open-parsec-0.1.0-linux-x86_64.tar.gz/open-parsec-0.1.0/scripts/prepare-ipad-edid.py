#!/usr/bin/env python3
"""Preserve the original EDID and append a CTA detailed timing for 1920x1440."""
import argparse,json,struct
from pathlib import Path

def customized(original):
    if len(original)<128 or len(original)%128 or original[:8]!=b'\x00\xff\xff\xff\xff\xff\xff\x00':raise ValueError('EDID invalide')
    if len(original)!=(1+original[126])*128 or any(sum(original[i:i+128])%256 for i in range(0,len(original),128)):raise ValueError('EDID incomplet ou checksum invalide')
    if original[126]>=254:raise ValueError('Trop d’extensions EDID')
    # CVT 1920x1440@59.97: 233.50 MHz, h 1920 2056 2264 2608,
    # v 1440 1443 1447 1493, negative hsync / positive vsync.
    d=bytearray(18);d[:2]=struct.pack('<H',23350)
    d[2:5]=bytes([1920&255,688&255,((1920>>8)<<4)|(688>>8)])
    d[5:8]=bytes([1440&255,53,((1440>>8)<<4)])
    d[8:12]=bytes([136,208,(3<<4)|4,0])
    d[12:15]=original[66:69];d[17]=0x1c
    extension=bytearray(128);extension[:4]=bytes([2,3,4,0]);extension[4:22]=d
    extension[127]=(-sum(extension[:127]))&255
    result=bytearray(original);result[126]+=1;result[127]=(-sum(result[:127]))&255
    return bytes(result+extension)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('original',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
    data=customized(a.original.read_bytes());a.destination.write_bytes(data)
    print(json.dumps({'bytes':len(data),'mode':'1920×1440 @59.97Hz','original_modes_preserved':True,'block_checksums_valid':all(sum(data[i:i+128])%256==0 for i in range(0,len(data),128))}))
