#!/bin/sh
# Remove program files while preserving account/configuration data by default.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run with sudo.' >&2; exit 2; }
systemctl disable --now open-parsecd.service || true
rm -f /etc/systemd/system/open-parsecd.service /etc/systemd/user/open-parsec-session.service
rm -f /usr/share/applications/org.openparsec.Desktop.desktop /usr/share/applications/open-parsec.desktop
rm -f /usr/share/icons/hicolor/256x256/apps/org.openparsec.Desktop.png
rm -f /usr/local/bin/open-parsec /usr/local/bin/open-parsec-login
rm -rf /opt/open-parsec
systemctl daemon-reload
update-desktop-database /usr/share/applications || true
printf 'Application removed. /etc/openparsec was preserved.\nIn your user session, stop the helper and remove its startup entry:\n'
printf 'systemctl --user disable --now open-parsec-session.service\nrm -f ~/.config/autostart/org.openparsec.Desktop.desktop\n'
