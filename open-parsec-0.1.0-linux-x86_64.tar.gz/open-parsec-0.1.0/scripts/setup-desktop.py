#!/usr/bin/env python3
"""Install the current user's background launcher; no privileged changes."""
import os
from pathlib import Path
import shutil
import subprocess

def main():
    if os.getuid()==0:raise SystemExit('Run as the desktop user, not root.')
    source=Path('/usr/share/applications/org.openparsec.Desktop.desktop')
    directory=Path(os.environ.get('XDG_CONFIG_HOME',Path.home()/'.config'))/'autostart'
    directory.mkdir(parents=True,exist_ok=True)
    lines=source.read_text().splitlines()
    lines=[line+' --background' if line.startswith('Exec=') else line for line in lines]
    lines.append('X-GNOME-Autostart-enabled=true')
    (directory/source.name).write_text('\n'.join(lines)+'\n')
    # Remove the development launcher so GNOME uses the installed release.
    local=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'applications'
    for name in ['org.openparsec.Desktop.desktop','open-parsec.desktop']:
        (local/name).unlink(missing_ok=True)
    if shutil.which('update-desktop-database') and local.exists():subprocess.run(['update-desktop-database',str(local)],check=False)
    print('Background desktop startup configured.')
if __name__=='__main__':main()
