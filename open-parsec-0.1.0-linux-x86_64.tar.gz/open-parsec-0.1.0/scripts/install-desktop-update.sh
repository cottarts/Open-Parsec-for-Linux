#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
install -m 644 apps/control/desktop_icons.py apps/control/gnome_mode.py apps/control/desktop_app.py apps/control/host_channel.py apps/control/control.py /opt/open-parsec/apps/control/
install -d /opt/open-parsec/apps/control/assets
install -m 644 apps/control/assets/* /opt/open-parsec/apps/control/assets/
install -d /usr/share/icons/hicolor/256x256/apps
install -m 644 apps/control/assets/openparsec.png /usr/share/icons/hicolor/256x256/apps/org.openparsec.Desktop.png
install -m 644 packaging/openparsec/org.openparsec.Desktop.desktop /usr/share/applications/
rm -f /usr/share/applications/open-parsec.desktop
update-desktop-database /usr/share/applications || true
install -m 755 bin/open-parsecd /opt/open-parsec/bin/open-parsecd.new
mv /opt/open-parsec/bin/open-parsecd.new /opt/open-parsec/bin/open-parsecd
systemctl restart open-parsecd.service
