#!/bin/sh
# Install the reviewed application, never drivers. Does not start hosting.
set -eu
cd "$(dirname "$0")/.."
[ "$(id -u)" = 0 ] || { echo 'Run with sudo from the graphical desktop session.' >&2; exit 2; }
owner=${SUDO_UID:-}
case "$owner" in ''|*[!0-9]*|0) echo 'SUDO_UID must identify the desktop user.' >&2; exit 2;; esac
[ -x bin/open-parsecd ] || { echo 'Build with scripts/build-openparsec.sh first.' >&2; exit 2; }
if systemctl is-active --quiet lowlatd.service; then
    echo 'Stop the Lowlat service before installing to avoid competing hosts.' >&2; exit 2
fi
install -d /opt/open-parsec/bin /opt/open-parsec/apps/control /etc/openparsec
for binary in open-parsecd open-parsec-probe; do
    install -m 755 "bin/$binary" "/opt/open-parsec/bin/$binary.new"
    mv "/opt/open-parsec/bin/$binary.new" "/opt/open-parsec/bin/$binary"
done
install -m 755 open-parsec /opt/open-parsec/
install -m 644 apps/control/gnome_mode.py apps/control/desktop_icons.py apps/control/desktop_app.py apps/control/host_channel.py apps/control/control.py apps/control/index.html apps/control/app.js apps/control/style.css /opt/open-parsec/apps/control/
install -d /opt/open-parsec/apps/control/assets
install -m 644 apps/control/assets/* /opt/open-parsec/apps/control/assets/
install -d /usr/share/icons/hicolor/256x256/apps
install -m 644 apps/control/assets/openparsec.png /usr/share/icons/hicolor/256x256/apps/org.openparsec.Desktop.png
install -m 644 packaging/openparsec/org.openparsec.Desktop.desktop /usr/share/applications/
rm -f /usr/share/applications/open-parsec.desktop
update-desktop-database /usr/share/applications || true
if command -v gtk-update-icon-cache >/dev/null; then gtk-update-icon-cache -f /usr/share/icons/hicolor || true; fi
ln -sf /opt/open-parsec/open-parsec /usr/local/bin/open-parsec
install -m 755 scripts/open-parsec-login.py /usr/local/bin/open-parsec-login
install -m 644 packaging/openparsec/open-parsecd.service /etc/systemd/system/
install -m 644 packaging/openparsec/open-parsec-session.service /etc/systemd/user/
if [ ! -e /etc/openparsec/settings.env ]; then
    python3 - "$owner" <<'PY'
import importlib.util,sys,os
from pathlib import Path
spec=importlib.util.spec_from_file_location('c','/opt/open-parsec/apps/control/control.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.atomic(Path('/etc/openparsec/settings.env'),c.environment(c.DEFAULT|{'owner_uid':int(sys.argv[1]),'output':''}))
PY
fi
if [ ! -e /etc/openparsec/session.env ]; then
    install -m 600 /dev/null /etc/openparsec/session.env
    printf 'KESSEL_SESSION=\n' > /etc/openparsec/session.env
fi
systemctl daemon-reload
printf 'Installed. Hosting has not started. Sign in: sudo open-parsec-login --install\nThen, in the user terminal: systemctl --user daemon-reload && systemctl --user enable --now open-parsec-session.service\n'
