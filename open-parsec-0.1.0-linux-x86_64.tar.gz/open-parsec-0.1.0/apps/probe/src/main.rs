//! Bounded per-stage diagnostics. Synthetic encoding never reads the desktop.
use lowlat_encode::{Poll, cuda::Cuda, nvenc};
use serde_json::{Value, json};
use std::{
    path::Path,
    time::{Duration, Instant},
};

fn synthetic(path: &Path, codec: nvenc::Codec, width: u32, height: u32) -> Result<Value, String> {
    let cuda = Cuda::load().map_err(|e| format!("CUDA: {e}"))?;
    let device = cuda.any_device().map_err(|e| format!("CUDA device: {e}"))?;
    let api = nvenc::Api::load().map_err(|e| format!("NVENC API: {e}"))?;
    let context = cuda
        .retain_primary(&device)
        .map_err(|e| format!("CUDA context: {e}"))?;
    let session = api
        .open_session(context)
        .map_err(|e| format!("NVENC session: {e}"))?;
    let caps = session
        .caps(codec)
        .map_err(|e| format!("codec capabilities: {e}"))?;
    let mut encoder = session
        .initialize(
            &cuda,
            nvenc::Config {
                codec,
                width,
                height,
                fps: 60,
                bitrate_bps: 10_000_000,
                min_qp: lowlat_encode::DEFAULT_MIN_QP,
                chroma: nvenc::Chroma::Yuv420,
                depth: nvenc::Depth::Eight,
            },
        )
        .map_err(|e| format!("NVENC initialize: {e}"))?;
    let mut source = lowlat_capture::synthetic::Synthetic::new(width, height);
    let mut bytes = Vec::new();
    let mut latencies = Vec::new();
    for index in 0..30 {
        let start = Instant::now();
        encoder
            .submit(&source.acquire(), index == 0)
            .map_err(|e| format!("submit: {e}"))?;
        loop {
            match encoder.poll().map_err(|e| format!("poll: {e}"))? {
                Poll::Ready { bitstream, .. } => {
                    if bitstream.is_empty() {
                        return Err("empty encoded frame".into());
                    }
                    bytes.extend_from_slice(bitstream);
                    latencies.push(start.elapsed().as_secs_f64() * 1000.0);
                    break;
                }
                Poll::Pending if start.elapsed() < Duration::from_secs(5) => {
                    std::thread::sleep(Duration::from_millis(1));
                }
                Poll::Pending => return Err("NVENC completion timed out after 5s".into()),
            }
        }
    }
    use std::io::Write;
    use std::os::unix::fs::OpenOptionsExt;
    let mut file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(path)
        .map_err(|e| format!("write {}: {e}", path.display()))?;
    file.write_all(&bytes).map_err(|e| e.to_string())?;
    latencies.sort_by(f64::total_cmp);
    Ok(
        json!({"stage":"synthetic_encode", "ok":true, "codec":format!("{codec:?}"),
        "width":width, "height":height, "frames":30, "bytes":bytes.len(),
        "submit_collect_p50_ms":latencies[15], "submit_collect_p95_ms":latencies[28],
        "output":path, "caps":format!("{caps:?}"),
        "note":"CPU upload + NVENC only; no capture, network, or client decode measurement"}),
    )
}

fn report() -> Value {
    let mut checks = Vec::new();
    match Cuda::load() {
        Ok(cuda) => match cuda.device_count() {
            Ok(count) => checks.push(json!({"stage":"cuda","ok":count>0,"devices":count})),
            Err(e) => checks.push(json!({"stage":"cuda","ok":false,"error":e.to_string()})),
        },
        Err(e) => checks.push(json!({"stage":"cuda","ok":false,"error":e.to_string()})),
    }
    match nvenc::Api::load() {
        Ok(api) => checks.push(json!({"stage":"nvenc_api","ok":true,
            "driver_api":api.driver_version().to_string(),"compiled_api":nvenc::Version::COMPILED.to_string()})),
        Err(e) => checks.push(json!({"stage":"nvenc_api","ok":false,"error":e.to_string()})),
    }
    let mut cards = Vec::new();
    // Enumerate nodes, do not conflate permission failure with no lit display.
    if let Ok(entries) = std::fs::read_dir("/dev/dri") {
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().into_owned();
            if !name
                .strip_prefix("card")
                .is_some_and(|n| !n.is_empty() && n.bytes().all(|c| c.is_ascii_digit()))
            {
                continue;
            }
            let path = entry.path();
            let capture = match lowlat_capture::scanout::Card::open(&path) {
                Ok(card) => match card.scan() {
                    Ok(layout) => {
                        let export = layout.primary.planes().next().map(|p| card.export(p));
                        let readable = matches!(export, Some(Ok(_)));
                        json!({"ok":readable,"geometry_available":true,"buffers_readable":readable,"width":layout.primary.width,"height":layout.primary.height,"note":"DRM export requires appropriate permissions; full capture pipeline not tested here"})
                    }
                    Err(e) => json!({"ok":false,"error":e.to_string()}),
                },
                Err(e) => json!({"ok":false,"error":e.to_string()}),
            };
            let convert = match lowlat_capture::vulkan::Device::for_display(&path) {
                Ok(device) => {
                    json!({"ok":true,"device":device.name(),"note":"device opened; DMA-BUF import not exercised"})
                }
                Err(e) => json!({"ok":false,"error":e.to_string()}),
            };
            cards.push(json!({"node":path,"capture":capture,"conversion_device":convert}));
        }
    }
    let outputs: Vec<Value> = lowlat::display::Display::outputs()
        .into_iter()
        .map(|o| {
            json!({"id":o.id,"width":o.width,"height":o.height,"refresh_hz":o.refresh_hz,
               "layout_known":o.place.is_some()})
        })
        .collect();
    json!({"app":"Open Parsec","version":"0.1.0","checks":checks,"cards":cards,"outputs":outputs,
        "capture_backend":"DRM scanout / Vulkan","end_to_end_validated":false})
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let result = if args.get(1).map(String::as_str) == Some("encode") {
        (|| {
            let codec = match args.get(2).map(String::as_str) {
                Some("h264") => nvenc::Codec::H264,
                Some("hevc") => nvenc::Codec::H265,
                _ => return Err("encode h264|hevc OUTPUT [WIDTH HEIGHT]".into()),
            };
            let output = args.get(3).ok_or("missing output path")?;
            let width = args
                .get(4)
                .map_or(Ok(1920), |s| s.parse::<u32>().map_err(|e| e.to_string()))?;
            let height = args
                .get(5)
                .map_or(Ok(1080), |s| s.parse::<u32>().map_err(|e| e.to_string()))?;
            if !(64..=7680).contains(&width)
                || !(64..=4320).contains(&height)
                || width % 2 != 0
                || height % 2 != 0
            {
                return Err("dimensions must be even, width 64..7680, height 64..4320".into());
            }
            synthetic(Path::new(output), codec, width, height)
        })()
    } else if args.len() == 1 {
        Ok(report())
    } else {
        Err("usage: open-parsec-probe [encode h264|hevc OUTPUT [WIDTH HEIGHT]]".into())
    };
    match result {
        Ok(report) => println!("{}", serde_json::to_string_pretty(&report).unwrap()),
        Err(error) => {
            println!("{}", json!({"ok":false,"error":error}));
            std::process::exit(2);
        }
    }
}
