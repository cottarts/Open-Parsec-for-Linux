"""Owner-authorized daemon IPC; never handles Parsec credentials."""
import json, socket, struct, threading
MAX_FRAME=1<<20

def receive(sock):
    def exact(n):
        data=bytearray()
        while len(data)<n:
            part=sock.recv(n-len(data))
            if not part:raise EOFError('Host disconnected')
            data.extend(part)
        return bytes(data)
    size=struct.unpack('<I',exact(4))[0]
    if size>MAX_FRAME:raise ValueError('Message too large')
    return json.loads(exact(size))

def send(sock,message):
    body=json.dumps(message).encode()
    if len(body)>MAX_FRAME:raise ValueError('Message too large')
    sock.sendall(struct.pack('<I',len(body))+body)

class Channel:
    def __init__(self,callback):
        self.callback=callback;self.sock=None;self.lock=threading.Lock();self.stop=threading.Event()
        threading.Thread(target=self.follow,daemon=True).start()
    def follow(self):
        while not self.stop.is_set():
            try:
                with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
                    sock.settimeout(2);sock.connect('/run/lowlatd/session')
                    # Root owns the daemon socket: refuse a substituted local server.
                    _,uid,_=struct.unpack('3i',sock.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
                    if uid!=0:raise PermissionError('Local server is not root-owned')
                    send(sock,{'version':1,'role':'tray','can':[]});sock.settimeout(None)
                    with self.lock:self.sock=sock
                    while not self.stop.is_set():
                        msg=receive(sock)
                        if isinstance(msg,dict) and isinstance(msg.get('state'),dict):self.callback(True,msg['state'])
            except (OSError,EOFError,ValueError):pass
            finally:
                with self.lock:self.sock=None
                self.callback(False,{})
            self.stop.wait(2)
    def request(self,message):
        with self.lock:
            if self.sock is None:raise ConnectionError('Host unavailable')
            send(self.sock,message)
