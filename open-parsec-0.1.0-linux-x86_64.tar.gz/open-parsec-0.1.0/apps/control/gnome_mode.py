#!/usr/bin/env python3
"""GNOME session display API; never invokes a root process."""
import argparse,json,os,sys
from pathlib import Path

def target_size(width,height,native_width,native_height):
    if not (64<=width<=8192 and 64<=height<=8192): raise ValueError('Resolution out of range')
    # Match the requested proportions within the physical monitor dimensions.
    # The 12.9-inch client reports 2732×2048, almost exactly 4:3.
    if abs(width/height-4/3)<0.005:
        unit=min(native_width//4,native_height//3)
        unit-=unit%2
        return 4*unit,3*unit
    factor=min(1,native_width/width,native_height/height)
    return int(width*factor)//2*2,int(height*factor)//2*2

def current_config(state):
    active={spec[0]:next(m[0] for m in modes if m[6].get('is-current',False)) for spec,modes,props in state[1] if any(m[6].get('is-current',False) for m in modes)}
    return [[x,y,scale,turn,primary,[[s[0],active[s[0]],{}] for s in specs]] for x,y,scale,turn,primary,specs,props in state[2]]

def planned(state,connector,width,height,transform):
    aliases=[connector]
    if connector.startswith('HDMI-A-'):aliases.append(connector.replace('HDMI-A-','HDMI-',1))
    monitor=next((m for m in state[1] if m[0][0] in aliases),None)
    if monitor is None: raise ValueError('Display not found: '+connector)
    connector=monitor[0][0]
    config=current_config(state)
    logical=next(c for c in config if any(o[0]==connector for o in c[5]))
    if len(logical[5])!=1:raise ValueError('Mirrored display: manual configuration required')
    old=next(m for m in monitor[1] if m[6].get('is-current',False))
    size=(old[1],old[2])
    if width and height:
        # Native bounds, not the temporarily selected low-resolution mode.
        native=max(monitor[1],key=lambda m:m[1]*m[2])
        size=target_size(width,height,native[1],native[2])
    choices=[m for m in monitor[1] if tuple(m[1:3])==size and not m[0].endswith('+vrr')]
    if not choices:raise ValueError(f'{connector} does not offer the custom mode {size[0]}×{size[1]}; display configuration/restart required')
    chosen=min(choices,key=lambda m:abs(m[3]-60))
    turn=logical[3] if transform is None else transform
    if not 0<=turn<=7:raise ValueError('Invalid rotation')
    # Reflow screens to the right by the size delta; preserve primary, scale,
    # rotation and all other display modes.
    old_width=(old[2] if logical[3]%2 else old[1])/logical[2]
    new_width=(chosen[2] if turn%2 else chosen[1])/logical[2]
    delta=round(new_width-old_width)
    for c in config:
        if c is not logical and c[0]>logical[0]:c[0]+=delta
    logical[3]=turn
    logical[5][0][1]=chosen[0]
    return config,size

def main():
    from gi.repository import Gio,GLib
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['probe','apply','verify','restore'])
    parser.add_argument('--output',default='DP-1')
    parser.add_argument('--width',type=int,default=0);parser.add_argument('--height',type=int,default=0)
    parser.add_argument('--transform',type=int)
    args=parser.parse_args()
    bus=Gio.bus_get_sync(Gio.BusType.SESSION,None)
    face='org.gnome.Mutter.DisplayConfig';obj='/org/gnome/Mutter/DisplayConfig'
    def call(method,value=None):
        return bus.call_sync(face,obj,face,method,value,None,Gio.DBusCallFlags.NONE,700,None).unpack()
    state=call('GetCurrentState')
    if args.command=='probe':print('GNOME DisplayConfig available');return
    from desktop_icons import Icons
    def icons_before():
        try:return Icons(state)
        except Exception as e:print('Desktop icons: '+str(e),file=sys.stderr);return None
    def icons_after(icons):
        if icons:
            try:icons.restore(call('GetCurrentState'))
            except Exception as e:print('Desktop icons: '+str(e),file=sys.stderr)
    snapshot=Path(os.environ['XDG_RUNTIME_DIR'])/'openparsec-display-before.json'
    if args.command=='restore':
        if not snapshot.exists():return
        config=json.loads(snapshot.read_text())
        old_names={o[0] for c in config for o in c[5]}
        now_names={o[0] for c in current_config(state) for o in c[5]}
        if old_names!=now_names:raise ValueError('Connected displays changed: automatic restore refused')
        icons=icons_before()
        call('ApplyMonitorsConfig',GLib.Variant('(uua(iiduba(ssa{sv}))a{sv})',(state[0],1,config,{})))
        icons_after(icons)
        snapshot.unlink();print('Previous layout restored');return
    config,size=planned(state,args.output,args.width,args.height,args.transform)
    call('ApplyMonitorsConfig',GLib.Variant('(uua(iiduba(ssa{sv}))a{sv})',(state[0],0,config,{})))
    if args.command=='verify':print(f'Mode verified: {size[0]}×{size[1]}');return
    if not snapshot.exists():
        fd=os.open(snapshot,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:json.dump(current_config(state),f)
    icons=icons_before()
    call('ApplyMonitorsConfig',GLib.Variant('(uua(iiduba(ssa{sv}))a{sv})',(state[0],1,config,{})))
    icons_after(icons)
    print(f'GNOME : {args.output} switched to {size[0]}×{size[1]} temporarily')

if __name__=='__main__':
    try:main()
    except Exception as e:print('Open Parsec GNOME : '+str(e),file=sys.stderr);sys.exit(2)
