#!/usr/bin/env python3
"""Open Parsec local control plane. Standard library only; no account secrets."""
import argparse
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import socket
import ssl
import subprocess
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

DEFAULT = {"name": "Open Parsec", "codec": "h264", "encoder": "nvenc", "fps": 60,
           "bitrate": 15, "output": "", "allow_guests": False, "owner_uid": os.getuid()}
ROOT = Path(__file__).resolve().parents[2]

def checked(value):
    if not isinstance(value, dict) or set(value) - set(DEFAULT):
        raise ValueError("Unknown configuration fields")
    config = DEFAULT | value
    for key, lo, hi in (("fps", 15, 144), ("bitrate", 2, 100), ("owner_uid", 0, 4294967295)):
        if type(config[key]) is not int or not lo <= config[key] <= hi:
            raise ValueError(f"{key}: integer between {lo} and {hi}")
    if config["codec"] not in ("h264", "hevc") or config["encoder"] not in ("nvenc", "auto"):
        raise ValueError("Invalid codec/encoder")
    if type(config["allow_guests"]) is not bool:
        raise ValueError("allow_guests: boolean required")
    if not isinstance(config["name"], str) or not re.fullmatch(r"[\w .-]{1,60}", config["name"]):
        raise ValueError("Name: 1–60 letters, digits, spaces, dots or hyphens")
    if not isinstance(config["output"], str) or not re.fullmatch(r"(?:card\d+:[A-Za-z0-9-]+)?", config["output"]):
        raise ValueError("Display: empty or a DRM connector such as card0:DP-1")
    return config

def load(directory):
    path = directory / "settings.json"
    return checked(json.loads(path.read_text())) if path.exists() else DEFAULT.copy()

def atomic(path, text):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, tmp = tempfile.mkstemp(prefix=".openparsec-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def environment(config):
    config = checked(config)
    args = ["--name", config["name"], "--codec", config["codec"], "--fps", str(config["fps"]),
            "--bitrate", str(config["bitrate"]), "--max-guests", "1", "--quality", "latency", "--no-host-mute"]
    if config["encoder"] == "nvenc": args += ["--encoder", "nvenc"]
    if config["output"]: args += ["--output", config["output"]]
    if config["allow_guests"]: args += ["--allow-guests"]
    # EnvironmentFile syntax, not shell source. Token is in a separate root-only file.
    return ("# Open Parsec — install to /etc/openparsec/settings.env\n"
            "KESSEL_WS_SERVER=wss://kessel-ws.parsec.app\n"
            f"OPEN_PARSEC_OWNER_UID={config['owner_uid']}\n"
            f"OPEN_PARSEC_DEFAULT_OUTPUT={config['output']}\n"
            "OPEN_PARSEC_VISIBLE_CURSOR=1\n"
            f"PULSE_SERVER=unix:/run/user/{config['owner_uid']}/pulse/native\n"
            f"LOWLATD_ARGS={json.dumps(shlex.join(args), ensure_ascii=False)}\n")

def save(directory, value):
    config = checked(value)
    atomic(directory / "settings.json", json.dumps(config, indent=2, ensure_ascii=False) + "\n")
    atomic(directory / "settings.env", environment(config))
    return config

def run(argv, timeout=8):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
        return {"ok": p.returncode == 0, "code": p.returncode, "output": (p.stdout+p.stderr)[-20000:]}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": str(error)}

def binary(name):
    for path in (ROOT / "bin" / name, ROOT / "target/release" / name, ROOT / "target/debug" / name,
                 Path("/usr/bin") / name):
        if path.is_file(): return str(path)
    raise FileNotFoundError(f"{name}: lancer scripts/build-openparsec.sh")

def network():
    checks = []
    context = ssl.create_default_context()
    for host in ("kessel-api.parsec.app", "kessel-ws.parsec.app"):
        try:
            # create_connection includes DNS and TCP. Certificate validation stays enabled.
            with socket.create_connection((host,443), timeout=4) as sock:
                with context.wrap_socket(sock,server_hostname=host) as tls:
                    checks.append({"host":host,"ok":True,"tls":tls.version(),
                        "scope":"DNS/TCP443/TLS only; authentication/WebSocket not tested"})
        except OSError as error:
            checks.append({"host":host,"ok":False,"error":str(error)})
    return checks

def doctor(check_network=False):
    try: probe = run([binary("open-parsec-probe")], 12)
    except OSError as e: probe = {"ok":False,"error":str(e)}
    return {"version":"0.1.0","session":os.getenv("XDG_SESSION_TYPE","unknown"),
        "desktop":os.getenv("XDG_CURRENT_DESKTOP","unknown"),
        "nvidia":run(["nvidia-smi","--query-gpu=name,driver_version,pci.bus_id","--format=csv,noheader"]),
        "probe":probe, "service":run(["systemctl","is-active","open-parsecd.service"]),
        "network":network() if check_network else "not tested (doctor --network)",
        "notes":["-17: client decoder format error; not proof of an NVENC failure",
                 "-6101: check the client connection to Parsec services",
                 "Test from a separate device rather than connecting to the same computer",
                 "AV1 and PipeWire capture are not implemented in this version"]}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass  # No PIN, token, or user configuration in access logs.
    def reply(self, status, data, kind="application/json"):
        body = data.encode() if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", kind+"; charset=utf-8")
        self.send_header("Content-Length",str(len(body)))
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("X-Frame-Options","DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)
    def host_valid(self):
        return self.headers.get("Host") in (f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}")
    def auth(self):
        if not self.host_valid(): self.reply(403,{"error":"Host rejected"}); return False
        if self.server.failures >= 5: self.reply(429,{"error":"PIN locked; restart the panel"}); return False
        candidate = self.headers.get("X-OpenParsec-PIN", "")
        if not secrets.compare_digest(candidate,self.server.pin):
            self.server.failures += 1
            self.reply(401,{"error":"Local PIN required"}); return False
        return True
    def do_GET(self):
        if not self.host_valid(): return self.reply(403,{"error":"Host rejected"})
        files = {"/":"index.html", "/app.js":"app.js", "/style.css":"style.css"}
        if self.path in files:
            path=Path(__file__).parent / files[self.path]
            kind={"/":"text/html","/app.js":"text/javascript","/style.css":"text/css"}[self.path]
            return self.reply(200,path.read_text(),kind)
        if not self.auth(): return
        if self.path == "/api/settings": return self.reply(200,load(self.server.directory))
        if self.path == "/api/doctor": return self.reply(200,doctor())
        return self.reply(404,{"error":"Not found"})
    def do_POST(self):
        if not self.auth(): return
        if self.headers.get("Origin") not in (f"http://127.0.0.1:{self.server.server_port}",f"http://localhost:{self.server.server_port}"):
            return self.reply(403,{"error":"Origin rejected"})
        if self.path != "/api/settings": return self.reply(404,{"error":"Not found"})
        try:
            length=int(self.headers.get("Content-Length","0"))
            if not 0 < length <= 4096: raise ValueError("Request body too large or empty")
            data=json.loads(self.rfile.read(length))
            return self.reply(200,save(self.server.directory,data))
        except (ValueError,UnicodeError) as e: return self.reply(400,{"error":str(e)})

def server(directory,port=47990,pin=None):
    srv=HTTPServer(("127.0.0.1",port),Handler)
    srv.directory=directory
    srv.pin=pin or f"{secrets.randbelow(100_000_000):08d}"
    srv.failures=0
    return srv

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config-dir",type=Path,default=Path(os.environ.get("XDG_CONFIG_HOME",Path.home()/".config"))/"openparsec")
    sub=parser.add_subparsers(dest="command",required=True)
    d=sub.add_parser("doctor"); d.add_argument("--network",action="store_true")
    w=sub.add_parser("web"); w.add_argument("--port",type=int,default=47990)
    sub.add_parser("configure")
    sub.add_parser("export")
    v=sub.add_parser("test-video"); v.add_argument("codec",choices=["h264","hevc"]); v.add_argument("output",type=Path)
    v.add_argument("--width",type=int,default=1920); v.add_argument("--height",type=int,default=1080)
    args=parser.parse_args()
    try:
        if args.command=="doctor": print(json.dumps(doctor(args.network),indent=2,ensure_ascii=False))
        elif args.command=="configure": save(args.config_dir,load(args.config_dir)); print(args.config_dir/"settings.env")
        elif args.command=="export": print(environment(load(args.config_dir)),end="")
        elif args.command=="test-video":
            p=run([binary("open-parsec-probe"),"encode",args.codec,str(args.output),str(args.width),str(args.height)],180)
            print(json.dumps(p,indent=2)); return 0 if p["ok"] else 2
        elif args.command=="web":
            srv=server(args.config_dir,args.port)
            print(f"Open Parsec : http://127.0.0.1:{srv.server_port} — PIN local : {srv.pin}",flush=True)
            try: srv.serve_forever()
            except KeyboardInterrupt: pass
            finally: srv.server_close()
        return 0
    except (OSError,ValueError) as e: parser.exit(2,f"Open Parsec: {e}\n")

if __name__=="__main__": raise SystemExit(main())
