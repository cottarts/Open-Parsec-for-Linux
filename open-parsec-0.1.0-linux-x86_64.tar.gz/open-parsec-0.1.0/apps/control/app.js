let pin = '';
const message = document.querySelector('#message');
async function api(path,body) {
  const response = await fetch(path,{method:body?'POST':'GET',headers:{'X-OpenParsec-PIN':pin,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
  const data = await response.json();
  if(!response.ok) throw new Error(data.error || 'Error');
  return data;
}
document.querySelector('#unlock').onclick=async()=>{
  pin=document.querySelector('#pin').value;
  try {
    const config=await api('/api/settings');
    const form=document.querySelector('#settings');
    for(const [key,value] of Object.entries(config)) {
      const field=form.elements.namedItem(key);
      if(field.type==='checkbox') field.checked=value; else field.value=value;
    }
    document.querySelector('#login').hidden=true; document.querySelector('#panel').hidden=false;
    document.querySelector('#pin').value=''; message.textContent='';
  } catch(e) {message.textContent=e.message;}
};
document.querySelector('#settings').onsubmit=async e=>{
  e.preventDefault(); const form=e.target; const config={};
  for(const key of ['name','codec','encoder','output']) config[key]=form.elements.namedItem(key).value;
  for(const key of ['fps','bitrate','owner_uid']) config[key]=Number(form.elements.namedItem(key).value);
  config.allow_guests=form.elements.namedItem('allow_guests').checked;
  try {await api('/api/settings',config);message.textContent='Saved. Apply settings.env and restart the service to use these settings.';}
  catch(e){message.textContent=e.message;}
};
document.querySelector('#diagnose').onclick=async()=>{
  const button=document.querySelector('#diagnose');button.disabled=true;
  try {document.querySelector('#diagnostic').textContent=JSON.stringify(await api('/api/doctor'),null,2);}
  catch(e){message.textContent=e.message;} finally {button.disabled=false;}
};
