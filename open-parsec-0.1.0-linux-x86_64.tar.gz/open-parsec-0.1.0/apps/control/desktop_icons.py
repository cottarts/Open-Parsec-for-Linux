"""Remember DING desktop file positions per monitor geometry (session user only)."""
import json, os
from pathlib import Path


def geometry(state):
    modes={s[0]:next((m for m in ms if m[6].get('is-current')),None) for s,ms,_ in state[1]}
    result=[]
    for x,y,scale,turn,_,specs,_ in state[2]:
        m=modes.get(specs[0][0])
        if m:
            w,h=m[1:3]
            if turn%2:w,h=h,w
            result.append(dict(name=specs[0][0],x=x,y=y,w=round(w/scale),h=round(h/scale)))
    return result


def remap(pos, old, new):
    monitor=next((m for m in old if m['x']<=pos[0]<m['x']+m['w'] and m['y']<=pos[1]<m['y']+m['h']),None)
    target=next((m for m in new if monitor and m['name']==monitor['name']),None)
    if not target:return pos
    # Keep the existing order, leaving room for DING's icon tile and label.
    return [target['x']+min(max(0,pos[0]-monitor['x']),max(0,target['w']-110)),
            target['y']+min(max(32,pos[1]-monitor['y']),max(32,target['h']-130))]


class Icons:
    def __init__(self,state):
        from gi.repository import Gio,GLib
        self.Gio=Gio
        self.old=geometry(state)
        self.path=Path(GLib.get_user_config_dir())/'openparsec'/'desktop-layouts.json'
        try:self.profiles=json.loads(self.path.read_text())
        except (OSError,ValueError):self.profiles={}
        self.files={}
        directory=GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP)
        if not directory:return
        folder=Gio.File.new_for_path(directory)
        enumerator=folder.enumerate_children('standard::name,metadata::nautilus-icon-position',Gio.FileQueryInfoFlags.NONE,None)
        for info in enumerator:
            raw=info.get_attribute_string('metadata::nautilus-icon-position')
            try:pos=[int(v) for v in raw.split(',')]
            except (AttributeError,ValueError):continue
            if len(pos)==2:self.files[info.get_name()]=(folder.get_child(info.get_name()),pos)
        self.profiles[self.key(self.old)]={name:pos for name,(_,pos) in self.files.items()}

    @staticmethod
    def key(rects):
        return json.dumps(sorted(rects,key=lambda m:m['name']),sort_keys=True)

    def restore(self,state):
        new=geometry(state)
        remembered=self.profiles.get(self.key(new),{})
        for name,(file,pos) in self.files.items():
            target=remembered.get(name,remap(pos,self.old,new))
            info=self.Gio.FileInfo()
            info.set_attribute_string('metadata::nautilus-icon-position',','.join(map(str,target)))
            file.set_attributes_from_info(info,self.Gio.FileQueryInfoFlags.NONE,None)
        self.path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        tmp=self.path.with_suffix('.tmp')
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w') as f:json.dump(dict(list(self.profiles.items())[-16:]),f)
        os.replace(tmp,self.path)
