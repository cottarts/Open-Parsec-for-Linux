#!/usr/bin/env python3
"""Temporary GNOME DP-1 aspect preset, with explicit restoration."""
import json,os,sys
from pathlib import Path
from gi.repository import Gio,GLib
DEST='org.gnome.Mutter.DisplayConfig'; OBJ='/org/gnome/Mutter/DisplayConfig'
bus=Gio.bus_get_sync(Gio.BusType.SESSION,None)
def call(name,args=None):
 return bus.call_sync(DEST,OBJ,DEST,name,args,None,Gio.DBusCallFlags.NONE,5000,None).unpack()
def unpack_config(state):
 modes={spec[0]:next(m[0] for m in available if m[6].get('is-current',False)) for spec,available,props in state[1] if any(m[6].get('is-current',False) for m in available)}
 return [[x,y,scale,turn,primary,[[spec[0],modes[spec[0]],{}] for spec in specs]] for x,y,scale,turn,primary,specs,props in state[2]]
def apply(serial,config):
 call('ApplyMonitorsConfig',GLib.Variant('(uua(iiduba(ssa{sv}))a{sv})',(serial,1,config,{})))
state=call('GetCurrentState')
path=Path(os.environ['XDG_RUNTIME_DIR'])/'openparsec-display-before.json'
action=sys.argv[1] if len(sys.argv)>1 else 'ipad'
if action=='restore':
 apply(state[0],json.loads(path.read_text()));path.unlink();print('Disposition précédente rétablie.');sys.exit()
if action not in ('ipad','check'): raise SystemExit('Usage: display_mode.py ipad|restore|check')
config=unpack_config(state)
monitor=next((m for m in state[1] if m[0][0]=='DP-1'),None)
if monitor is None: raise SystemExit('DP-1 absent')
candidates=[m for m in monitor[1] if m[1:3]==(1280,960) and not m[0].endswith('+vrr')]
if not candidates: raise SystemExit('Mode 1280×960 indisponible, aucun changement')
mode=min(candidates,key=lambda m:abs(m[3]-60))
target=next(c for c in config if any(o[0]=='DP-1' for o in c[5]))
if len(target[5])!=1: raise SystemExit('Écran miroir : modification automatique refusée')
old=next(m for m in monitor[1] if m[6].get('is-current',False))
delta=round((1280-old[1])/target[2])
for c in config:
 if c is not target and c[0]>target[0]: c[0]+=delta
for o in target[5]: o[1]=mode[0]
print('DP-1 : 1280×960, format 4:3, ~60 Hz ; autres écrans conservés.')
if action=='check': sys.exit()
original=unpack_config(state)
# Ask GNOME to verify before modifying or saving restoration data.
call('ApplyMonitorsConfig',GLib.Variant('(uua(iiduba(ssa{sv}))a{sv})',(state[0],0,config,{})))
if not path.exists():
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(original,f)
apply(state[0],config)
print('Appliqué temporairement. Retour : open-parsec-format restore')
