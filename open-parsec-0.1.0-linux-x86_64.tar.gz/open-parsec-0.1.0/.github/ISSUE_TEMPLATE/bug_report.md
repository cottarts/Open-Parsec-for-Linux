---
name: Bug report
about: Report a reproducible hosting or interface problem
title: ''
labels: bug
assignees: ''
---
**Environment**
- Distribution / desktop / Wayland or X11:
- GPU / driver:
- Open Parsec version:
- Client application / device:

**Steps to reproduce**

**Expected and actual behavior**

**Relevant diagnostics**
Remove account tokens, credentials, public IP addresses and personal names before posting logs.
