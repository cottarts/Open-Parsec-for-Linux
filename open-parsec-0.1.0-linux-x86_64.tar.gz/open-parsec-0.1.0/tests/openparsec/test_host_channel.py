import importlib.util,json,socket,struct,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('channel',Path(__file__).resolve().parents[2]/'apps/control/host_channel.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
class Frames(unittest.TestCase):
 def test_matches_rust_little_endian_json_framing(self):
  a,b=socket.socketpair()
  try:
   c.send(a,{'config':{'video':[{'encoderMaxBitrate':25}]}})
   self.assertEqual(c.receive(b),{'config':{'video':[{'encoderMaxBitrate':25}]}})
  finally:a.close();b.close()
 def test_rejects_oversize_frame_before_reading_body(self):
  a,b=socket.socketpair()
  try:
   a.sendall(struct.pack('<I',c.MAX_FRAME+1))
   with self.assertRaises(ValueError):c.receive(b)
  finally:a.close();b.close()
 def test_truncated_frame_closes_cleanly(self):
  a,b=socket.socketpair()
  try:
   a.sendall(b'\x05\x00');a.close()
   with self.assertRaises(EOFError):c.receive(b)
  finally:a.close();b.close()
