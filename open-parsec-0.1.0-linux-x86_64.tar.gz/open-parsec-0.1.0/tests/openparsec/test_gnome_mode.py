import importlib.util,unittest
from pathlib import Path
s=importlib.util.spec_from_file_location('gnome',Path(__file__).resolve().parents[2]/'apps/control/gnome_mode.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
s=importlib.util.spec_from_file_location('edid',Path(__file__).resolve().parents[2]/'scripts/prepare-ipad-edid.py');e=importlib.util.module_from_spec(s);s.loader.exec_module(e)
def mode(w,h,active=False):return (f'{w}x{h}@60',w,h,60.,1.,[1.],{'is-current':active})
def state(custom=True):
 a=('DP-1','vendor','monitor','serial');b=('HDMI-1','v','m','s');c=('DP-3','v','m','s')
 modes=[mode(2560,1440,True)]+([mode(1920,1440)] if custom else [])
 return (1,[(a,modes,{}),(b,[mode(2560,1440,True)],{}),(c,[mode(1680,1050,True)],{})],[(0,0,1.,1,False,[c],{}),(1050,122,1.,0,True,[a],{}),(3610,122,1.,0,False,[b],{})],{})
class GnomeTests(unittest.TestCase):
 def test_client_ipad_matches_maximum_native_four_thirds(self):self.assertEqual(g.target_size(2732,2048,2560,1440),(1920,1440))
 def test_custom_mode_reflows_right_display_and_preserves_primary(self):
  c,size=g.planned(state(),'DP-1',2732,2048,None);self.assertEqual(size,(1920,1440));self.assertEqual(c[2][0],2970);self.assertTrue(c[1][4]);self.assertEqual(c[0][3],1)
 def test_missing_custom_mode_does_not_fall_back_to_low_resolution(self):
  with self.assertRaises(ValueError):g.planned(state(False),'DP-1',2732,2048,None)
 def test_edid_keeps_original_modes_and_adds_valid_timing(self):
  b=bytearray(128);b[:8]=bytes.fromhex('00ffffffffffff00');b[127]=(-sum(b[:127]))&255
  out=e.customized(bytes(b));self.assertEqual(out[:126],b[:126]);self.assertEqual(out[126],1);self.assertEqual(out[132:134],(23350).to_bytes(2,'little'));self.assertEqual(sum(out[:128])%256,0);self.assertEqual(sum(out[128:])%256,0)
 def test_invalid_edid_is_refused(self):
  with self.assertRaises(ValueError):e.customized(b'not an EDID')
