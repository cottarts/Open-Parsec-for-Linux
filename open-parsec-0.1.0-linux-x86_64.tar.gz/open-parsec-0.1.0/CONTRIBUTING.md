# Contributing

Keep host policy in Rust and desktop presentation in `apps/control/`. Avoid hardware-specific defaults, account credentials and developer paths. Runtime settings belong outside the repository.

Run `python3 -m unittest discover -s tests/openparsec` for the desktop/control layer. Build the host with `sh scripts/build-openparsec.sh dev` and run the relevant Rust crate tests for engine changes. Test graphical behavior in a real desktop session; CI does not validate physical capture, NVENC or an iPad connection.

The standard installer must not change GPU drivers, EDIDs, automatic desktop login or firewall settings. New distribution support needs an explicit dependency list and a tested installation/uninstallation path. Preserve upstream copyright notices and the logo's separate license.
