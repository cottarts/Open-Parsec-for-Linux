#!/bin/sh
# Interactive installer for an extracted Linux x86_64 release or source checkout.
set -eu
cd "$(dirname "$0")"
case "${1:-}" in --check) check=1;; '') check=0;; *) echo 'Usage: ./install.sh [--check]' >&2; exit 2;; esac
[ "$(id -u)" != 0 ] || { echo 'Run this as your normal desktop user, not with sudo.' >&2; exit 2; }
[ "$(uname -s)" = Linux ] && [ "$(uname -m)" = x86_64 ] || { echo 'This installer supports Linux x86_64 only.' >&2; exit 2; }
. /etc/os-release
case "${ID:-}:${VERSION_ID:-}" in ubuntu:24.*|ubuntu:25.*|ubuntu:26.*) ;; *) echo 'This installer currently supports Ubuntu 24.04 or later (24–26). Other distributions require manual installation.' >&2; exit 2;; esac
for cmd in sudo apt-get systemctl python3; do command -v "$cmd" >/dev/null || { echo "Missing required command: $cmd" >&2; exit 2; }; done
[ -n "${DBUS_SESSION_BUS_ADDRESS:-}" ] || { echo 'Run from a terminal in your graphical desktop session.' >&2; exit 2; }
if [ "$check" = 1 ]; then
    echo "Platform: $PRETTY_NAME / $(uname -m)"
    if [ -x bin/open-parsecd ] && [ -x bin/open-parsec-probe ]; then echo 'Release binaries: available'; else echo 'Source checkout: Cargo is required to build the host'; fi
    echo 'Preflight passed. No changes made.'; exit 0
fi
printf '\nOpen Parsec setup\nDependencies, application launcher and automatic hosting will be installed.\nDrivers, display modes and desktop automatic login are not changed.\n\n'
sudo -v
sudo apt-get update
sudo apt-get install -y python3-gi gir1.2-gtk-3.0 libayatana-appindicator3-1 desktop-file-utils libvulkan1 libegl1 libgbm1 libpulse0 libopus0 libssl3t64 ca-certificates xterm
if [ ! -x bin/open-parsecd ] || [ ! -x bin/open-parsec-probe ]; then
    command -v cargo >/dev/null || { echo 'Install Rust with https://rustup.rs, then run ./install.sh again. Release archives include binaries and do not need Rust.' >&2; exit 2; }
    sudo apt-get install -y build-essential pkg-config
    sh scripts/build-openparsec.sh release
fi
sudo sh scripts/install-openparsec.sh
systemctl --user daemon-reload
systemctl --user enable --now open-parsec-session.service
python3 scripts/setup-desktop.py
printf '\nSign in to your Parsec account. Credentials are entered only in this terminal.\n'
sudo open-parsec-login --install
sudo systemctl enable --now open-parsecd.service
printf '\nSetup complete. Hosting starts at boot; the panel indicator starts at desktop login.\nFor unattended desktop access, enable automatic login in your desktop settings.\n'
python3 /opt/open-parsec/apps/control/desktop_app.py --background >/dev/null 2>&1 &
