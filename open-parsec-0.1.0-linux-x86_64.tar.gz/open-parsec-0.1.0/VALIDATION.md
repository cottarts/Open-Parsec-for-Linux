# Validation

Python tests cover configuration validation, web panel authentication, GNOME modes and local IPC framing. The IPC server must be root-owned; the daemon restricts actions to its configured owner.

Testing on one machine does not guarantee compatibility with all GPUs, distributions, displays or clients. Machine-specific validation reports and configuration remain local and are not published.
