# Publishing the project

The source tree contains no built binaries, user configuration, credentials or machine-specific EDID setup. Keep `local/`, `bin/`, `target/` and runtime settings untracked. Review `git diff --cached` before the first commit. Preserve all upstream license notices, including the separate logo license.

Create an empty GitHub repository, then from this source tree:

```sh
git commit -m "Initial Open Parsec Linux host"
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Use your own repository URL. No repository name, visibility or GitHub account is assumed. Enable private vulnerability reporting in repository settings.

For a release, run the **Release archive** workflow with a version number. It builds on Ubuntu 24.04 and produces a downloadable artifact with the installable archive and SHA-256 file. Create a GitHub Release and attach those files after testing on a fresh Ubuntu machine. The workflow does not publish automatically.

Locally, use:

```sh
sh scripts/build-openparsec.sh release
sh scripts/package-release.sh 0.1.0
```

Local builds depend on the build machine's ABI; check minimum glibc/runtime requirements before claiming broad compatibility. A successful build and unit tests do not replace testing installation, authentication, reboot and real streaming on another machine.
