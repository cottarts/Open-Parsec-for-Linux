# Installation

## Recommended: Linux release archive

1. Download the Linux x86_64 `.tar.gz` and its `.sha256` file from this repository's Releases page.
2. In the download directory, verify and extract them:

```sh
sha256sum -c open-parsec-0.1.0-linux-x86_64.tar.gz.sha256
tar -xzf open-parsec-0.1.0-linux-x86_64.tar.gz
cd open-parsec-0.1.0
./install.sh
```

The checksum detects corruption; it does not independently authenticate the publisher. Use the version number in the release you downloaded.

The installer runs from your normal desktop user, asks for sudo, installs runtime dependencies, installs the application and helper, and asks you to sign in to Parsec. No Rust compiler is required for a release archive. Hosting starts at boot; the application starts in the background when you log in.

## Source checkout

Install stable Rust from https://rustup.rs, clone this repository and run `./install.sh`. The installer builds missing binaries locally. Build/runtime dependencies are installed through apt. `./install.sh --check` validates basic platform prerequisites without changing the system.

## Requirements and limits

- The automatic installer targets Ubuntu 24.04–26.x, x86_64, with a graphical user session and systemd. Other distributions need manual setup.
- A compatible GPU driver, Vulkan runtime and hardware encoder are required. The installer does not replace drivers.
- GNOME resolution changes require a display-supported mode; custom EDIDs are outside the standard installation.
- Internet access and a Parsec account are required for signaling. Client compatibility and capture depend on the hardware and desktop.
- Desktop auto-login is optional and must be enabled by the user for unattended desktop access. The installer never removes login protection.
- No guarantees are made for all Ubuntu versions or GPUs; fresh-machine installation and hardware streaming need release testing.

## Troubleshooting

```sh
systemctl status open-parsecd.service
systemctl --user status open-parsec-session.service
open-parsec doctor
```

If authentication expires, run `sudo open-parsec-login --install` again. The tray remains available when the application window is closed. Never share `/etc/openparsec/session.env`.

## Uninstall

From the extracted archive or source tree:

```sh
sudo sh scripts/uninstall-openparsec.sh
systemctl --user disable --now open-parsec-session.service
rm -f ~/.config/autostart/org.openparsec.Desktop.desktop
```

The system and user configuration are preserved. Remove `/etc/openparsec` and `~/.config/openparsec` separately only if you want to delete saved settings and the local session token. Uninstalling does not revoke the Parsec session remotely.
