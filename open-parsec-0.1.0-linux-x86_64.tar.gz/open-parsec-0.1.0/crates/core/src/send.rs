//! Per-channel send ring, retransmission, and the staleness scan
//! (docs/01-protocol.md 9).
//!
//! Storage is lent by the caller, as on the receive side.
//!
//! Three behaviours live here and they interlock:
//!
//! - **Retransmission timeout** is per fragment and exponential in its retry
//!   count. It is *not* derived from the congestion level table.
//! - **Fast retransmission** on a negative acknowledgement fires **once per
//!   fragment**, latched, so a burst of them cannot become a storm.
//! - **Staleness classification** uses the level table and produces the count
//!   the congestion controller consumes. The scan and the controller are one
//!   loop split in two.

use crate::congestion::{self, WINDOW_FLOOR};
use crate::error::{Error, Result};
use crate::message::Message;
use crate::packet::{self, Ack, Data};
use crate::seq;

/// Outstanding fragments beyond which a sender stops emitting and defers.
pub const OUTSTANDING_CAP: u32 = WINDOW_FLOOR;

const RTO_FLOOR_MS: f64 = 50.0;
const RTO_CEILING_MS: f64 = 1000.0;
/// Flat grace added after the clamp, not part of it.
const RTO_GRACE_MS: f64 = 30.0;

/// Bookkeeping for one outstanding fragment.
///
/// Public because the caller owns the storage; its fields are not.
#[derive(Debug, Clone, Copy)]
pub struct SendSlot {
    len: u16,
    occupied: bool,
    last: bool,
    /// False while the fragment is written but not yet on the wire, which is
    /// what the outstanding cap produces.
    sent: bool,
    /// Latch: at most one fast retransmission per fragment.
    nack_resent: bool,
    retransmits: u16,
    first_sent_ms: f64,
    last_sent_ms: f64,
    /// The smoothed round trip at the moment this fragment was queued.
    ///
    /// **The baseline the second staleness clause is judged against**, so the
    /// question that clause asks is whether the path has got slower since
    /// this fragment went out rather than whether it is slow in absolute
    /// terms. It is stamped once and never restamped: a fragment the
    /// outstanding cap holds back carries the round trip from before the
    /// queue built, which is exactly the comparison worth making about it.
    srtt_at_enqueue_ms: f64,
}

impl Default for SendSlot {
    fn default() -> Self {
        Self {
            len: 0,
            occupied: false,
            last: false,
            sent: false,
            nack_resent: false,
            retransmits: 0,
            first_sent_ms: 0.0,
            last_sent_ms: 0.0,
            srtt_at_enqueue_ms: 0.0,
        }
    }
}

/// A channel's send ring.
#[derive(Debug)]
pub struct SendRing<'a> {
    bodies: &'a mut [u8],
    meta: &'a mut [SendSlot],
    slot_len: usize,
    channel: u8,
    /// The peer's cumulative acknowledgement: everything below is delivered.
    base: u32,
    /// Next sequence to assign.
    next: u32,
    /// Where the scan has reached this pass.
    cursor: u32,
    /// Set by a negative acknowledgement; consumed by the next scan.
    nack_below: Option<u32>,
    outstanding: u32,
    stale: u32,
    /// The peer's ring depth, which bounds how far ahead we may run: getting
    /// more than this far ahead of the peer's cumulative acknowledgement wraps
    /// onto slots it has not delivered from. **Starts at the smallest ring in
    /// circulation** and opens once the peer's generation is identified, since
    /// an unidentified peer may be the shallow one.
    peer_depth: u32,
    /// Payload bytes handed to the wire, retransmissions included.
    ///
    /// **Retransmissions count**, because this measures what the path was made
    /// to carry rather than what was usefully delivered, and the rate
    /// controller is deciding how much more the path can take.
    bytes_sent: u64,
    /// Fragments put on the wire for the first time.
    ///
    /// **Retransmissions do not count**, which is the opposite of
    /// `bytes_sent` and is deliberate: this is the denominator a reader
    /// divides the resend counters by, and a denominator that grows with its
    /// own numerator understates every loss rate it is used for.
    packets_sent: u64,
    /// Fragments the peer has acknowledged since the ring was created.
    acked: u64,
    /// Payload bytes the peer's cumulative acknowledgements have covered.
    acked_bytes: u64,
    /// Fast retransmissions taken on negative acknowledgements.
    nack_resends: u64,
    /// Retransmissions taken on the timeout.
    timeout_resends: u64,
}

impl<'a> SendRing<'a> {
    /// Build a ring over caller-owned storage.
    pub fn new(
        bodies: &'a mut [u8],
        meta: &'a mut [SendSlot],
        slot_len: usize,
        channel: u8,
    ) -> Result<Self> {
        if slot_len == 0 || meta.is_empty() || channel as usize >= packet::CHANNEL_COUNT {
            return Err(Error::BadLength);
        }
        if bodies.len() != meta.len().checked_mul(slot_len).ok_or(Error::BadLength)? {
            return Err(Error::BadLength);
        }
        // Our own storage bounds the window too; the effective depth is the
        // smaller of the two, so a peer depth wider than our ring never lets
        // the ring wrap onto itself.
        let ours = u32::try_from(meta.len()).unwrap_or(u32::MAX);
        let depth = ours.min(crate::channel::PEER_RING_FLOOR);
        Ok(Self {
            bodies,
            meta,
            slot_len,
            channel,
            base: 0,
            next: 0,
            cursor: 0,
            nack_below: None,
            outstanding: 0,
            stale: 0,
            peer_depth: depth,
            bytes_sent: 0,
            packets_sent: 0,
            acked: 0,
            acked_bytes: 0,
            nack_resends: 0,
            timeout_resends: 0,
        })
    }

    /// Open the window to what the identified peer's ring can hold, capped at
    /// our own storage.
    ///
    /// **The peer's generation is read from its first group acknowledgement**,
    /// whose entry count is the peer's channel count: a nineteen-channel peer
    /// carries the deep ring, and until one is seen the floor stands.
    pub fn raise_peer_depth(&mut self, peer_slots: u32) {
        let ours = u32::try_from(self.meta.len()).unwrap_or(u32::MAX);
        self.peer_depth = peer_slots.min(ours);
    }

    /// Fragments the peer has not acknowledged.
    pub fn in_flight(&self) -> u32 {
        self.next.wrapping_sub(self.base)
    }

    /// Fragments the ring can still accept.
    ///
    /// Bounded by the **peer's** ring depth, not ours: running further ahead
    /// than that wraps onto slots the peer has already delivered from.
    pub fn window_free(&self) -> usize {
        self.peer_depth.saturating_sub(self.in_flight()) as usize
    }

    /// Fragments the peer has acknowledged since the ring was created.
    ///
    /// **Monotonic, and it is the only evidence that anything is arriving.**
    /// The window and the stale count describe what is outstanding, and a peer
    /// that has stopped listening leaves both looking exactly like a peer on a
    /// congested path: full and old. The difference between the two is whether
    /// this figure moves.
    pub fn acked(&self) -> u64 {
        self.acked
    }

    /// Payload bytes the peer's cumulative acknowledgements have covered.
    ///
    /// **Delivered, not offered.** A retransmission moves
    /// [`SendRing::bytes_sent`] and adds nothing here, which is the
    /// difference between what the path carried and what it was asked to.
    /// Cumulative and never reset, for the same reason as `bytes_sent`.
    pub fn acked_bytes(&self) -> u64 {
        self.acked_bytes
    }

    /// Fast retransmissions taken on negative acknowledgements. Cumulative.
    pub fn nack_resends(&self) -> u64 {
        self.nack_resends
    }

    /// Retransmissions taken on the timeout. Cumulative.
    pub fn timeout_resends(&self) -> u64 {
        self.timeout_resends
    }

    /// Outstanding count from the last completed scan.
    pub fn outstanding(&self) -> u32 {
        self.outstanding
    }

    /// Stale count from the last completed scan. Feeds the controller.
    pub fn stale(&self) -> u32 {
        self.stale
    }

    /// Payload bytes sent on this channel since the ring was created.
    ///
    /// The controller's throughput measurement is a difference of two of
    /// these over a known interval, which is why the counter is cumulative and
    /// never reset: a counter the reader clears cannot be read by two readers,
    /// and a rate derived from a cleared counter loses whatever arrived
    /// between the read and the clear.
    pub fn bytes_sent(&self) -> u64 {
        self.bytes_sent
    }

    /// Distinct fragments sent on this channel since the ring was created.
    ///
    /// **First transmissions only.** A retransmission moves `bytes_sent` and
    /// one of the resend counters and adds nothing here, so `nack_resends`
    /// over this is a loss rate rather than a ratio of two counts that
    /// overlap.
    pub fn packets_sent(&self) -> u64 {
        self.packets_sent
    }

    /// Next sequence that will be assigned.
    pub fn next_sequence(&self) -> u32 {
        self.next
    }

    fn index(&self, sequence: u32) -> usize {
        (sequence as usize) % self.meta.len()
    }

    /// Write a message's fragments into the ring.
    ///
    /// Nothing is emitted here. The fragments become pending, and the scan
    /// releases them subject to the outstanding cap.
    pub fn enqueue(&mut self, message: &Message<'_>, srtt_ms: f64) -> Result<u32> {
        let capacity = self.slot_len;
        let fragments = message.fragment_count(capacity);
        if fragments > self.window_free() {
            return Err(Error::BufferTooSmall);
        }

        for index in 0..fragments {
            let step = u32::try_from(index).map_err(|_| Error::BadLength)?;
            let sequence = self.next.wrapping_add(step);
            let slot = self.index(sequence);
            let start = slot.checked_mul(self.slot_len).ok_or(Error::BadLength)?;
            let region = self
                .bodies
                .get_mut(start..start + self.slot_len)
                .ok_or(Error::BadLength)?;
            let Some(result) = message.fragment(index, capacity, region) else {
                return Err(Error::BadLength);
            };
            let fragment = result?;
            let entry = self.meta.get_mut(slot).ok_or(Error::BadLength)?;
            *entry = SendSlot {
                len: u16::try_from(fragment.len).map_err(|_| Error::BadLength)?,
                occupied: true,
                last: fragment.last,
                srtt_at_enqueue_ms: srtt_ms,
                ..SendSlot::default()
            };
        }

        let count = u32::try_from(fragments).map_err(|_| Error::BadLength)?;
        self.next = self.next.wrapping_add(count);
        Ok(count)
    }

    /// Advance the base from an acknowledgement's cumulative counts, returning
    /// the base as it stood before.
    fn apply_cumulative(&mut self, ack: &Ack) -> u32 {
        let previous = self.base;
        // **Only a channel the sender actually reported.** Peers differ in how
        // many they carry, and a value that is not there says nothing about
        // this channel.
        let cumulative = ack
            .cumulative
            .get(self.channel as usize)
            .copied()
            .filter(|_| (self.channel as usize) < ack.reported)
            .unwrap_or(self.base);
        if seq::gt(cumulative, self.base) && seq::le(cumulative, self.next) {
            // **Delivered payload bytes: what the advance covers and still
            // holds.** A slot the trigger path already cleared is not counted
            // twice -- it was counted there, at the moment it left the
            // occupied set ahead of the base -- and one the receiver
            // abandoned by escaping a stall counts anyway, which this side
            // cannot tell apart from delivered. The walk is bounded by the
            // advance and each step is a read.
            let mut covered = 0u64;
            let mut sequence = self.base;
            while seq::lt(sequence, cumulative) {
                if let Some(slot) = self.meta.get(self.index(sequence))
                    && slot.occupied
                {
                    covered = covered.saturating_add(u64::from(slot.len));
                }
                sequence = sequence.wrapping_add(1);
            }
            self.acked_bytes = self.acked_bytes.saturating_add(covered);
            self.acked = self
                .acked
                .saturating_add(u64::from(cumulative.wrapping_sub(self.base)));
            self.base = cumulative;
            if seq::lt(self.cursor, self.base) {
                self.cursor = self.base;
            }
        }
        previous
    }

    /// Apply a keepalive: the cumulative counts and nothing else.
    ///
    /// A keepalive points at nothing -- its trigger is zeros by construction,
    /// not a name -- so reading the trigger from one would clear whichever
    /// fragment sits at sequence zero and report its age as a round trip.
    pub fn on_keepalive(&mut self, ack: &Ack) {
        self.apply_cumulative(ack);
    }

    /// Apply an ordinary acknowledgement.
    ///
    /// Returns a round-trip sample when the acknowledgement names a fragment we
    /// are still holding. The sample comes from the fragment's **first** send,
    /// so a retransmitted fragment does not report an artificially short trip.
    pub fn on_ack(&mut self, ack: &Ack, now_ms: f64) -> Option<f64> {
        let previous = self.apply_cumulative(ack);

        if ack.nack && ack.trigger_channel == self.channel {
            self.nack_below = Some(ack.trigger_seq);
        }

        if ack.trigger_channel != self.channel {
            return None;
        }
        if seq::lt(ack.trigger_seq, previous) || seq::ge(ack.trigger_seq, self.next) {
            return None;
        }
        let index = self.index(ack.trigger_seq);
        // **Whether the advance above has already counted this fragment.**
        // The cumulative walk covers everything below the new base and skips
        // whatever is no longer occupied, so a fragment cleared here at or
        // past the base would never be counted by anything. Read before the
        // slot is borrowed, and the two regions are disjoint: below the base
        // the walk had it, at or above the base only this does.
        let ahead = seq::ge(ack.trigger_seq, self.base);
        let slot = self.meta.get_mut(index)?;
        if !slot.occupied || !slot.sent {
            return None;
        }
        let sample = now_ms - slot.first_sent_ms;
        let delivered = u64::from(slot.len);
        slot.occupied = false;
        if ahead {
            self.acked_bytes = self.acked_bytes.saturating_add(delivered);
        }
        if sample.is_finite() && sample >= 0.0 {
            Some(sample)
        } else {
            None
        }
    }

    /// Retransmission timeout for a fragment that has been sent `retransmits`
    /// times already.
    fn rto_ms(retransmits: u16, srtt_ms: f64) -> f64 {
        let scaled = 2.0 * f64::from(u32::from(retransmits) + 1) * srtt_ms;
        scaled.clamp(RTO_FLOOR_MS, RTO_CEILING_MS) + RTO_GRACE_MS
    }

    /// Emit the next fragment that is due, if any.
    ///
    /// Drive this until it returns `None`, which marks the end of one scan
    /// pass and publishes fresh [`SendRing::outstanding`] and
    /// [`SendRing::stale`] counts.
    pub fn poll_send(
        &mut self,
        now_ms: f64,
        srtt_ms: f64,
        level_index: usize,
        out: &mut [u8],
    ) -> Option<Result<usize>> {
        let level = congestion::level(level_index);

        while self.cursor != self.next {
            let sequence = self.cursor;
            let index = self.index(sequence);
            let Some(slot) = self.meta.get(index).copied() else {
                self.cursor = self.cursor.wrapping_add(1);
                continue;
            };
            if !slot.occupied {
                self.cursor = self.cursor.wrapping_add(1);
                continue;
            }

            // **The cap gates the whole scan and not only the fragments
            // waiting for a first send.** It is the only ceiling on
            // retransmission there is: a window full of stale fragments is
            // re-sent in its entirety on every pass without it, at several
            // times the configured rate and for as long as the session lasts.
            // Past the cap the scan classifies and sends nothing, so the
            // fragments nearest the base are the ones that get the bandwidth.
            if self.outstanding >= OUTSTANDING_CAP {
                self.classify(index, now_ms, srtt_ms, level);
                self.cursor = self.cursor.wrapping_add(1);
                continue;
            }

            let age = now_ms - slot.last_sent_ms;
            let nacked = self
                .nack_below
                .is_some_and(|below| seq::lt(sequence, below) && !slot.nack_resent);

            let due = if !slot.sent {
                // Pending. The cap above is what defers it, and draining is
                // what releases it.
                true
            } else if nacked {
                true
            } else {
                age > Self::rto_ms(slot.retransmits, srtt_ms)
            };

            if !due {
                // **A fragment in a retransmitting state counts against the cap
                // whether or not it is due this pass.** Counting only what was
                // sent lets a window of stale fragments admit a hundred more
                // sends every pass, which is the ceiling failing to hold.
                if slot.retransmits > 0 || slot.nack_resent {
                    self.outstanding = self.outstanding.saturating_add(1);
                }
                self.classify(index, now_ms, srtt_ms, level);
                self.cursor = self.cursor.wrapping_add(1);
                continue;
            }

            // Encode before mutating, so a buffer that is too small leaves the
            // ring untouched and the caller can retry with a larger one.
            let start = index.checked_mul(self.slot_len)?;
            let body = self
                .bodies
                .get(start..start.checked_add(slot.len as usize)?)?;
            let written = match packet::encode_data(
                out,
                &Data {
                    channel: self.channel,
                    seq: sequence,
                    last: slot.last,
                    body,
                },
            ) {
                Ok(written) => written,
                Err(error) => return Some(Err(error)),
            };

            let Some(entry) = self.meta.get_mut(index) else {
                return Some(Err(Error::BadLength));
            };
            let resent = entry.sent;
            if resent {
                if nacked {
                    entry.nack_resent = true;
                } else {
                    entry.retransmits = entry.retransmits.saturating_add(1);
                }
            } else {
                entry.sent = true;
                entry.first_sent_ms = now_ms;
            }
            entry.last_sent_ms = now_ms;
            // Counted by cause, so a loss rate can be read without inferring
            // one kind from the other.
            if resent {
                if nacked {
                    self.nack_resends = self.nack_resends.saturating_add(1);
                } else {
                    self.timeout_resends = self.timeout_resends.saturating_add(1);
                }
            }
            self.outstanding = self.outstanding.saturating_add(1);
            self.bytes_sent = self.bytes_sent.saturating_add(u64::from(slot.len));
            if !resent {
                self.packets_sent = self.packets_sent.saturating_add(1);
            }

            self.classify(index, now_ms, srtt_ms, level);
            self.cursor = self.cursor.wrapping_add(1);
            return Some(Ok(written));
        }

        // Pass complete. Republish the counters and rewind for the next one.
        self.nack_below = None;
        self.cursor = self.base;
        None
    }

    /// Count a fragment toward the outstanding and stale totals.
    fn classify(&mut self, index: usize, now_ms: f64, srtt_ms: f64, level: congestion::Level) {
        let Some(slot) = self.meta.get(index) else {
            return;
        };
        if !slot.occupied {
            return;
        }
        let age = now_ms - slot.last_sent_ms;
        let threshold = level.rtt_mult * srtt_ms + level.base_ms;
        let is_stale = age > threshold
            || srtt_ms > level.rtt_mult * slot.srtt_at_enqueue_ms + level.base_ms
            || slot.retransmits > 0
            || slot.nack_resent
            || !slot.sent;
        if is_stale {
            self.stale = self.stale.saturating_add(1);
        }
    }

    /// Clear the per-pass counters. The shell calls this before draining.
    pub fn begin_pass(&mut self) {
        self.outstanding = 0;
        self.stale = 0;
        self.cursor = self.base;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::packet::{AckKind, CHANNEL_COUNT};
    use std::vec::Vec;

    const SLOT: usize = 32;
    const SLOTS: usize = 16;
    const CHANNEL: u8 = 1;

    struct Storage {
        bodies: Vec<u8>,
        meta: Vec<SendSlot>,
    }

    impl Storage {
        fn new() -> Self {
            Self::wide(SLOTS)
        }

        /// A ring deep enough for the cap to bite.
        fn wide(slots: usize) -> Self {
            Self {
                bodies: std::vec![0u8; SLOT * slots],
                meta: std::vec![SendSlot::default(); slots],
            }
        }
        fn ring(&mut self) -> SendRing<'_> {
            SendRing::new(&mut self.bodies, &mut self.meta, SLOT, CHANNEL).unwrap()
        }
    }

    fn ack_with(cumulative: u32, nack: bool, trigger_seq: u32) -> Ack {
        let mut values = [0u32; CHANNEL_COUNT];
        if let Some(slot) = values.get_mut(CHANNEL as usize) {
            *slot = cumulative;
        }
        Ack {
            reported: CHANNEL_COUNT,
            kind: AckKind::Ack,
            nack,
            trigger_channel: CHANNEL,
            trigger_seq,
            cumulative: values,
        }
    }

    /// **A peer that reports fewer channels than we carry still frees our
    /// window.**
    ///
    /// A peer generation reports four cumulative values where this one reports
    /// nineteen. Ignoring what it sends leaves the base where it started, so
    /// every fragment goes stale, the scan retransmits all of it, and the
    /// session ends undeliverable while that peer is receiving perfectly well.
    /// The channel this ring is on is inside the four, which is what makes the
    /// short report usable at all.
    #[test]
    fn a_peer_reporting_fewer_channels_still_frees_the_window() {
        const REPORTED: usize = 4;
        assert!(
            (CHANNEL as usize) < REPORTED,
            "this ring's channel has to be one the peer reports"
        );

        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..8 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        assert_eq!(ring.in_flight(), 8, "nothing has been acknowledged yet");

        let mut short = ack_with(5, false, 0);
        short.reported = REPORTED;
        ring.on_ack(&short, 1.0);

        assert_eq!(
            ring.in_flight(),
            3,
            "a short report left the window where it was"
        );
    }

    /// A channel the peer did not report is left alone, rather than read as an
    /// acknowledgement of nothing.
    #[test]
    fn a_channel_the_peer_did_not_report_is_untouched() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        let before = ring.in_flight();

        let mut unreported = ack_with(3, false, 0);
        unreported.reported = CHANNEL as usize;
        ring.on_ack(&unreported, 1.0);

        assert_eq!(
            ring.in_flight(),
            before,
            "a channel the peer never reported moved the window"
        );
    }

    /// Drain one scan pass, returning the sequences emitted.
    fn drain(ring: &mut SendRing<'_>, now: f64, srtt: f64) -> Vec<u32> {
        let mut out = [0u8; 128];
        let mut seen = Vec::new();
        ring.begin_pass();
        while let Some(result) = ring.poll_send(now, srtt, 1, &mut out) {
            let written = result.unwrap();
            let parsed = packet::parse(&out[..written]).unwrap();
            match parsed {
                packet::Packet::Data(data) => seen.push(data.seq),
                packet::Packet::Ack(_) => panic!("send ring emitted an ack"),
            }
        }
        seen
    }

    #[test]
    fn enqueue_then_emit_in_order() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        let payload = [7u8; 100];
        let message = Message::new(&[], &payload).unwrap();
        assert_eq!(ring.enqueue(&message, 0.0).unwrap(), 4);
        assert_eq!(ring.in_flight(), 4);
        assert_eq!(drain(&mut ring, 0.0, 10.0), std::vec![0, 1, 2, 3]);
        // Already sent and not yet due: a second pass emits nothing.
        assert!(drain(&mut ring, 1.0, 10.0).is_empty());
    }

    #[test]
    fn the_last_fragment_carries_the_flag_and_earlier_ones_do_not() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        let payload = [1u8; 100];
        let message = Message::new(&[], &payload).unwrap();
        ring.enqueue(&message, 0.0).unwrap();

        let mut out = [0u8; 128];
        let mut flags = Vec::new();
        ring.begin_pass();
        while let Some(result) = ring.poll_send(0.0, 10.0, 1, &mut out) {
            let written = result.unwrap();
            let packet::Packet::Data(data) = packet::parse(&out[..written]).unwrap() else {
                panic!()
            };
            flags.push(data.last);
        }
        assert_eq!(flags, std::vec![false, false, false, true]);
    }

    #[test]
    fn the_outstanding_cap_defers_rather_than_dropping() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        // One fragment per message keeps the arithmetic obvious.
        for _ in 0..SLOTS {
            let message = Message::new(&[], b"x").unwrap();
            ring.enqueue(&message, 0.0).unwrap();
        }
        assert_eq!(ring.in_flight(), SLOTS as u32);

        // With the cap lowered below the queue depth nothing is lost, it is
        // simply held back. SLOTS is under the real cap, so emulate pressure by
        // checking the counter instead.
        let emitted = drain(&mut ring, 0.0, 10.0);
        assert_eq!(emitted.len(), SLOTS, "cap should not bite below 100");
        assert_eq!(ring.outstanding(), SLOTS as u32);
    }

    /// The window assumes the smallest ring in circulation until the peer
    /// says otherwise: running further ahead than a peer's ring holds wraps
    /// onto slots it has not freed.
    #[test]
    fn the_window_assumes_the_floor_until_the_peer_is_identified() {
        const FLOOR: usize = crate::channel::PEER_RING_FLOOR as usize;
        const DEEP: usize = FLOOR + 500;
        let mut storage = Storage::wide(DEEP);
        let mut ring = storage.ring();

        for _ in 0..FLOOR {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        assert_eq!(ring.window_free(), 0, "the floor did not bound the window");
        assert!(
            ring.enqueue(&Message::new(&[], b"y").unwrap(), 0.0)
                .is_err(),
            "ran past the floor against an unidentified peer"
        );

        // The peer identified itself as a generation with deeper rings; the
        // window opens to our own storage.
        ring.raise_peer_depth(u32::try_from(crate::channel::RING_SLOTS).unwrap_or(u32::MAX));
        assert_eq!(ring.window_free(), DEEP - FLOOR);
        assert!(ring.enqueue(&Message::new(&[], b"y").unwrap(), 0.0).is_ok());
    }

    /// **The only ceiling on retransmission there is.** A window of stale
    /// fragments was re-sent whole on every pass, because the cap was applied
    /// to fragments awaiting a first send and to nothing else. Measured live
    /// at 74 Mbps against a configured 10, for as long as the session lasted.
    #[test]
    fn a_stale_window_is_not_resent_whole_on_every_pass() {
        const WIDE: usize = 300;
        let mut storage = Storage::wide(WIDE);
        let mut ring = storage.ring();
        for _ in 0..WIDE {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }

        // Every fragment gets a first send, a capful per pass, and nothing is
        // acknowledged.
        let now = 0.0;
        let mut first = 0usize;
        loop {
            let emitted = drain(&mut ring, now, 1.0);
            assert!(
                emitted.len() <= OUTSTANDING_CAP as usize,
                "a pass sent {} fragments",
                emitted.len()
            );
            if emitted.is_empty() {
                break;
            }
            first += emitted.len();
        }
        assert_eq!(first, WIDE, "every fragment should reach the wire once");

        // Now past every timeout, with the peer still saying nothing.
        let now = now + 200.0;
        assert_eq!(
            drain(&mut ring, now, 1.0).len(),
            OUTSTANDING_CAP as usize,
            "the whole window went out again"
        );

        // **And the pass straight after sends nothing.** The hundred already
        // retransmitting hold the cap until they are due again, which is what
        // stops the rest of the window being admitted behind them.
        assert!(
            drain(&mut ring, now, 1.0).is_empty(),
            "a second pass sent more of the same window"
        );
    }

    /// A keepalive advances the base and touches nothing else: the fragment
    /// its zeroed trigger happens to name stays held and is retransmitted.
    #[test]
    fn a_keepalive_frees_the_window_and_touches_no_slot() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);

        let mut keepalive = ack_with(2, false, 0);
        keepalive.kind = AckKind::Keepalive;
        ring.on_keepalive(&keepalive);
        assert_eq!(ring.in_flight(), 2, "the counts were not applied");

        // Sequences 2 and 3 are still due at their timeout; nothing was
        // cleared by the trigger.
        assert_eq!(drain(&mut ring, 200.0, 10.0), std::vec![2, 3]);
    }

    #[test]
    fn a_cumulative_acknowledgement_frees_the_window() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..SLOTS {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        assert_eq!(ring.window_free(), 0);
        assert!(
            ring.enqueue(&Message::new(&[], b"y").unwrap(), 0.0)
                .is_err()
        );

        drain(&mut ring, 0.0, 10.0);
        ring.on_ack(&ack_with(8, false, u32::MAX - 1), 5.0);
        assert_eq!(ring.window_free(), 8);
        assert!(ring.enqueue(&Message::new(&[], b"y").unwrap(), 0.0).is_ok());
    }

    #[test]
    fn a_round_trip_sample_comes_from_the_first_send() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
            .unwrap();
        drain(&mut ring, 100.0, 10.0);
        let sample = ring.on_ack(&ack_with(1, false, 0), 137.5).unwrap();
        assert!((sample - 37.5).abs() < 1e-9);
    }

    #[test]
    fn retransmission_waits_for_the_timeout_then_fires() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
            .unwrap();
        drain(&mut ring, 0.0, 10.0);

        // Floor is 50 ms plus 30 ms of grace, so 79 is early and 81 is due.
        assert!(drain(&mut ring, 79.0, 10.0).is_empty());
        assert_eq!(drain(&mut ring, 81.0, 10.0), std::vec![0]);
    }

    #[test]
    fn the_timeout_grows_with_each_retry() {
        assert!((SendRing::rto_ms(0, 10.0) - 80.0).abs() < 1e-9);
        assert!((SendRing::rto_ms(1, 10.0) - 70.0_f64.max(80.0)).abs() < 1e-9);
        // Floor and ceiling both apply before the grace is added.
        assert!((SendRing::rto_ms(0, 0.1) - (RTO_FLOOR_MS + RTO_GRACE_MS)).abs() < 1e-9);
        assert!((SendRing::rto_ms(200, 100.0) - (RTO_CEILING_MS + RTO_GRACE_MS)).abs() < 1e-9);
        // **Linear in the retry count between the bounds, not exponential.**
        // Each retry adds one `2 * srtt`, so successive timeouts differ by a
        // constant; a doubling would pass a bare `grows` check and fail this.
        let step = SendRing::rto_ms(1, 40.0) - SendRing::rto_ms(0, 40.0);
        assert!((step - 80.0).abs() < 1e-9);
        for n in 1..5u16 {
            let delta = SendRing::rto_ms(n + 1, 40.0) - SendRing::rto_ms(n, 40.0);
            assert!((delta - step).abs() < 1e-9);
        }
    }

    #[test]
    fn a_negative_acknowledgement_retransmits_immediately_but_only_once() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);

        // Nack below sequence 3, well inside the timeout.
        ring.on_ack(&ack_with(0, true, 3), 1.0);
        assert_eq!(drain(&mut ring, 2.0, 10.0), std::vec![0, 1, 2]);

        // A second nack must not resend the same fragments: the latch holds.
        ring.on_ack(&ack_with(0, true, 3), 3.0);
        assert!(
            drain(&mut ring, 4.0, 10.0).is_empty(),
            "fast retransmission fired twice for the same fragment"
        );
    }

    /// A fragment sent once and still fresh is not stale; one that has been
    /// retransmitted is, and that is what reaches the congestion controller.
    #[test]
    fn retransmission_makes_a_fragment_stale() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..3 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        assert_eq!(drain(&mut ring, 0.0, 5.0).len(), 3);
        assert_eq!(ring.stale(), 0, "freshly sent fragments are not stale");

        // Past the timeout, so all three retransmit and become stale.
        assert_eq!(drain(&mut ring, 100.0, 5.0).len(), 3);
        assert_eq!(ring.stale(), 3);
    }

    /// Age alone is enough, before any retransmission: the threshold is
    /// `rtt_mult * srtt + base_ms`, which is 25.5 ms at level 1 with a 5 ms
    /// round trip.
    #[test]
    fn age_past_the_threshold_makes_a_fragment_stale() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
            .unwrap();
        drain(&mut ring, 0.0, 5.0);
        // Under the retransmission timeout, so nothing is sent, but the
        // fragment is older than the staleness threshold.
        assert!(drain(&mut ring, 40.0, 5.0).is_empty());
        assert_eq!(ring.stale(), 1);
    }

    /// **Delivered bytes, not offered ones.** The cumulative advance counts
    /// the payload it covers exactly once; a retransmission moves
    /// `bytes_sent` and adds nothing here, which is the difference between
    /// what the path carried and what it was asked to.
    #[test]
    fn acknowledged_bytes_count_what_the_cumulative_covers_once() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        // Four single-fragment one-byte messages: five bytes of body each,
        // the four-byte length prefix and the byte.
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        assert_eq!(ring.bytes_sent(), 20);
        assert_eq!(ring.acked_bytes(), 0, "nothing has been acknowledged");

        ring.on_ack(&ack_with(2, false, 1), 5.0);
        assert_eq!(ring.acked_bytes(), 10, "half the window delivered");

        // The rest is lost, retransmitted on the timeout, and then covered.
        // The retransmission is offered load, not delivered.
        assert_eq!(drain(&mut ring, 200.0, 10.0), std::vec![2, 3]);
        assert_eq!(ring.bytes_sent(), 30);
        assert_eq!(
            ring.acked_bytes(),
            10,
            "a retransmission counted as delivered"
        );
        ring.on_ack(&ack_with(4, false, 3), 250.0);
        assert_eq!(ring.acked_bytes(), 20);
    }

    /// **The second staleness clause asks whether the path got slower, not
    /// whether it is slow.**
    ///
    /// Each fragment carries the round trip as it stood when it was queued, so
    /// a path that has always been slow is not congestion and a path that has
    /// just doubled is. A fixed budget in place of that baseline answers a
    /// different question -- is the round trip past some absolute figure --
    /// which is true of a bad path from its first frame and never true of a
    /// good one going bad, and the second is the case the clause exists for.
    #[test]
    fn a_round_trip_that_grew_since_the_fragment_was_queued_is_stale() {
        // Level 1: threshold is 1.1 * srtt + 20 ms.
        let fast = 5.0;
        let now_slow = 30.0;

        let mut storage = Storage::new();
        let mut ring = storage.ring();
        ring.enqueue(&Message::new(&[], b"x").unwrap(), fast)
            .unwrap();
        drain(&mut ring, 0.0, fast);

        // 30 > 1.1 * 5 + 20, and the fragment is far too young for the first
        // clause (1.1 * 30 + 20 = 53 ms).
        drain(&mut ring, 1.0, now_slow);
        assert_eq!(
            ring.stale(),
            1,
            "a round trip six times what it was when the fragment was queued read as healthy"
        );

        // The control: queued on a path already this slow, nothing has
        // changed and nothing is stale. 30 is not past 1.1 * 30 + 20.
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        ring.enqueue(&Message::new(&[], b"x").unwrap(), now_slow)
            .unwrap();
        drain(&mut ring, 0.0, now_slow);
        drain(&mut ring, 1.0, now_slow);
        assert_eq!(
            ring.stale(),
            0,
            "a uniformly slow path was read as congestion"
        );
    }

    /// **A fragment the trigger names ahead of the cumulative is delivered,
    /// and its bytes must be counted where they leave the occupied set.**
    ///
    /// The trigger may name a fragment past the cumulative -- the peer stored
    /// it out of order while still missing something below it, and `cumack + 2`
    /// is the threshold for calling that a loss, never a bound on what may be
    /// named. Clearing the slot there takes it out of the walk that counts
    /// delivery, so without the trigger-path add its payload is lost from the
    /// figure for good: one fragment per such acknowledgement, and they happen
    /// precisely under the loss and reorder the delivered figure is read for.
    #[test]
    fn a_fragment_named_ahead_of_the_cumulative_still_counts_as_delivered() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        assert_eq!(ring.bytes_sent(), 20, "four fragments of five bytes");

        // Names 2 while the cumulative has only reached 1: delivered out of
        // order, and the slot is cleared here rather than by the walk.
        ring.on_ack(&ack_with(1, false, 2), 5.0);
        // Then the cumulative passes it. The walk finds the slot already
        // clear and steps over it.
        ring.on_ack(&ack_with(4, false, 3), 10.0);

        assert_eq!(
            ring.acked_bytes(),
            20,
            "a fragment named ahead of the cumulative was dropped from the delivered bytes"
        );
    }

    /// The other half of the same discriminator: a trigger the walk has
    /// already covered is counted once, not twice. Without this the fix for
    /// the far-ahead case reads long instead of short, which is the same
    /// defect with the sign flipped.
    #[test]
    fn a_fragment_named_below_the_cumulative_counts_once() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);

        // The advance covers 0 and 1; the trigger names 1, inside it.
        ring.on_ack(&ack_with(2, false, 1), 5.0);
        assert_eq!(
            ring.acked_bytes(),
            10,
            "the covered trigger was counted twice"
        );
    }

    /// **First transmissions only, where the byte count takes both.** The two
    /// answer different questions: the bytes are what the path was made to
    /// carry, and the fragments are the denominator a reader divides the
    /// resend counters by. Counting a resend in both would make every loss
    /// rate derived from them read low, and read lower the worse the loss got.
    #[test]
    fn sent_fragments_count_first_transmissions_only() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        assert_eq!(ring.packets_sent(), 4);
        assert_eq!(ring.bytes_sent(), 20);

        ring.on_ack(&ack_with(2, false, 1), 5.0);
        assert_eq!(drain(&mut ring, 200.0, 10.0), std::vec![2, 3]);
        assert_eq!(
            ring.packets_sent(),
            4,
            "a retransmission was counted as a fragment sent"
        );
        assert_eq!(ring.bytes_sent(), 30, "the bytes take both");
        assert_eq!(
            ring.timeout_resends(),
            2,
            "and the resends are counted once"
        );
    }

    /// Resends are counted by cause: a negative acknowledgement's fast
    /// retransmission apart from the timeout's, so a loss rate can be read
    /// without inferring either from the other.
    #[test]
    fn resends_are_counted_by_cause() {
        let mut storage = Storage::new();
        let mut ring = storage.ring();
        for _ in 0..4 {
            ring.enqueue(&Message::new(&[], b"x").unwrap(), 0.0)
                .unwrap();
        }
        drain(&mut ring, 0.0, 10.0);
        assert_eq!(ring.nack_resends(), 0);
        assert_eq!(ring.timeout_resends(), 0);

        // Nack below sequence 3, well inside the timeout: fast retransmission.
        ring.on_ack(&ack_with(0, true, 3), 1.0);
        assert_eq!(drain(&mut ring, 2.0, 10.0), std::vec![0, 1, 2]);
        assert_eq!(ring.nack_resends(), 3);
        assert_eq!(ring.timeout_resends(), 0, "a fast resend is not a timeout");

        // Past the timeout the same fragments go again, on the timer this
        // time: the nack latch held and the resend is not a second fast one.
        assert_eq!(drain(&mut ring, 200.0, 10.0), std::vec![0, 1, 2]);
        assert_eq!(ring.timeout_resends(), 3);
        assert_eq!(ring.nack_resends(), 3);
    }

    #[test]
    fn rejects_mismatched_storage_and_bad_channels() {
        let mut bodies = std::vec![0u8; 10];
        let mut meta = std::vec![SendSlot::default(); 3];
        assert!(SendRing::new(&mut bodies, &mut meta, 4, CHANNEL).is_err());
        let mut bodies = std::vec![0u8; 12];
        assert!(SendRing::new(&mut bodies, &mut meta, 4, CHANNEL_COUNT as u8).is_err());
    }
}
