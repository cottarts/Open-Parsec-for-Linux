//! Sound, from the desktop to every guest.
//!
//! **One capture, one encode, and a slot per encoding actually wanted.** A room
//! where nobody asked for the uncompressed form never produces it, and a room
//! where everybody did never runs the codec. The two are independent, so a
//! mixed room costs both and neither costs anything per guest.
//!
//! **The header is not here.** It is fifteen bytes a guest can write for
//! itself: the sample count is fixed and the codec is that guest's own choice,
//! so the pool holds payload and nothing else -- exactly as it does for
//! pictures, where the header is per guest too.
//!
//! This thread is the sound server's in the sense that matters: it wakes when a
//! frame arrives and does nothing in between, so its cadence is the sound
//! device's own and never a timer of ours ([05 §9.1](../../../docs/05-host.md)).

use std::sync::Arc;

use lowlat_audio::encode::{self, DEFAULT_BITRATE_KBPS};
use lowlat_audio::{Capture, Encoder, FRAME, FRAME_BYTES};
use lowlat_core::audio::{AUDIO_HEADER_LEN, AudioHeader, Codec};

use crate::stream::Shared;

/// Slots in the audio pool.
///
/// **Two encodings times a short queue.** A guest behind by more than this
/// loses packets, which for sound is the right answer: a late one is worth less
/// than the one behind it.
const POOL_SLOTS: usize = 8;

/// How long the uncompressed path keeps sending after sound stops.
///
/// **Two seconds, and the reason is the peer's own buffer.** A peer plays only
/// once it has queued its minimum -- measured at 75 to 150 ms on a desktop and
/// 150 to 300 on a phone -- and reaching zero makes it wait out that minimum
/// again. So a pause between words that emptied its queue would clip the start
/// of the next one. Two seconds is past any pause inside speech and still stops
/// a quiet desktop from spending 1.5 Mbit/s saying nothing.
const SILENCE_HOLD: u32 = 100;

/// Whether silence has gone on long enough to stop sending it.
///
/// **Only the uncompressed path asks.** The compressed one collapses silence to
/// about a hundredth of its rate on its own, so it keeps sending and the peer's
/// queue never drains.
#[derive(Debug, Default)]
struct Silence {
    frames: u32,
}

impl Silence {
    /// Take one frame, and say whether an uncompressed guest should be sent it.
    fn observe(&mut self, silent: bool) -> bool {
        if silent {
            self.frames = self.frames.saturating_add(1);
            self.frames <= SILENCE_HOLD
        } else {
            self.frames = 0;
            true
        }
    }
}

/// How long to wait before taking the sound device again after losing it.
///
/// **It is also how long a session stays silent when a sound server
/// restarts**, so it is short; and it is what stops a server that has gone for
/// good from being asked once per frame.
const RETRY_MS: f64 = 2000.0;

/// How long to wait before asking for a sound device that has never answered.
///
/// **A service that starts at boot meets its first guest before any
/// session exists**, and the sound server arrives with the login, minutes
/// later; a device that was never held is therefore asked for again, at a
/// pace that keeps a machine with no sound server at all from paying for the
/// question often. Each ask is a connection attempt on the loop that encodes.
const RETRY_ABSENT_MS: f64 = 10_000.0;

/// What a room's sound costs, and who it goes to.
pub(crate) struct Sound {
    capture: Option<Capture>,
    /// When the device was last asked for, so a loss is not retried per frame.
    tried: lowlat_common::clock::Time,
    /// Whether it was ever held.
    opened: bool,
    /// Whether the loss has been reported. A server that stays away must not
    /// fill the log with the same line every two seconds.
    reported: bool,
}

impl core::fmt::Debug for Sound {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("Sound")
            .field("capturing", &self.capture.is_some())
            .field("alive", &self.alive())
            .finish()
    }
}

impl Sound {
    /// Start capturing and publishing to whoever is seated.
    ///
    /// **A failure here is not a failure of the session.** A host with no sound
    /// server, or one it may not reach, streams pictures and says so once;
    /// refusing to host over something no guest has asked for would be worse.
    pub(crate) fn start(shared: &Arc<Shared>, config: &lowlat_audio::Config) -> Self {
        let capture = open(shared, config, true);
        Self {
            opened: capture.is_some(),
            reported: capture.is_none(),
            capture,
            tried: lowlat_common::clock::Time::now(),
        }
    }

    /// Whether the device is still being read.
    pub(crate) fn alive(&self) -> bool {
        self.capture.as_ref().is_some_and(Capture::alive)
    }

    /// The device being read, which is **not always the one that was asked
    /// for**: an empty request means whichever output is the default, and the
    /// sound server may move a stream while it runs.
    pub(crate) fn device(&self) -> Option<String> {
        self.capture.as_ref().map(Capture::device)
    }

    /// Take the device again after it stopped delivering.
    ///
    /// **Whoever notices is not whoever built it**, which is why this is here
    /// rather than at the call site: a capture ends on its own thread and the
    /// only thing that can act on it is the pass that finds it gone.
    pub(crate) fn regain(&mut self, shared: &Arc<Shared>, config: &lowlat_audio::Config) {
        if !due(self.opened, lowlat_common::clock::elapsed_ms(self.tried)) {
            return;
        }
        self.tried = lowlat_common::clock::Time::now();
        self.capture = open(shared, config, !self.reported);
        self.reported = self.capture.is_none();
    }
}

/// Whether a device that is not being read is asked for again on this pass.
///
/// **One that was held is asked for soon; one that never was, rarely.** A
/// capture that never opened was once taken to mean a machine with no sound
/// server, and the answer taken not to change; a guest seated at the greeter
/// showed that it does, at the login. The cost of asking is a connection
/// attempt on the loop that encodes, so the never-held case is paced apart.
fn due(opened: bool, since_ms: f64) -> bool {
    since_ms >= if opened { RETRY_MS } else { RETRY_ABSENT_MS }
}

/// Take the sound device and publish what it delivers.
///
/// **Whether a failure is said out loud is the caller's**: the first is worth
/// a line and the twentieth after it is noise.
fn open(shared: &Arc<Shared>, config: &lowlat_audio::Config, say: bool) -> Option<Capture> {
    let mut encoder = match Encoder::new(DEFAULT_BITRATE_KBPS) {
        Ok(encoder) => encoder,
        Err(error) => {
            if say {
                lowlat_common::log_warn!("audio: no encoder, sound is off, error={error}");
            }
            return None;
        }
    };
    let owned = Arc::clone(shared);
    let mut kbps = shared.sound_kbps();
    let mut silence = Silence::default();
    encoder.set_bitrate(kbps);
    match Capture::open(config.clone(), move |frame: &[u8]| {
        // **Read every frame and applied when it moves.** A rate that
        // needed a new encoder would cost a discontinuity a listener hears,
        // and one latched at start would be a setting that does nothing.
        let wanted = owned.sound_kbps();
        if wanted != kbps {
            kbps = wanted;
            encoder.set_bitrate(kbps);
            lowlat_common::log_info!("audio: encoding at {kbps} kbit/s");
        }
        publish(&owned, &mut encoder, &mut silence, frame);
    }) {
        Ok(capture) => {
            lowlat_common::log_info!("audio: sound is on, device={}", capture.device());
            Some(capture)
        }
        Err(error) => {
            if say {
                lowlat_common::log_warn!("audio: sound is off, error={error}");
            }
            None
        }
    }
}

/// One captured frame, to every seat that wants it.
fn publish(shared: &Shared, encoder: &mut Encoder, silence: &mut Silence, frame: &[u8]) {
    let (compressed, uncompressed) = shared.audio_wanted();
    let wanted = silence.observe(encode::is_silent(frame));

    if compressed {
        // **Silence is sent compressed.** The codec collapses it to about a
        // hundredth of the rate on its own, and a peer whose buffer drains pays
        // for it audibly when sound returns.
        let began = lowlat_common::clock::Time::now();
        let encoded = encoder.encode(frame);
        // Measured around the codec alone, on the same terms as the picture's
        // figure, which is what makes the two comparable in a roster.
        shared.note_audio_encode(lowlat_common::clock::elapsed_ms(began));
        match encoded {
            Ok(packet) => shared.publish_audio(false, packet),
            Err(error) => lowlat_common::log_warn!("audio: frame not encoded, error={error}"),
        }
    }
    // **Silence is not sent uncompressed, but not the moment it starts.** It
    // costs the whole rate to carry nothing, and stopping the instant a talker
    // pauses empties the peer's queue and clips the next word.
    if uncompressed && wanted {
        shared.publish_audio(true, frame);
    }
}

/// What one guest's sound costs on the wire, in the unit the rate controllers
/// are tuned in.
///
/// **Header and length prefix included**, because a packet is what the uplink
/// carries rather than a payload. The uncompressed form is the whole frame; the
/// compressed one is whatever rate the encoder was asked for, which is what it
/// averages by construction.
pub(crate) fn guest_mbps(raw: bool, compressed_kbps: u32) -> f64 {
    let overhead = AUDIO_HEADER_LEN + lowlat_core::message::LENGTH_PREFIX_LEN;
    // Packets a second, from the frame this host sends.
    let packets = f64::from(lowlat_audio::SAMPLE_RATE) / FRAME_PER_SECOND_DIVISOR;
    let framing = f64::from(u32::try_from(overhead * 8).unwrap_or(0)) * packets;
    let bits = if raw {
        f64::from(u32::try_from(FRAME_BYTES * 8).unwrap_or(0)) * packets + framing
    } else {
        f64::from(compressed_kbps) * 1000.0 + framing
    };
    bits / 1_048_576.0
}

/// Samples in one packet, as the divisor that turns a rate into a packet count.
const FRAME_PER_SECOND_DIVISOR: f64 = FRAME as f64;

/// The fifteen bytes that precede one packet of this host's sound.
///
/// **Built per guest rather than shared**, because the codec is that guest's
/// own choice and the sample count is the same for both. It is arithmetic over
/// a stack array, which is why nothing caches it.
pub(crate) fn header(raw: bool) -> [u8; AUDIO_HEADER_LEN] {
    let codec = if raw { Codec::Pcm } else { Codec::Opus };
    let samples = u32::try_from(FRAME).unwrap_or(0);
    let mut bytes = [0u8; AUDIO_HEADER_LEN];
    let _ = lowlat_core::audio::encode(&mut bytes, &AudioHeader::stereo(samples, codec));
    bytes
}

/// How the pool behind all of this is built.
///
/// One slot holds a payload of either kind, so it is sized by the larger: the
/// uncompressed frame, which is exactly what capture delivers.
pub(crate) fn pool() -> crate::frames::Pool {
    crate::frames::Pool::new(POOL_SLOTS, FRAME_BYTES)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// **A pause is not silence.** Stopping the moment sound does empties the
    /// peer's queue, and it then waits out its own minimum -- up to 300 ms on a
    /// phone -- before the next word is heard.
    #[test]
    fn a_short_pause_keeps_the_uncompressed_stream_alive() {
        let mut silence = Silence::default();
        assert!(silence.observe(false), "sound was not sent");
        // A pause inside speech: half a second.
        for frame in 0..25 {
            assert!(silence.observe(true), "stopped after {frame} silent frames");
        }
        // And it resumes with no penalty.
        assert!(silence.observe(false));
        assert_eq!(silence.frames, 0, "the count did not reset on sound");
    }

    /// **A desktop that is genuinely quiet stops costing anything.** Without
    /// this the hold above would be a decision never to skip at all.
    #[test]
    fn sustained_silence_is_eventually_dropped() {
        let mut silence = Silence::default();
        for _ in 0..SILENCE_HOLD {
            assert!(silence.observe(true));
        }
        assert!(!silence.observe(true), "silence was still being sent");
        assert!(!silence.observe(true));
        // One sound frame and the hold begins again.
        assert!(silence.observe(false));
        assert!(silence.observe(true));
    }

    /// **What a guest's sound costs, in the unit the controllers are tuned
    /// in.** The uncompressed form is the number the whole decision rests on:
    /// if it is wrong, the picture is given back the wrong share.
    #[test]
    fn the_uncompressed_form_costs_what_the_wire_carries() {
        // 3840 bytes of samples plus nineteen of framing, fifty times a
        // second, in mebibits.
        let expected = ((FRAME_BYTES + AUDIO_HEADER_LEN + 4) * 8 * 50) as f64 / 1_048_576.0;
        let measured = guest_mbps(true, 128);
        assert!(
            (measured - expected).abs() < 1e-9,
            "measured {measured}, expected {expected}"
        );
        // Which is about a megabit and a half.
        assert!((1.4..1.6).contains(&measured), "{measured} Mibit/s");
    }

    /// The compressed form is the rate that was asked for, plus its framing.
    #[test]
    fn the_compressed_form_costs_the_rate_it_was_asked_for() {
        let measured = guest_mbps(false, 128);
        let payload = 128_000.0 / 1_048_576.0;
        assert!(measured > payload, "framing was not counted");
        assert!(
            measured < payload * 1.1,
            "framing dominated the rate: {measured}"
        );
    }

    /// **The two differ by an order of magnitude**, which is the whole reason
    /// the choice is a guest's to make and the cost is the host's to account
    /// for.
    #[test]
    fn uncompressed_costs_an_order_of_magnitude_more() {
        assert!(guest_mbps(true, 128) > guest_mbps(false, 128) * 10.0);
    }

    /// **A device that was held and stopped is taken again soon; one that
    /// never opened is taken again rarely.** The second half is what lets a
    /// guest seated before the login hear the session that follows, while
    /// keeping a machine with no sound server from spending a connection
    /// attempt per frame -- that attempt blocks the loop that encodes.
    #[test]
    fn a_device_never_held_is_asked_for_again_but_rarely() {
        assert!(
            !due(false, RETRY_MS),
            "a device never held was retried as if lost"
        );
        assert!(
            due(false, RETRY_ABSENT_MS),
            "a device never held was never asked for again"
        );
        assert!(due(true, RETRY_MS), "a lost device was not taken again");
    }

    /// **And not on the pass that noticed.** Retrying every frame is a
    /// blocking connect sixty times a second at the one moment the server is
    /// least able to answer.
    #[test]
    fn a_loss_is_not_retried_on_every_pass() {
        assert!(!due(true, 0.0));
        assert!(!due(true, RETRY_MS - 1.0));
    }
}
