//! The host service: signaling on one side, the admission seam on the other.
//!
//! This is the only place the two meet, and deliberately so. The SDK does not
//! link a signaling client, so something above both has to translate one into
//! the other, and that translation is the whole of this program.
//!
//! Four inbound actions map onto the seam's four calls, and the seam's event
//! queue maps back onto two outbound actions. Nothing else here is protocol.
//!
//!   KESSEL_WS_SERVER=... KESSEL_SESSION=... lowlatd [--name NAME] [--port N]
//!   lowlatd session

use std::net::SocketAddr;

use lowlat::admission::{Admission, Config, Event, Peer, Transport};
use lowlat_kessel::message::{
    Answer, AnswerData, CancelRelay, Candex, CandexRelay, CandidateData, ConnUpdate, Credentials,
    HostDataBase, OfferRelay, Relayed, no_credentials,
};
use lowlat_kessel::{Backoff, Client, Connect, Role};

/// The generation this host implements, as the wire wants it: a string.
const APP_V: &str = "150-104a";
const SDK_V: u32 = 0x0006_0000;

/// Advertised capacity, and the only policy the seam applies. Read once and
/// handed to both the seam and the advertisement, so the listing cannot promise
/// more than admission will grant.
/// Seats a host offers unless told otherwise. The compile-time cap is the
/// stream's, and a request above it is clamped rather than refused.
const MAX_GUESTS: u32 = 4;

/// Base port every guest's bind walks from.
const DEFAULT_PORT: u16 = 9000;

/// Reflexive servers, for discovering our own mapped address.
///
/// **Names, so both address families are reachable.** One dual-stack name
/// answers with an A and an AAAA record, and both are asked; a literal can only
/// ever be one family, and a v4 literal is why this host had no v6 reflexive
/// candidate to offer.
///
/// **Two operators, because one server can only ever agree with itself.** Two
/// servers reporting different mapped ports is how a symmetric translator is
/// told from an endpoint-independent one, and two names on separate
/// infrastructure keep one outage from costing every reflexive candidate at
/// once. Two names by two families is four servers, which is exactly what the
/// engine holds.
const DEFAULT_STUN: &str = "stun.l.google.com:19302,stun.cloudflare.com:3478";

/// What the stream produces by default. The guest declares what it can decode
/// and the host is authoritative over all of it, so a declaration is a request.
const WIDTH: u32 = 1920;
const HEIGHT: u32 = 1080;
/// **Zero, which is a request to follow the captured display.** The rate a
/// display presents at is the ceiling on any stream of it, and it is not
/// knowable from here: the fallback when a device will not describe its mode
/// belongs where the display is opened, not where a flag is parsed.
const FPS: u32 = 0;

/// The bitrate ceiling, in megabits per second, before it is divided among the
/// guests on the stream. Ten is the documented default, and higher values buy
/// picture at the cost of latency.
const DEFAULT_BITRATE_MBPS: f64 = 10.0;

/// The floor a controller may not descend below.
const MIN_BITRATE_MBPS: f64 = 1.0;

/// How long the loop waits when neither side has anything, before draining the
/// seam again. Signaling carries no media and is on no hot path; a candidate
/// noticed this late is invisible against a wide-area round trip.
const IDLE_MS: u64 = 50;

/// How often the room is told what everyone's numbers are.
///
/// **A wall-clock interval rather than a frame count.** The reference this
/// shape is written for re-sends every 120 frames, which is two seconds at
/// sixty; this host sends one frame a second on a still desktop, where a frame
/// count would stretch to two minutes of stale numbers exactly when a reader is
/// most likely watching. The interval is what was meant, so the interval is
/// what is used.
const ROSTER_MS: f64 = 2000.0;

/// The address on a readiness marker is ignored by the receiver, so this is a
/// placeholder rather than anywhere we can be reached. A widely deployed peer
/// sends this exact value, which is what establishes that it is ignored.
const READY_PLACEHOLDER: &str = "1.2.3.4";
const READY_PORT: u16 = 1234;

/// Stands in for the address on an inbound readiness marker.
///
/// The marker's address is ignored and must never reach the candidate table,
/// so nothing is lost by not carrying it -- and passing a real-looking one
/// would invite somebody to start probing it.
const UNREAD_MARKER_ADDRESS: SocketAddr =
    SocketAddr::new(std::net::IpAddr::V6(std::net::Ipv6Addr::UNSPECIFIED), 0);

#[tokio::main]
async fn main() {
    if let Err(error) = run().await {
        lowlat_common::log_error!("lowlatd: {error}");
        std::process::exit(1);
    }
}

/// The `log` facade onto this program's own stream.
struct Bridge;

static BRIDGE: Bridge = Bridge;

impl log::Log for Bridge {
    fn enabled(&self, metadata: &log::Metadata) -> bool {
        lowlat_common::log::enabled(level_of(metadata.level()))
    }

    fn log(&self, record: &log::Record) {
        let level = level_of(record.level());
        if lowlat_common::log::enabled(level) {
            lowlat_common::log::emit(level, &format!("{}: {}", record.target(), record.args()));
        }
    }

    fn flush(&self) {}
}

/// The facade's levels onto this program's: a warning is a warning, and
/// everything the two crates consider informational is debug here.
fn level_of(level: log::Level) -> lowlat_common::log::Level {
    match level {
        log::Level::Error => lowlat_common::log::Level::Error,
        log::Level::Warn => lowlat_common::log::Level::Warn,
        log::Level::Info | log::Level::Debug => lowlat_common::log::Level::Debug,
        log::Level::Trace => lowlat_common::log::Level::Trace,
    }
}

mod app;
mod channel;
mod dbus;
mod gnome;
mod policy;
mod seat;
mod sni;

/// Which of the two programs an invocation is.
///
/// **One binary, two roles**, because the two sides speak a private protocol
/// that changes whenever either does and one build cannot disagree with itself
/// (docs/07-platforms.md section 5.1).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Program {
    /// The system service: the stream, the network, and the socket the session
    /// side connects to.
    Service,
    /// The session agent, which connects outward and speaks for its own
    /// session and no other.
    Session,
    /// The tray, which connects outward, shows the host and acts on it.
    Tray,
}

/// The words that select the session-side roles, in first position and
/// nowhere else.
const SESSION_ROLE: &str = "session";
const TRAY_ROLE: &str = "tray";

/// The program this invocation is, from the arguments after the name it was
/// run under.
///
/// **Read from the first argument alone.** The two roles run at different
/// privilege, so a file that can be talked into the wrong one is a security
/// defect rather than a bug: a flag is matched wherever it appears in a
/// command line, and an argument in first position is not. Everything else on
/// the line belongs to whichever role this answers.
fn program_of<'a>(args: impl IntoIterator<Item = &'a str>) -> Program {
    match args.into_iter().next() {
        Some(SESSION_ROLE) => Program::Session,
        Some(TRAY_ROLE) => Program::Tray,
        _ => Program::Service,
    }
}

fn flag(name: &str) -> Option<String> {
    let args: Vec<String> = std::env::args().collect();
    let at = args.iter().position(|arg| arg == name)?;
    args.get(at + 1).cloned()
}

/// A switch that carries no value.
fn flag_set(name: &str) -> bool {
    std::env::args().any(|arg| arg == name)
}

/// Where sound comes from, or nothing when it is switched off.
///
/// **A service outside the session has to be told which one**, because the
/// sound server's socket lives in that session's own runtime directory. Absent,
/// the environment answers -- which is right when the daemon runs inside the
/// session and wrong nowhere else, since a machine with no sound server simply
/// reports that it has none.
/// Say what a guest's microphone delivered, once a second while it does.
///
/// **A count and a rate rather than every packet.** A hundred lines a second
/// says nothing that one line a second does not, and it buries the rest of the
/// log while it does it.
fn report_microphone(heard: &lowlat::microphone::Receiver) {
    let mut samples = [0i16; 960];
    let mut packets = 0u64;
    let mut lost = 0u64;
    let mut loudest = 0i16;
    let mut said = lowlat_common::clock::Time::now();
    loop {
        match heard.recv_timeout_into(std::time::Duration::from_millis(500), &mut samples) {
            lowlat::microphone::Taken::Empty => {}
            lowlat::microphone::Taken::Took {
                guest,
                samples: count,
                dropped,
            } => {
                packets += 1;
                lost += u64::from(dropped);
                loudest = samples
                    .iter()
                    .take(count)
                    .fold(loudest, |peak, sample| peak.max(sample.saturating_abs()));
                if lowlat_common::clock::elapsed_ms(said) >= 1000.0 {
                    said = lowlat_common::clock::Time::now();
                    lowlat_common::log_info!(
                        "lowlatd: microphone from guest {guest}, packets={packets} dropped={lost} samples={count} peak={loudest}"
                    );
                    loudest = 0;
                }
            }
        }
    }
}

/// Where sound is read from.
///
/// **Always somewhere.** A host that streams a desktop streams its sound; there
/// is no reason to run one without it and no flag to. A machine with no sound
/// server says so once and the session runs regardless, which is the same
/// answer switching it off would have given.
fn audio_config() -> lowlat_audio::Config {
    lowlat_audio::Config {
        server: flag("--audio-server"),
        wanted: std::sync::Arc::new(lowlat_audio::capture::Wanted::new(
            lowlat_audio::capture::Live {
                device: flag("--audio-device"),
                // **On unless asked otherwise.** Somebody hosting their own
                // machine is in the room with it: hearing the session played
                // back at them is the surprising default, not the quiet one.
                // The tap is ahead of the mute where the device allows it, so
                // a guest hears everything either way.
                mute_local: !flag_set("--no-host-mute"),
            },
        )),
    }
}

fn read(path: &str) -> String {
    std::fs::read_to_string(path)
        .map(|s| s.trim().to_string())
        .unwrap_or_default()
}

/// Guests currently admitted, in the width the wire uses.
///
/// Bounded by the configured limit, which is a small number, so the conversion
/// cannot lose anything; it is written as a conversion rather than a cast so
/// that stays true if the limit ever moves.
fn occupancy(seam: &Admission) -> u32 {
    u32::try_from(seam.occupancy()).unwrap_or(u32::MAX)
}

fn advertisement(name: &str, capacity: u32, players: u32) -> ConnUpdate {
    ConnUpdate {
        loader_v: 0,
        service_v: 0,
        os: "linux".to_string(),
        os_v: read("/proc/sys/kernel/osrelease"),
        platform: "linux".to_string(),
        app_v: APP_V.to_string(),
        sdk_v: SDK_V,
        device_id: read("/etc/machine-id"),
        mode: "desktop".to_string(),
        name: name.to_string(),
        desc: String::new(),
        game_id: String::new(),
        secret: String::new(),
        max_players: capacity,
        players,
        is_public: false,
        guests: Vec::new(),
    }
}

/// One outbound candidate, or a readiness marker.
fn candex<'a>(
    attempt: &'a str,
    to: &'a str,
    ip: String,
    port: u16,
    lan: bool,
    from_stun: bool,
    sync: bool,
) -> Candex<'a> {
    Candex {
        attempt_id: attempt,
        data: CandidateData {
            base: HostDataBase::default(),
            ip,
            port,
            lan,
            from_stun,
            sync,
        },
        to,
    }
}

/// The session agent: connect outward, say what this is, and hold the
/// connection for as long as the session does.
///
/// **It speaks for its own session and nothing else**, so it carries no
/// privilege worth taking and is never asked to do anything it could not do on
/// its own behalf (docs/07-platforms.md section 5.1). What it has to say
/// arrives with the sources of those signals; today it is announced and
/// silent, which is a helper that reports nothing rather than a helper that is
/// absent.
fn session() -> ! {
    // **What this session can do, announced rather than assumed.** The
    // mechanisms differ per desktop and one of them offers no protocol at all,
    // so a helper says what it found and the service answers the honest way
    // for the rest. Nothing is claimed yet: the customers land with their own
    // sources, and a helper that reports nothing is not a helper that is
    // absent.
    // **What this session offers, found rather than assumed.** A desktop with
    // no screen saver of its own, or none that answers on the bus, is a
    // session that cannot hold a screen open, and saying so is what lets the
    // service give the honest answer instead of waiting for one.
    let mut screen = match dbus::Screen::connect() {
        Ok(screen) => Some(screen),
        Err(error) => {
            lowlat_common::log_warn!("session: nothing to ask about the screen, error={error}");
            None
        }
    };
    let clip = match dbus::Clip::connect() {
        Ok(clip) => Some(clip),
        Err(error) => {
            lowlat_common::log_warn!("session: no clipboard to own, error={error}");
            None
        }
    };
    // **Watched rather than asked for, which is the whole reason this is here
    // and not in the service.** A session re-describes an output when it moves
    // and announces one that appears, but only to a client that is still
    // connected; a query that opens, reads and closes learns the layout once
    // and can never learn that it changed.
    let watching = lowlat::capture::Watch::open();
    // **Whether the session takes mode requests is a property of the
    // compositor**, asked once here and announced, so a desktop without the
    // mechanism refuses a request at the service rather than here.
    let can = channel::Can {
        idle: screen.is_some(),
        clipboard: clip.is_some(),
        layout: watching.is_some(),
        mode: gnome::offered() || lowlat::capture::mode::offered(),
        ..channel::Can::default()
    };
    // **A thread of its own, because owning a clipboard is a wait.** The
    // desktop says when its selection changed and nothing says when it will,
    // so something has to be sitting on that answer while this reads the
    // service's socket.
    let (copied, to_copy) = std::sync::mpsc::channel::<String>();
    let writer: Writer = std::sync::Arc::new(std::sync::Mutex::new(None));
    let latest: Latest = std::sync::Arc::new(std::sync::Mutex::new(None));
    if let Some((watch, first)) = watching {
        let writer = std::sync::Arc::clone(&writer);
        let latest = std::sync::Arc::clone(&latest);
        if std::thread::Builder::new()
            .name("lowlat-layout".to_string())
            .spawn(move || watch_layout(watch, first, &writer, &latest))
            .is_err()
        {
            lowlat_common::log_warn!("session: no thread for the layout");
        }
    }
    if let Some(clip) = clip {
        let writer = std::sync::Arc::clone(&writer);
        if std::thread::Builder::new()
            .name("lowlat-clip".to_string())
            .spawn(move || own_clipboard(clip, &to_copy, &writer))
            .is_err()
        {
            lowlat_common::log_warn!("session: no thread for the clipboard");
        }
    }
    // **Reconnected rather than exited.** A helper outlives the service by
    // design -- a system service restarts, a session does not -- so losing the
    // socket is a wait rather than an ending. Backed off because the common
    // reason to fail is that there is nothing there yet.
    let mut wait = FIRST_RETRY_MS;
    loop {
        match channel::connect(channel::Role::Helper, can) {
            Ok(mut stream) => {
                lowlat_common::log_info!("session: connected");
                wait = FIRST_RETRY_MS;
                if let Ok(sending) = stream.try_clone()
                    && let Ok(mut writer) = writer.lock()
                {
                    *writer = Some(sending);
                }
                // **The layout is said again on every connection.** The service
                // on the other end may have just started and read nothing, and
                // the layout thread speaks only on change.
                if let Ok(kept) = latest.lock()
                    && let Some(outputs) = kept.as_ref()
                    && let Err(error) =
                        channel::write_frame(&mut stream, channel::layout(outputs).as_bytes())
                {
                    lowlat_common::log_warn!(
                        "session: the service did not take the layout, {error}"
                    );
                }
                let mut body = Vec::new();
                while channel::read_frame(&mut stream, &mut body).is_ok() {
                    if let Some(reason) = channel::is_bye(&body) {
                        lowlat_common::log_info!("session: sent away, reason={reason}");
                        std::process::exit(0);
                    }
                    if let Some(awake) = channel::is_awake(&body) {
                        hold_screen(screen.as_mut(), awake);
                        if !awake
                            && can.mode
                            && std::env::var("XDG_CURRENT_DESKTOP")
                                .unwrap_or_default()
                                .contains("GNOME")
                        {
                            gnome::restore();
                        }
                    }
                    if let Some(text) = channel::is_clipboard(&body) {
                        let _ = copied.send(text);
                    }
                    if let Some(asked) = channel::is_mode_ask(&body) {
                        let outcome = change_mode(&asked.output, asked.size, asked.rotation);
                        let answer = channel::reply(asked.id, &outcome);
                        if let Err(error) = channel::write_frame(&mut stream, &answer) {
                            lowlat_common::log_warn!(
                                "session: the service did not take the answer, {error}"
                            );
                        }
                    }
                }
                if let Ok(mut writer) = writer.lock() {
                    *writer = None;
                }
                // **Let go on the way out.** The lease is held while it is
                // asked for, and a socket that has gone is nobody asking. A
                // service that comes back says so again.
                hold_screen(screen.as_mut(), false);
                // **What is known, which is only that the connection ended.**
                // A service that went away and one that is still there both
                // read as a closed socket from here; the case where it is
                // deliberate is the one above, and it says so.
                lowlat_common::log_info!("session: the connection ended");
            }
            Err(error) => {
                lowlat_common::log_warn!("session: cannot reach the service, error={error}");
                wait = (wait * 2).min(LAST_RETRY_MS);
            }
        }
        std::thread::sleep(std::time::Duration::from_millis(wait));
    }
}

/// The tray: `lowlatd tray`, run inside a session.
///
/// **Never load-bearing.** It attaches, shows what the host is doing, asks
/// for a kick or a rate, and detaches; the stream neither waits on it nor
/// notices it go (docs/07-platforms.md section 5). The desktop draws it
/// from what it describes over the session bus, so it links no toolkit and
/// is the same binary as the service for the same reason the helper is: the
/// two sides speak a private protocol, and one build cannot disagree with
/// itself.
fn tray() -> ! {
    let bus = match sni::Bus::open() {
        Ok(bus) => std::sync::Arc::new(bus),
        Err(error) => {
            lowlat_common::log_error!("tray: no session bus to be drawn on, {error}");
            std::process::exit(1);
        }
    };
    let shown = std::sync::Arc::new(std::sync::Mutex::new(sni::Shown::default()));
    let writer: Writer = std::sync::Arc::new(std::sync::Mutex::new(None));
    // **The service on its own thread, the bus on this one.** Each is a
    // blocking read, and what one hears the other announces.
    {
        let bus = std::sync::Arc::clone(&bus);
        let shown = std::sync::Arc::clone(&shown);
        let writer = std::sync::Arc::clone(&writer);
        if std::thread::Builder::new()
            .name("lowlat-tray".to_string())
            .spawn(move || follow_service(&bus, &shown, &writer))
            .is_err()
        {
            lowlat_common::log_error!("tray: no thread for the service");
            std::process::exit(1);
        }
    }
    let why = bus.serve(&shown, |click| act(click, &writer));
    // **The bus going away is the session ending**, and a tray outside a
    // session is nothing.
    lowlat_common::log_info!("tray: the session bus ended, {why}");
    std::process::exit(0);
}

/// Stay connected to the service, and show what it says.
///
/// **Reconnected rather than exited**, as the helper is: a system service
/// restarts and a session does not, so losing the socket is a wait. What is
/// shown meanwhile is that there is nothing to show.
fn follow_service(
    bus: &sni::Bus,
    shown: &std::sync::Mutex<sni::Shown>,
    writer: &std::sync::Mutex<Option<std::os::unix::net::UnixStream>>,
) {
    let mut wait = FIRST_RETRY_MS;
    loop {
        match channel::connect(channel::Role::Tray, channel::Can::default()) {
            Ok(mut stream) => {
                lowlat_common::log_info!("tray: connected");
                wait = FIRST_RETRY_MS;
                if let Ok(sending) = stream.try_clone()
                    && let Ok(mut writer) = writer.lock()
                {
                    *writer = Some(sending);
                }
                if let Ok(mut shown) = shown.lock() {
                    shown.connected = true;
                    bus.changed(&shown);
                }
                // **The first state after a connect is a baseline, not
                // news.** What is there when the tray first looks is shown;
                // what changes afterwards is what a person is told about.
                let mut known: Option<Vec<sni::Guest>> = None;
                let mut body = Vec::new();
                while channel::read_frame(&mut stream, &mut body).is_ok() {
                    if let Some(state) = channel::is_state(&body)
                        && let Ok(mut shown) = shown.lock()
                    {
                        shown.read(&state);
                        bus.changed(&shown);
                        if let Some(before) = known.as_deref() {
                            for (who, arrived) in sni::arrivals(before, &shown.guests) {
                                let what = if arrived { "connected" } else { "disconnected" };
                                bus.notify(&format!("{who} {what}"), "");
                            }
                        }
                        known = Some(shown.guests.clone());
                    }
                    if let Some(reason) = channel::is_bye(&body) {
                        lowlat_common::log_info!("tray: sent away, reason={reason}");
                    }
                }
                if let Ok(mut writer) = writer.lock() {
                    *writer = None;
                }
                if let Ok(mut shown) = shown.lock() {
                    shown.connected = false;
                    bus.changed(&shown);
                }
                lowlat_common::log_info!("tray: the connection ended");
            }
            Err(error) => {
                lowlat_common::log_warn!("tray: cannot reach the service, error={error}");
                wait = (wait * 2).min(LAST_RETRY_MS);
            }
        }
        std::thread::sleep(std::time::Duration::from_millis(wait));
    }
}

/// What a click asks the service for.
///
/// **Not waited on.** The answer is the state the service pushes back: a
/// guest gone from the list, a rate marked; a request that changed nothing
/// is read off the service's own log, where it says who asked.
fn act(click: sni::Click, writer: &std::sync::Mutex<Option<std::os::unix::net::UnixStream>>) {
    let frame = match click {
        sni::Click::Quit => {
            lowlat_common::log_info!("tray: quit");
            std::process::exit(0);
        }
        sni::Click::Kick(guest) => channel::kick(guest),
        sni::Click::Bitrate(mbps) => channel::config(&serde_json::json!({
            "video": [{ "encoderMaxBitrate": mbps }],
        })),
    };
    let sent = writer.lock().ok().and_then(|mut writer| {
        writer
            .as_mut()
            .map(|stream| channel::write_frame(stream, &frame))
    });
    match sent {
        Some(Ok(())) => lowlat_common::log_info!("tray: asked, {click:?}"),
        Some(Err(error)) => lowlat_common::log_warn!("tray: not asked, {click:?} error={error}"),
        None => lowlat_common::log_warn!("tray: not connected, {click:?} goes nowhere"),
    }
}

/// How often the seat is asked which session owns the display.
///
/// The question costs a few file reads and, where the owning session has no
/// helper, one round trip to its compositor -- measured under a tenth of a
/// millisecond -- so the interval is set by how stale a layout may be after a
/// switch, not by cost.
const SEAT_MS: f64 = 1000.0;

/// Take a layout as the one in force, and tell everything that reads one.
///
/// **Told to every reader, not only the stream.** The output listing, the
/// corner preference and what a guest is told all read the layout for
/// themselves. A layout of nothing withdraws the placement, so the absolute
/// axis spans the picture alone rather than a desktop that is no longer there.
fn adopt_layout(
    seam: &mut Admission,
    layout: &mut Option<Vec<lowlat::capture::Output>>,
    chosen: Option<Vec<lowlat::capture::Output>>,
) -> Option<lowlat::capture::Placement> {
    lowlat::capture::tell(chosen.clone());
    *layout = chosen;
    let placed = situate(seam, layout.as_deref());
    if placed.is_none() {
        seam.set_place(None);
    }
    placed
}

/// Tell the stream where its picture sits, from the layout a session gave.
///
/// **The connector, not the identity.** A session names an output the way the
/// display device does; the identity this host selects by carries the device
/// alongside, and the two are the same name with a prefix.
fn situate(
    seam: &mut Admission,
    layout: Option<&[lowlat::capture::Output]>,
) -> Option<lowlat::capture::Placement> {
    let outputs = layout?;
    let listed = lowlat::display::Display::outputs();
    let capturing = lowlat::display::captured(&listed, seam.captured())?;
    let place = lowlat::capture::place(outputs, &capturing.connector);
    match place {
        Some(place) => lowlat_common::log_info!(
            "lowlatd: {} is {}x{} at {},{} of a {}x{} desktop, rotation={}",
            capturing.connector,
            place.width,
            place.height,
            place.x,
            place.y,
            place.desktop_width,
            place.desktop_height,
            place.rotation as u8
        ),
        None => lowlat_common::log_info!(
            "lowlatd: the session describes no {}, absolute input spans the picture alone",
            capturing.connector
        ),
    }
    seam.set_place(place);
    place
}

/// Report this session's display layout, and every change to it.
///
/// **The first one is sent unasked.** A service that opened its display before
/// a helper connected read the layout once for itself; saying it again costs a
/// frame and covers the case where it read nothing at all.
fn watch_layout(
    mut watch: lowlat::capture::Watch,
    first: Vec<lowlat::capture::Output>,
    writer: &Writer,
    latest: &Latest,
) {
    let say = |outputs: &[lowlat::capture::Output]| {
        lowlat_common::log_info!("session: the desktop has {} output(s)", outputs.len());
        // **Kept, for the next connection.** A service that restarts has
        // read nothing, and the layout is only ever sent on change; the
        // connect loop sends what is kept here the moment it connects.
        if let Ok(mut kept) = latest.lock() {
            *kept = Some(outputs.to_vec());
        }
        let body = channel::layout(outputs);
        if let Ok(mut writer) = writer.lock()
            && let Some(stream) = writer.as_mut()
            && let Err(error) = channel::write_frame(stream, body.as_bytes())
        {
            lowlat_common::log_warn!("session: the service did not take the layout, {error}");
        }
    };
    say(&first);
    // **Only what changed, and for as long as the session lasts.** A session
    // re-sends every field of an output it re-describes, so a report per
    // event would be a report per anything; and a quiet tick is not the
    // session ending, which is the distinction this loop once got wrong and
    // stopped watching after its first second.
    loop {
        match watch.changed(std::time::Duration::from_millis(LAYOUT_TICK_MS)) {
            Ok(Some(outputs)) => say(&outputs),
            Ok(None) => {}
            Err(_) => {
                lowlat_common::log_warn!("session: the layout can no longer be watched");
                return;
            }
        }
    }
}

/// Change an output as the service asked, and say what the session said.
///
/// **Answered inline, on the helper's own deadline**, which is shorter than
/// the service's: a session that is slow answers with a refusal rather than
/// with silence, and the service never has to drop this helper for a
/// compositor that took its time.
fn change_mode(output: &str, size: Option<(u32, u32)>, rotation: Option<u8>) -> Result<(), String> {
    // The wire's code is one-based and the session's transform is not.
    let transform = rotation.map(|rotation| u32::from(rotation.saturating_sub(1)));
    let outcome = if std::env::var("XDG_CURRENT_DESKTOP")
        .unwrap_or_default()
        .contains("GNOME")
    {
        gnome::set(output, size, transform)
    } else {
        lowlat::capture::mode::set(
            output,
            lowlat::capture::mode::Change { size, transform },
            std::time::Duration::from_millis(MODE_MS),
        )
    };
    match &outcome {
        Ok(()) => {
            lowlat_common::log_info!("session: {output} set to {size:?} transform={transform:?}")
        }
        Err(reason) => lowlat_common::log_warn!(
            "session: {output} not set to {size:?} transform={transform:?}, {reason}"
        ),
    }
    outcome
}

/// How long the helper waits on the compositor for a mode change.
const MODE_MS: u64 = 3_000;

/// How long the layout thread waits on its session before looking again.
///
/// **A deadline on a read, not a poll.** Nothing is asked for on this
/// connection; the wait exists so a session that ends is noticed rather than
/// waited on forever.
const LAYOUT_TICK_MS: u64 = 1_000;

/// What signaling said about a peer when it was introduced: where to answer,
/// and who it is.
#[derive(Debug, Clone)]
struct Introduced {
    /// The address an answer or a candidate goes to.
    from: String,
    /// The account's name, or empty for a peer the service did not name.
    name: String,
}

/// Where the clipboard thread writes, when there is a service to write to.
type Writer = std::sync::Arc<std::sync::Mutex<Option<std::os::unix::net::UnixStream>>>;

/// The layout last reported, for a service that connects after it was.
type Latest = std::sync::Arc<std::sync::Mutex<Option<Vec<lowlat::capture::Output>>>>;

/// Own the desktop's clipboard: report what it becomes, and set what a guest
/// sent.
///
/// **One connection doing both, on a cadence.** Waiting for the desktop to
/// speak and being told to set something are two things to be doing at once,
/// and a tick is the smaller of the two ways to have both: the other is a poll
/// over the bus and a pipe to wake it. Nothing is timed against this and no
/// data path passes through it -- a person pastes, and a fifth of a second
/// either way is not a thing anybody can see.
///
/// **One connection also keeps the echo out.** What this host sets, it
/// remembers, so the change it causes is not read back and handed to the guest
/// that caused it.
fn own_clipboard(
    mut clip: dbus::Clip,
    to_copy: &std::sync::mpsc::Receiver<String>,
    writer: &Writer,
) {
    loop {
        if let Some(text) = clip.changed(std::time::Duration::from_millis(CLIP_TICK_MS)) {
            let body = serde_json::json!({ "clipboard": text }).to_string();
            lowlat_common::log_info!("session: the desktop copied {} bytes", text.len());
            if let Ok(mut writer) = writer.lock()
                && let Some(stream) = writer.as_mut()
                && let Err(error) = crate::channel::write_frame(stream, body.as_bytes())
            {
                lowlat_common::log_warn!("session: the service did not take it, error={error}");
            }
        }
        while let Ok(text) = to_copy.try_recv() {
            match clip.write(&text) {
                Ok(()) => {
                    lowlat_common::log_info!("session: a guest copied {} bytes here", text.len());
                }
                Err(error) => {
                    lowlat_common::log_warn!("session: the clipboard refused, error={error}");
                }
            }
        }
    }
}

/// How long the clipboard thread waits on the desktop before it looks at what
/// a guest sent.
const CLIP_TICK_MS: u64 = 200;

/// Take or let go of the screen, and say which happened.
///
/// **Reported rather than answered.** The service asked for a state rather
/// than a reply, so what comes back is a line in the log of the session that
/// owns the screen, which is where somebody looking for a screen that blanked
/// anyway would look.
fn hold_screen(screen: Option<&mut dbus::Screen>, awake: bool) {
    let Some(screen) = screen else { return };
    let held = if awake {
        screen.inhibit()
    } else {
        screen.release()
    };
    match held {
        Ok(()) => lowlat_common::log_info!(
            "session: screen asked to stay awake={} holding={}",
            u8::from(awake),
            u8::from(screen.holding())
        ),
        Err(error) => lowlat_common::log_warn!("session: the screen refused, error={error}"),
    }
}

/// How long a session agent waits before asking for the service again, and
/// how long it eventually waits.
///
/// **A cadence, not a deadline**: nothing is timed against these and no data
/// path passes through them, so the coarse sleep this uses is the right one.
const FIRST_RETRY_MS: u64 = 250;
const LAST_RETRY_MS: u64 = 5_000;

async fn run() -> Result<(), Box<dyn std::error::Error>> {
    // **Decided before any flag is read**, which is the whole of the rule: a
    // role that depends on a line having been scanned is a role a line can be
    // written to change. Everything after this belongs to whichever role it
    // answered.
    let args: Vec<String> = std::env::args().skip(1).collect();
    let program = program_of(args.iter().map(String::as_str));
    // **Off by default and worth having at all only for input.** Nothing else
    // in this program says anything at this level, so the switch is in
    // practice "log every key as it is expanded", which is the one fault that
    // cannot be read off a stream of injected events afterwards.
    if flag_set("--verbose") {
        lowlat_common::log::set_level(lowlat_common::log::Level::Debug);
    }
    // The browser pipe's two state machines say what they see through the
    // `log` facade; carried onto this program's own stream so a handshake
    // that fails is one log and not two. **Their idea of informational is a
    // hex dump of every packet**, so anything below a warning from them is
    // this program's debug, and is not even formatted unless asked for.
    let facade = if flag_set("--verbose") {
        log::LevelFilter::Debug
    } else {
        log::LevelFilter::Warn
    };
    let _ = log::set_logger(&BRIDGE).map(|()| log::set_max_level(facade));
    match program {
        Program::Session => session(),
        Program::Tray => tray(),
        Program::Service => {}
    }
    // **Before anything else is set up.** It answers the one question that has
    // to be answered before --output can be used at all, and a machine being
    // asked what it has is not a machine about to host.
    if flag_set("--outputs") {
        for output in lowlat::display::Display::outputs() {
            match output.place {
                Some(place) => println!(
                    "{}  {}x{} at {},{} of a {}x{} desktop",
                    output.id,
                    output.width,
                    output.height,
                    place.x,
                    place.y,
                    place.desktop_width,
                    place.desktop_height
                ),
                None => println!("{}  {}x{}", output.id, output.width, output.height),
            }
        }
        return Ok(());
    }

    // **Whether this process can reach the display, answered before anything
    // is advertised.** A display that is lit but out of reach is the
    // privilege, and a host that finds that out from its first guest has
    // advertised a stream it could never produce. Nothing lit is not refused:
    // the session may not have started yet, and the stream waits for one.
    if !flag_set("--synth") {
        match lowlat::display::Display::capturable() {
            lowlat::display::Capturable::Yes => {}
            lowlat::display::Capturable::NothingLit => {
                lowlat_common::log_warn!(
                    "lowlatd: nothing is scanning out yet, waiting for a display"
                );
            }
            lowlat::display::Capturable::NotReachable => {
                return Err(
                    "a display is lit and its framebuffer cannot be reached; this needs the \
                            capture privilege, or --synth to generate pictures instead"
                        .into(),
                );
            }
        }
    }

    // **Not configured is not a failure.** A host that has been installed and
    // not yet logged in is an expected state, and a unit that failed on it
    // would be restarted into it every few seconds until somebody did; so
    // this says what is missing and where it goes, and exits cleanly.
    let configured = std::env::var("KESSEL_WS_SERVER").unwrap_or_default();
    let session = std::env::var("KESSEL_SESSION").unwrap_or_default();
    let configured = configured.trim();
    if configured.is_empty() || session.trim().is_empty() {
        lowlat_common::log_warn!(
            "lowlatd: not configured, KESSEL_WS_SERVER and KESSEL_SESSION are read from \
             /etc/lowlat/lowlatd.env and lowlat-login --install obtains the session"
        );
        return Ok(());
    }
    let server = if configured.contains("://") {
        configured.to_string()
    } else {
        format!("wss://{configured}")
    };
    if !policy::secure_signaling(&server) {
        return Err("Open Parsec requires wss:// signaling; refusing to send a session token over plaintext".into());
    }
    let hostname = read("/proc/sys/kernel/hostname");
    let name = flag("--name").unwrap_or(if hostname.is_empty() {
        "lowlat".to_string()
    } else {
        hostname
    });
    // Declines every offer, which is the only way to exercise the refusal path
    // against a real peer: approval is otherwise unconditional here.
    let admission_policy = policy::AdmissionPolicy {
        reject_all: flag_set("--reject"),
        allow_guests: flag_set("--allow-guests"),
    };
    let base_port: u16 = flag("--port")
        .and_then(|v| v.parse().ok())
        .unwrap_or(DEFAULT_PORT);
    // **A list, comma separated.** One reflexive server answers what address it
    // sees; two answering differently is how an endpoint-independent
    // translator is told from a symmetric one, and both answers travel to the
    // peer as candidates. The engine holds four.
    // Names or literals, each resolved to one address per family. **A name that
    // does not resolve is reported and skipped rather than fatal**: an attempt
    // with no reflexive server still punches on what it gathered locally, and a
    // service that refuses to start because a resolver was briefly unavailable
    // is worse than one that offers fewer candidates.
    let configured_stun = std::env::var("LOWLAT_STUN").unwrap_or_else(|_| DEFAULT_STUN.to_string());
    let mut stun: Vec<SocketAddr> = Vec::new();
    for name in configured_stun
        .split(',')
        .map(str::trim)
        .filter(|t| !t.is_empty())
    {
        let found = lowlat::admission::resolve_server(name);
        if found.is_empty() {
            lowlat_common::log_warn!("lowlatd: reflexive server did not resolve, skipped: {name}");
            continue;
        }
        for addr in found {
            if stun.len() < lowlat::abi::LOWLAT_SERVERS_MAX {
                stun.push(addr);
            } else {
                lowlat_common::log_warn!("lowlatd: reflexive servers full, dropped {addr}");
            }
        }
    }
    lowlat_common::log_info!(
        "lowlatd: reflexive servers: {}",
        stun.iter()
            .map(ToString::to_string)
            .collect::<Vec<_>>()
            .join(" ")
    );

    // Gathered here, beside the reflexive servers, because the two are filtered
    // together and the servers are handed to the seam a few lines below.

    let bitrate_mbps: f64 = flag("--bitrate")
        .and_then(|v| v.parse().ok())
        .unwrap_or(DEFAULT_BITRATE_MBPS);
    // The size the generated picture runs at, under --synth; a display
    // decides its own. A larger one is how a frame is made big enough to
    // need more than one fragment, which is the whole of the reassembly path
    // a peer runs and the part a small synthetic picture never reaches.
    let width: u32 = flag("--width")
        .and_then(|v| v.parse().ok())
        .unwrap_or(WIDTH);
    let height: u32 = flag("--height")
        .and_then(|v| v.parse().ok())
        .unwrap_or(HEIGHT);
    // **Absent means the captured display's own rate**, which is the answer
    // this program cannot give until it has looked at the display, so it is
    // passed on as zero and settled there. A number is a ceiling rather than a
    // promise and is clamped to the display: the loop will not run ahead of
    // the presents, so anything above the refresh is a rate the stream cannot
    // reach while still being what the encoder's budget is divided by.
    let fps: u32 = flag("--fps").and_then(|v| v.parse().ok()).unwrap_or(FPS);
    // Rows of unpredictable detail in the synthetic picture. Zero is the flat
    // picture; a band makes frames large enough to need more than one
    // fragment, which is the only way a peer's reassembly is exercised.
    let detail_rows: u32 = flag("--detail").and_then(|v| v.parse().ok()).unwrap_or(0);
    // Advertised capacity, and the number of seats the stream offers. Read
    // from here rather than hardcoded, so the two cannot disagree.
    let max_guests: u32 = flag("--max-guests")
        .and_then(|v| v.parse().ok())
        .unwrap_or(MAX_GUESTS)
        .clamp(
            1,
            u32::try_from(lowlat::stream::MAX_SEATS).unwrap_or(MAX_GUESTS),
        );
    // **One-based, because zero means unspecified rather than upright.** The
    // coded picture stays landscape whatever this says; a quarter turn changes
    // what the peer presents and what it maps pointer coordinates against.
    // **One encode serves every guest**, so the codec is chosen here and not
    // negotiated per guest. A peer that cannot decode it has to be refused
    // rather than accommodated, which is the phase 6 refusal path.
    let codec = match flag("--codec").as_deref() {
        Some("hevc" | "h265") => lowlat::stream::Codec::H265,
        _ => lowlat::stream::Codec::H264,
    };
    // **Absent means follow the display**, which is the right answer on a
    // machine with more than one card: the encoder has to be on the device the
    // display is on, and which device that is can change while this runs.
    let backend = match flag("--encoder").as_deref() {
        Some("vendor" | "nvenc") => Some(lowlat::stream::Backend::Vendor),
        Some("open" | "vaapi") => Some(lowlat::stream::Backend::Open),
        _ => None,
    };
    // **A name pins the interface; absent follows the device** -- the compute
    // interface where it exists, the fallback where it does not, which is the
    // settled tier ladder (05 section 4). A name that is neither is refused
    // loudly and the stream follows the device instead, because silently
    // measuring the interface nobody asked about is worse than not pinning.
    let convert =
        flag("--convert")
            .as_deref()
            .map_or_else(lowlat::capture::Backend::asked, |named| {
                let parsed = lowlat::capture::Backend::parse(named);
                if parsed.is_none() {
                    eprintln!("--convert {named} names no interface; following the device");
                }
                parsed
            });
    // **Off unless asked for.** One guest driving at a time is a room's
    // decision, not a host's, and imposing it breaks two people sharing a
    // desktop.
    let exclusive_pointer = flag_set("--exclusive-pointer");
    // A live-run aid, off unless asked for: nothing on this machine vibrates,
    // so without it the path back to a peer's controller cannot be exercised
    // without running a game that raises an effect.
    let rumble_probe = flag_set("--rumble-probe");
    // **Not zero.** Level 0 declares congestion on any stale fragment once the
    // window passes its floor; it is compatibility-only and the guest loop was
    // pinned to it.
    // 1 is the default the core names; see its LEVELS table.
    // **Named rather than numbered.** The values are a person's words for a
    // trade, and a number here would be a code somebody has to look up.
    let quality = match flag("--quality").as_deref() {
        None | Some("latency" | "lowest-latency") => lowlat::stream::Quality::LowestLatency,
        Some("balanced") => lowlat::stream::Quality::Balanced,
        Some("quality" | "highest") => lowlat::stream::Quality::Highest,
        Some(other) => {
            eprintln!("lowlatd: --quality {other} is not one of latency, balanced, quality");
            std::process::exit(2);
        }
    };
    let cg_level = flag("--cg-level")
        .and_then(|text| text.parse().ok())
        // 3 is adaptive, which runs the sensitive tuning until a host-local
        // signal lands behind it. See `lowlat_cg_level`.
        .filter(|level| *level <= 3)
        .unwrap_or(1);
    // **Drained by a thread of its own, which is what an application does with
    // it.** The daemon has nothing to play a guest's microphone into, so it
    // reports what arrived: that is the whole of what a live run needs to see.
    let (hear, heard) = lowlat::microphone::queue();
    if flag_set("--accept-microphone") {
        std::thread::Builder::new()
            .name("lowlat-mic".to_owned())
            .spawn(move || report_microphone(&heard))
            .ok();
    }
    // **Opened before the first guest and independent of one.** A session-side
    // program connects when its session starts, which is not when somebody
    // decides to stream, and nothing on the channel is load bearing either way
    // (docs/07-platforms.md section 5.1).
    channel::listen();
    let mut seam = Admission::new(Config {
        microphone: Some(hear),
        exclusive_pointer,
        // The figure the pointer arbitration was tuned to. A flag exists so a
        // two-guest run can try another without a rebuild.
        exclusive_hold_ms: flag("--pointer-hold-ms")
            .and_then(|text| text.parse().ok())
            .unwrap_or(lowlat::floor::HOLD_MS),
        cg_level,
        rumble_probe,
        base_port,
        max_guests: max_guests as usize,
        servers: stun,
        shared_address_space: flag_set("--shared-address-space"),
        stream: Some(lowlat::stream::Config {
            // **Not a flag.** The depth is what the seated guests declare, so
            // the daemon starts eight-bit and the encoder is rebuilt if one
            // asks for ten; a switch here would choose for guests whose
            // decoders nobody running the daemon can see. Full chroma is the
            // same, and gated further by the census over every selectable
            // encoder, so there is nothing to configure here either.
            ten_bit: false,
            chroma_444: false,
            convert,
            // Prefer the encoder that shares the capture's device, where the
            // device can serve it; the environment (LOWLAT_VULKAN_ENCODE=1)
            // reaches the same knob without a flag.
            prefer_vulkan: flag_set("--vulkan-encode"),
            audio_kbps: flag("--audio-kbps")
                .and_then(|value| value.parse().ok())
                .unwrap_or(lowlat_audio::encode::DEFAULT_BITRATE_KBPS),
            allow_raw_audio: flag_set("--allow-raw-audio"),
            // **On, with nothing to turn it off.** A host that streams a
            // desktop streams its sound; the boundary keeps the switch because
            // an application embedding this library may have its own reasons,
            // and a daemon has none.
            audio_on: true,
            // **Off unless asked for**, like the boundary's own default: it
            // costs a packet every ten milliseconds on the control channel and
            // a peer is told to send one only because this said so.
            accept_microphone: flag_set("--accept-microphone"),
            audio: Some(audio_config()),
            codec,
            backend,
            cg_level,
            full_fps: flag_set("--full-fps"),
            quality,
            width,
            height,
            fps,
            configured_mbps: bitrate_mbps,
            min_mbps: MIN_BITRATE_MBPS,
            detail_rows,
            // **Named, not indexed.** An index is whichever order the kernel
            // enumerated in and moves when a cable does; the name is the
            // system's own and is what a session knows the output by too.
            output: flag("--output"),
            // **The display, unless asked otherwise.** A host streams a
            // desktop; the generator exists so the layers above capture can
            // be run and measured without a screen, and a run that wants it
            // says so. A host that cannot open the display refuses rather
            // than generating pictures in its place, because a stream of the
            // wrong thing is worse than none.
            display: !flag_set("--synth"),
        }),
    });

    let params = Connect {
        server,
        session_id: session,
        role: Role::Host,
        build: APP_V.to_string(),
        sdk_version: SDK_V,
        keepalive: lowlat_kessel::client::KEEPALIVE,
    };

    // Who each attempt is with, so an outbound message can be addressed. The
    // seam is addressed by attempt and knows nothing about peer identity. Both
    // outlive a signaling drop, because an established guest has its own media
    // path and does not depend on the connection that introduced it.
    // **Only what configuration decides.** What the stream is really producing
    // is the display's answer and is read where it is known; describing it from
    // here would report a stream nobody is producing the moment a display
    // turned out to be a different size from the one that was asked for.
    let settings = app::Settings {
        accept_microphone: flag_set("--accept-microphone"),
        // **Off unless asked for, and anything unrecognised is off.** One of
        // the two directions ships whatever the person at this machine copied,
        // and a typo must not open it.
        guest_clipboard: app::Clipboard::named(flag("--clipboard").as_deref()),
        output: flag("--output").unwrap_or_default(),
        // The ceiling is configured in whole megabits; a client reads it as
        // an integer and there is nothing below one to report.
        #[allow(
            clippy::cast_possible_truncation,
            clippy::cast_sign_loss,
            reason = "a configured bitrate in megabits, rounded and floored at zero"
        )]
        bitrate_mbps: bitrate_mbps.round().max(0.0) as u32,
        fps,
        host_os: flag("--host-os").and_then(|v| v.parse().ok()).unwrap_or(0),
        fake_output: flag_set("--fake-output"),
        // **Off unless asked for.** Nothing here skips a repeated picture, so
        // this is the permission rather than the behaviour; promising to spend
        // the bitrate forever is not a default worth having.
        full_fps: flag_set("--full-fps"),
    };
    let mut peers: std::collections::HashMap<String, Introduced> = std::collections::HashMap::new();
    let mut established: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut backoff = Backoff::new();

    loop {
        match Client::connect(&params).await {
            Ok(client) => {
                backoff.reset();
                // **An error inside a session reconnects rather than exits.**
                // A host that quits on one bad frame from the service takes
                // every established guest down with it, and the guests are the
                // thing this process exists to serve. The connection is the
                // recoverable part; losing it is what the loop already handles.
                match session_loop(
                    client,
                    &mut seam,
                    &mut peers,
                    &mut established,
                    &name,
                    max_guests,
                    admission_policy,
                    &settings,
                )
                .await
                {
                    Ok(true) => return Ok(()),
                    Ok(false) => lowlat_common::log_info!("lowlatd: signaling closed"),
                    Err(error) => lowlat_common::log_info!("lowlatd: session failed: {error}"),
                }
            }
            Err(error) => lowlat_common::log_info!("lowlatd: connect failed: {error}"),
        }

        // Attempts that were still negotiating are gone: the peer abandoned
        // them when the connection carrying their candidates dropped. An
        // established guest is not touched, because its media path never went
        // through here.
        let abandoned: Vec<String> = peers
            .keys()
            .filter(|id| !established.contains(*id))
            .cloned()
            .collect();
        for id in abandoned {
            lowlat_common::log_info!("lowlatd: abandoning in-flight {id}");
            seam.end_connection(&id);
            peers.remove(&id);
        }

        let delay = backoff.next_delay();
        lowlat_common::log_info!("lowlatd: reconnecting in {:.1}s", delay.as_secs_f64());
        tokio::select! {
            _ = tokio::time::sleep(delay) => {}
            _ = tokio::signal::ctrl_c() => {
                lowlat_common::log_info!("lowlatd: stopping");
                return Ok(());
            }
        }
    }
}

/// One connection's lifetime. Returns true when the operator asked to stop, and
/// false when the connection merely ended and should be retried.
#[allow(
    clippy::too_many_arguments,
    reason = "one call site, and a struct here would only rename the arguments"
)]
async fn session_loop(
    mut client: Client,
    seam: &mut Admission,
    peers: &mut std::collections::HashMap<String, Introduced>,
    established: &mut std::collections::HashSet<String>,
    name: &str,
    capacity: u32,
    admission_policy: policy::AdmissionPolicy,
    settings: &app::Settings,
) -> Result<bool, Box<dyn std::error::Error>> {
    // What was being captured the last time every guest was told. Zero until a
    // display has been opened, which is also what a host with no stream has.
    let mut captured: u32 = 0;
    // Resent on every connection, not just the first: the service takes it as
    // the frame that registers the session, so a reconnect without it is a
    // connection the service has not associated with this host.
    let _ = client.send_text("__ping__");
    client.send(
        "conn_update",
        &advertisement(name, capacity, occupancy(seam)),
    )?;
    lowlat_common::log_info!(
        "lowlatd: advertised as {name:?}, capacity {capacity}, {} guest(s) carried over",
        seam.occupancy()
    );

    // When the room was last told what everyone's numbers are.
    // **Said out loud at startup.** One of its two directions ships whatever
    // the person at this machine copied, so which way it is set is not
    // something anybody should have to infer from behaviour.
    lowlat_common::log_info!(
        "lowlatd: a guest's clipboard is {}",
        settings.guest_clipboard.name()
    );
    // The layout in force, which output the stream was pointed at when it was
    // last acted on, and where the picture sits in that layout.
    let mut layout: Option<Vec<lowlat::capture::Output>> = None;
    let mut situated = 0u32;
    let mut placed: Option<lowlat::capture::Placement> = None;
    // The last layout a helper pushed, and whose session it describes.
    let mut helper_layout: Option<(u32, Vec<lowlat::capture::Output>)> = None;
    // When the seat was last asked who owns the display.
    let mut seated = lowlat_common::clock::Time::now();
    let mut rostered = lowlat_common::clock::Time::now();
    // Whether the session was last told somebody is watching.
    let mut awake = false;
    // What a tray is shown, and the part of it that is re-read on a change.
    let mut shown = app::Shown::default();

    loop {
        tokio::select! {
            message = client.recv() => {
                let Some(message) = message else { return Ok(false) };
                match message.action.as_str() {
                    "offer_relay" => {
                        let offer: OfferRelay = serde_json::from_value(message.payload)?;
                        lowlat_common::log_info!("lowlatd: offer {} from {}", offer.attempt_id, offer.from);
                        peers.insert(
                            offer.attempt_id.clone(),
                            Introduced {
                                from: offer.from.clone(),
                                name: offer.user.name.clone(),
                            },
                        );

                        // Admission is the application's decision, and this
                        // application's policy is capacity alone.
                        // **Silence is not a refusal.** A declined answer is a
                        // wire event the peer acts on at once; no answer at all
                        // leaves it connecting indefinitely, because nothing in
                        // the protocol reports a host that never replied. Every
                        // offer gets an answer, including the ones we turn down.
                        let refusal = if !admission_policy.allows(offer.is_owner) {
                            Some("Open Parsec: owner-only admission policy".to_string())
                        } else {
                            if occupancy(seam) == 0 && !settings.output.is_empty() {
                                seam.select_output(Some(settings.output.clone()));
                            }
                            let transport = if offer.data.wants_web() {
                                Transport::Web
                            } else {
                                Transport::Bud
                            };
                            seam.new_attempt(&offer.attempt_id, Peer {
                                ufrag: offer.data.creds.ice_ufrag,
                                pwd: offer.data.creds.ice_pwd,
                                aes256: offer.data.creds.aes256,
                                transport,
                                fingerprint: offer.data.creds.fingerprint,
                                permissions: lowlat::inject::Permissions {
                                    keyboard: offer.permissions.keyboard,
                                    pointer: offer.permissions.mouse,
                                    gamepad: offer.permissions.gamepad,
                                },
                                owner: offer.is_owner,
                            })
                            .err()
                            .map(|error| error.to_string())
                        };
                        if let Some(why) = refusal {
                            lowlat_common::log_info!("lowlatd: declining {}: {why}", offer.attempt_id);
                            let empty = no_credentials();
                            client.send("answer", &Answer {
                                approved: false,
                                attempt_id: &offer.attempt_id,
                                data: AnswerData {
                                    base: HostDataBase::default(),
                                    creds: &empty,
                                },
                                to: &offer.from,
                            })?;
                            seam.end_connection(&offer.attempt_id);
                            peers.remove(&offer.attempt_id);
                            continue;
                        }
                        // **Zero: no opinion.** This service manages no
                        // gateway mapping and no port pool, so the configured
                        // base is the right start and the seam reports where it
                        // landed.
                        let host = seam.begin_p2p(&offer.attempt_id, 0)?;

                        let creds = Credentials {
                            // Empty means the attempt keys from the
                            // fingerprint, and the answer omits the field a
                            // peer of that generation cannot read.
                            aes256: (!host.aes256.is_empty()).then_some(host.aes256),
                            fingerprint: host.fingerprint,
                            ice_ufrag: host.ufrag,
                            ice_pwd: host.pwd,
                        };
                        client.send("answer", &Answer {
                            approved: true,
                            attempt_id: &offer.attempt_id,
                            data: AnswerData { base: HostDataBase::default(), creds: &creds },
                            to: &offer.from,
                        })?;
                        lowlat_common::log_info!("lowlatd: answered, guest bound to port {}", host.port);


                    }
                    "candex_relay" => {
                        let relay: CandexRelay = serde_json::from_value(message.payload)?;
                        match relay.data.read() {
                            Relayed::Ready => {
                                seam.add_candidate(
                                    &relay.attempt_id,
                                    UNREAD_MARKER_ADDRESS,
                                    true,
                                    lowlat::admission::Kind::Direct,
                                );
                            }
                            Relayed::Probe(addr) => {
                                // Both of the peer's markings, classified in
                                // one place for every caller of the seam.
                                let kind = lowlat::admission::Kind::marked(
                                    relay.data.lan,
                                    relay.data.from_stun,
                                );
                                seam.add_candidate(&relay.attempt_id, addr, false, kind);
                            }
                            // Not every candidate is an address: a peer may
                            // anonymise a host candidate behind a `.local` name
                            // that only multicast resolution answers. Nothing
                            // here can probe one, and saying so is the
                            // difference between a candidate declined and a
                            // candidate lost.
                            Relayed::Unreadable => lowlat_common::log_info!(
                                "lowlatd: candidate not an address, ignored: {}",
                                relay.data.ip
                            ),
                        }
                    }
                    "offer_cancel_relay" => {
                        let cancel: CancelRelay = serde_json::from_value(message.payload)?;
                        if established.contains(&cancel.attempt_id) {
                            lowlat_common::log_info!("Open Parsec: ignoring offer withdrawal for established session {}", cancel.attempt_id);
                            continue;
                        }
                        lowlat_common::log_info!("lowlatd: cancelled {}", cancel.attempt_id);
                        seam.end_connection(&cancel.attempt_id);
                        peers.remove(&cancel.attempt_id);
                        client.send("conn_update", &advertisement(name, capacity, occupancy(seam)))?;
                    }
                    // The service closes with a reason, and the reason is the
                    // only thing that distinguishes a bad session from a host
                    // that is simply unknown.
                    "close" => lowlat_common::log_info!("lowlatd: closed by the service: {}", message.payload),
                    // An opaque passthrough channel the schema does not list.
                    // Reported rather than dropped, so its arrival is visible.
                    "sdk" => lowlat_common::log_info!("lowlatd: sdk message: {}", message.payload),
                    other => lowlat_common::log_info!("lowlatd: ignoring {other}"),
                }
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(IDLE_MS)) => {}
            _ = tokio::signal::ctrl_c() => {
                lowlat_common::log_info!("lowlatd: stopping");
                return Ok(true);
            }
        }

        // **Watched rather than reported.** A guest asking for a different
        // output and a display moving to another card both change what is
        // being captured, and only the loop that rebuilt knows which happened;
        // this notices either, once it has actually landed.
        captured = app::announce_capture(seam, settings, captured);

        // **Repeated, because what it carries moves.** The room's membership
        // changes on an event and the roster is sent then; the telemetry inside
        // it changes continuously and nothing announces that, so a reader
        // watching a rate or a round trip needs the message again. Sent only
        // while somebody is there to read it.
        if lowlat_common::clock::elapsed_ms(rostered) >= ROSTER_MS && occupancy(seam) > 0 {
            rostered = lowlat_common::clock::Time::now();
            app::announce_guests(seam);
        }

        // **A lease, held while somebody is watching.** The screen blanking
        // during a session is the desktop doing exactly what it was told, and
        // nothing below the session can argue with it, so the session is asked
        // (docs/07-platforms.md section 5.1). Said on the change rather than on
        // a timer: it is a state, and a state repeated is a state that can
        // arrive out of order with the one that replaced it.
        let watched = occupancy(seam) > 0;
        if watched != awake {
            awake = watched;
            channel::screen_awake(watched);
        }

        // **Drained here rather than acted on where it arrives.** The channel
        // reads its socket on its own threads and only this loop may touch the
        // guests, so what a session says waits in a queue until this asks for
        // it (docs/07-platforms.md section 5.1).
        for (uid, said) in channel::take_said() {
            if let Some(text) = channel::is_clipboard(&said) {
                app::clipboard_to_guests(seam, settings, text.as_bytes());
            }
            if let Some(outputs) = channel::is_layout(&said) {
                // **Kept, and applied only if that session owns the display.**
                // A helper in a session that has gone inactive keeps pushing a
                // layout about a desktop nobody is scanning out.
                let owns = seat::active_uid().is_none_or(|active| active == uid);
                helper_layout = Some((uid, outputs.clone()));
                if owns {
                    placed = adopt_layout(seam, &mut layout, Some(outputs));
                }
            }
            // **The answer to a mode request is a line, not an action.** The
            // stream follows whatever the display became on its own.
            match channel::is_reply(&said) {
                Some(Ok(())) => lowlat_common::log_info!("lowlatd: the session set the mode"),
                Some(Err(reason)) => {
                    lowlat_common::log_info!("lowlatd: the session refused the mode, {reason}");
                }
                None => {}
            }
        }
        channel::drop_overdue();

        // **What a tray asked for, acted on here and attributed.** A tray's
        // frames wait in their own queue for the same reason a session's do:
        // only this loop may touch the guests.
        for (who, asked) in channel::take_acted() {
            app::on_action(seam, settings, who, &asked);
        }
        // **Said on every pass while somebody is looking, and sent on
        // change.** The room and the picture both move without an event this
        // loop sees, so what a tray shows is worked out each time round and
        // the channel decides whether it differs from what it last sent.
        // Nothing is worked out for nobody.
        if channel::trays() > 0 {
            channel::state(&app::state(seam, &mut shown, peers, established));
        }

        // **The display belongs to whichever session is in front of it, and
        // the login manager says which.** A user switch keeps the first
        // session alive with its helper connected, and puts a greeter with no
        // helper in front of the display; the layout in force has to be that
        // session's. Once a second: where the owning session has a helper,
        // its last push stands; where it has none, its own sockets are asked,
        // which root may do; where they say nothing, the picture is the
        // desktop, which is right for a greeter on one screen.
        if lowlat_common::clock::elapsed_ms(seated) >= SEAT_MS {
            seated = lowlat_common::clock::Time::now();
            // **No answer is no change.** Between one session and the next
            // the seat has no active session for a moment, and a layout
            // adopted then would be somebody's stale one over a desktop that
            // is about to be described properly.
            let active = seat::active_uid();
            let chosen = match active {
                Some(active) => match helper_layout.as_ref() {
                    Some((uid, outputs)) if *uid == active && channel::helper_for(active) => {
                        Some(outputs.clone())
                    }
                    _ => lowlat::capture::layout_of(active),
                },
                None => layout.clone(),
            };
            if chosen != layout {
                lowlat_common::log_info!(
                    "lowlatd: the display's session changed, uid={:?} outputs={}",
                    active,
                    chosen.as_ref().map_or(0, Vec::len)
                );
                placed = adopt_layout(seam, &mut layout, chosen);
            } else if placed.is_none() && layout.is_some() && seam.captured() != 0 {
                // **A layout adopted while the display was dark placed
                // nothing**, because nothing was lit to place; the display
                // coming back changes no name the pass below can see, so
                // this asks again until it is placed. **Only while something
                // is being captured**: with no guest seated nothing is, and
                // there is nothing to place -- the pass below places it when
                // a stream starts. Without this an idle host enumerated its
                // display devices and asked the session's sockets once a
                // second, forever, and said so each time.
                placed = situate(seam, layout.as_deref());
            }
        }

        // **Resolved when either half moves, not only when the desktop does.**
        // The two go stale for different reasons: a desktop that gained a
        // display, and a stream pointed at a different screen. Either leaves a
        // guest's absolute input mapped against a rectangle it is not in.
        let capturing = seam.captured();
        if capturing != situated {
            situated = capturing;
            placed = situate(seam, layout.as_deref());
        }
        // **Said every pass, though it is worked out only when it changes.**
        // The stream publishes what it read for itself when a pipeline is
        // built, and that reading is the one-shot one that goes stale; without
        // this, a rebuild for any reason at all would put the stale answer
        // back and nothing would notice. Repeating costs two stores.
        if placed.is_some() {
            seam.set_place(placed);
        }

        while let Some(received) = seam.poll_event() {
            // **Said out loud, because the queue is bounded.** An application
            // that stopped polling long enough loses the oldest events, and a
            // loss nobody reports looks like a peer that never did anything.
            if received.dropped > 0 {
                lowlat_common::log_info!(
                    "lowlatd: {} event(s) were dropped before this one",
                    received.dropped
                );
            }
            match received.event {
                Event::Candidate {
                    attempt,
                    addr,
                    from_stun,
                    lan,
                } => {
                    let Some(to) = peers.get(&attempt).map(|peer| &peer.from) else {
                        continue;
                    };
                    let kind = if from_stun { "reflexive" } else { "host" };
                    lowlat_common::log_info!("lowlatd: {kind} candidate {addr} for {attempt}");
                    // Both flags copied from the event verbatim: the marking
                    // is the boundary's decision, not this program's.
                    client.send(
                        "candex",
                        &candex(
                            &attempt,
                            to,
                            addr.ip().to_string(),
                            addr.port(),
                            lan,
                            from_stun,
                            false,
                        ),
                    )?;
                }
                Event::Ready { attempt } => {
                    let Some(to) = peers.get(&attempt).map(|peer| &peer.from) else {
                        continue;
                    };
                    client.send(
                        "candex",
                        &candex(
                            &attempt,
                            to,
                            READY_PLACEHOLDER.to_string(),
                            READY_PORT,
                            false,
                            false,
                            true,
                        ),
                    )?;
                }
                Event::Established { attempt, addr } => {
                    lowlat_common::log_info!("lowlatd: established {attempt} over {addr}");
                    established.insert(attempt.clone());
                    // **Everyone is told, not just the arrival.** The room the
                    // others are in changed too, and a guest that joined
                    // earlier has no way to ask.
                    app::announce_guests(seam);
                    client.send(
                        "conn_update",
                        &advertisement(name, capacity, occupancy(seam)),
                    )?;
                }
                // The enum is non-exhaustive, so a catch-all is required across
                // the crate boundary even though it is the shape this project
                // otherwise avoids. Logged rather than dropped silently, so a
                // variant added later announces itself at runtime.
                Event::Ended { attempt, outcome } => {
                    lowlat_common::log_info!("lowlatd: ended {attempt}, {outcome:?}");
                    if let lowlat::admission::Outcome::PeerLeft(code) = outcome {
                        if let Some(hint) = policy::error_hint(code) {
                            lowlat_common::log_warn!("Open Parsec: {hint}");
                        }
                    }
                    // Reaped whatever the reason: the loop has stopped, and
                    // leaving the attempt registered holds its port for the
                    // life of the host.
                    seam.end_connection(&attempt);
                    peers.remove(&attempt);
                    established.remove(&attempt);
                    // Told after the reaping, so the roster describes the room
                    // as it is rather than as it was a moment ago.
                    app::announce_guests(seam);
                    client.send(
                        "conn_update",
                        &advertisement(name, capacity, occupancy(seam)),
                    )?;
                }
                // **Answered here and nowhere below.** The identifier and the
                // body are this application's protocol rather than the SDK's,
                // so the choice of what they mean is made at this level and
                // the layers under it stay ignorant of it.
                Event::UserData { guest, id, text } => {
                    // **The exact bytes for configuration, a length for a
                    // person's own text.** Having the bytes beside the question
                    // is what makes a wrong answer findable, and that reasoning
                    // inverts for the identifiers that carry what somebody
                    // typed or copied: the same line turns this log into a
                    // transcript of a desktop.
                    let printable: String = if app::carries_user_text(id) {
                        String::new()
                    } else {
                        text.iter()
                            .take(120)
                            .map(|byte| {
                                if byte.is_ascii_graphic() || *byte == b' ' {
                                    char::from(*byte)
                                } else {
                                    '.'
                                }
                            })
                            .collect()
                    };
                    let spoken = app::on_message(seam, guest, id, &text, settings);
                    lowlat_common::log_info!(
                        "lowlatd: guest {guest} sent id={id} len={} {}body={printable}",
                        text.len(),
                        if spoken { "" } else { "(not ours) " }
                    );
                }
                other => lowlat_common::log_info!("lowlatd: unhandled seam event {other:?}"),
            }
        }
    }
}

#[cfg(test)]
mod role_tests {
    use super::{Program, program_of};

    /// **The role is a privilege boundary, so the word only counts in first
    /// position.** A flag is matched wherever it appears in a command line;
    /// this must not be, or a service invoked with an argument somebody else
    /// chose can be turned into a session agent, or the reverse.
    #[test]
    fn only_the_first_argument_selects_the_session_role() {
        assert_eq!(program_of(["session"]), Program::Session);
        assert_eq!(program_of(["session", "--verbose"]), Program::Session);
        assert_eq!(program_of(["tray"]), Program::Tray);
        assert_eq!(program_of(["tray", "--verbose"]), Program::Tray);
        assert_eq!(program_of(["--tray"]), Program::Service);
        assert_eq!(program_of(["--verbose", "tray"]), Program::Service);
        assert_eq!(program_of(["session", "tray"]), Program::Session);

        assert_eq!(program_of([] as [&str; 0]), Program::Service);
        assert_eq!(program_of(["--verbose"]), Program::Service);
        // The word, anywhere but first.
        assert_eq!(program_of(["--name", "session"]), Program::Service);
        assert_eq!(program_of(["--verbose", "session"]), Program::Service);
        // The word as a flag, which is the shape the rule exists to refuse.
        assert_eq!(program_of(["--session"]), Program::Service);
        assert_eq!(
            program_of(["--output", "card0:DP-1", "--session"]),
            Program::Service
        );
    }
}
