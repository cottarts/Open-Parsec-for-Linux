//! GNOME mode changes run in the graphical user's session, never in root host.
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};
fn helper() -> PathBuf {
    let local = std::env::current_exe().ok().and_then(|p| {
        p.parent()?
            .parent()
            .map(|p| p.join("apps/control/gnome_mode.py"))
    });
    local
        .filter(|p| p.is_file())
        .unwrap_or_else(|| PathBuf::from("/opt/open-parsec/apps/control/gnome_mode.py"))
}
pub(crate) fn offered() -> bool {
    std::env::var("XDG_CURRENT_DESKTOP")
        .unwrap_or_default()
        .contains("GNOME")
        && invoke(&["probe"]).is_ok()
}
fn invoke(args: &[&str]) -> Result<(), String> {
    let mut child = Command::new("/usr/bin/python3")
        .arg(helper())
        .args(args)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| e.to_string())?;
    let deadline = Instant::now() + Duration::from_millis(2500);
    loop {
        if child.try_wait().map_err(|e| e.to_string())?.is_some() {
            break;
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            return Err("GNOME display request timed out".into());
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    let output = child.wait_with_output().map_err(|e| e.to_string())?;
    if output.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&output.stderr)
            .trim()
            .chars()
            .take(500)
            .collect())
    }
}
pub(crate) fn set(
    output: &str,
    size: Option<(u32, u32)>,
    transform: Option<u32>,
) -> Result<(), String> {
    let mut args = vec!["apply".to_string(), "--output".into(), output.into()];
    if let Some((w, h)) = size {
        args.extend([
            "--width".into(),
            w.to_string(),
            "--height".into(),
            h.to_string(),
        ]);
    }
    if let Some(turn) = transform {
        args.extend(["--transform".into(), turn.to_string()]);
    }
    invoke(&args.iter().map(String::as_str).collect::<Vec<_>>())
}
pub(crate) fn restore() {
    if let Err(e) = invoke(&["restore"]) {
        lowlat_common::log_warn!("session: GNOME restore refused: {e}");
    }
}
