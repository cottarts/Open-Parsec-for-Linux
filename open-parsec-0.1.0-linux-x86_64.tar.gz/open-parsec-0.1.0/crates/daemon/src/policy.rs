//! Open Parsec policies above the transport/SDK boundary.
#[derive(Debug, Clone, Copy)]
pub(crate) struct AdmissionPolicy {
    pub reject_all: bool,
    pub allow_guests: bool,
}
impl AdmissionPolicy {
    pub(crate) fn allows(self, service_says_owner: bool) -> bool {
        !self.reject_all && (service_says_owner || self.allow_guests)
    }
}
pub(crate) fn secure_signaling(server: &str) -> bool {
    server
        .strip_prefix("wss://")
        .is_some_and(|host| !host.is_empty() && !host.starts_with('/'))
}
pub(crate) fn local_allowed(uid: u32, configured: Option<u32>) -> bool {
    uid == 0 || configured == Some(uid)
}
pub(crate) fn error_hint(code: i32) -> Option<&'static str> {
    match code {
        -17 => Some(
            "-17 DECODE_ERR_NO_SUPPORT: client rejected the video format; test H.264 8-bit 4:2:0 on one display, then HEVC. A self-connection does not validate a remote client.",
        ),
        -6101 => Some(
            "-6101: client cannot reach Parsec backend/auth/signaling. Check client DNS, TLS and TCP 443; this occurs before NVENC decoding.",
        ),
        -6023 => Some(
            "-6023: peer connectivity failed; check candidates, LAN UDP, firewall and NAT independently of video.",
        ),
        _ => None,
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn owners_are_admitted_guests_are_explicit() {
        let p = AdmissionPolicy {
            reject_all: false,
            allow_guests: false,
        };
        assert!(p.allows(true));
        assert!(!p.allows(false));
        assert!(
            AdmissionPolicy {
                allow_guests: true,
                ..p
            }
            .allows(false)
        );
        assert!(
            !AdmissionPolicy {
                reject_all: true,
                ..p
            }
            .allows(true)
        );
    }
    #[test]
    fn session_tokens_require_tls() {
        for s in [
            "ws://localhost",
            "http://example.com",
            "wss://",
            "wss:///bad",
        ] {
            assert!(!secure_signaling(s));
        }
        assert!(secure_signaling("wss://kessel-ws.parsec.app"));
    }
    #[test]
    fn local_channel_is_bound_to_configured_uid() {
        assert!(!local_allowed(1001, Some(1000)));
        assert!(!local_allowed(1000, None));
        assert!(local_allowed(1000, Some(1000)));
        assert!(local_allowed(0, None));
    }
    #[test]
    fn positive_17_is_not_negative_17() {
        assert!(error_hint(17).is_none());
        assert!(error_hint(-17).unwrap().contains("DECODE_ERR_NO_SUPPORT"));
        assert!(error_hint(-6101).unwrap().contains("before NVENC"));
    }
}
